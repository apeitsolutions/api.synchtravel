
<?php

// Travelanda Apis
if(isset($_POST)){

    $case = $_POST['case'];
  
if($case == 'travelandaSearch')
{
travelandaSearch();
}
if($case =='travelandapreBooking')
{
travelandapreBooking();
}
if($case == 'travelandaCnfrmBooking'){
travelandaCnfrmBooking();
}
    
    
}

function travelandaSearch(){
    $CityId= $_POST['CityId'];
    $CheckInDate= $_POST['CheckInDate'];
    $CheckOutDate=$_POST['CheckOutDate'];
    $res_data= $_POST['res_data'];
    $country_nationality= $_POST['country_nationality'];
   
    $res_data=json_decode($res_data);
      

    


$data_request="<Request>
<Head>
 <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
    <Password>rY8qm76g5dGH</Password>
    <RequestType>HotelSearch</RequestType>
</Head>
<Body>
<CityIds>
<CityId>$CityId</CityId>
</CityIds>
<CheckInDate>$CheckInDate</CheckInDate>
<CheckOutDate>$CheckOutDate</CheckOutDate>
<Rooms>";

foreach($res_data as $res_data)
{
$data_request .="
  
 
 <Room>
<NumAdults>". $res_data->Adults ."</NumAdults>
<Children>";
if(isset($res_data->ChildrenAge))
{
foreach ($res_data->ChildrenAge as $item)
{
$data_request .='<ChildAge>'. $item[0] .'</ChildAge>';
}
}
$data_request .= "
</Children>
</Room>

"; 
// echo $data_request;

}

$data_request .="</Rooms><Nationality>".$country_nationality."</Nationality>
<Currency>GBP</Currency>
<AvailableOnly>1</AvailableOnly>
</Body>
</Request>";


        
      //print_r($data_request); die();
        $url = "http://xmldemo.travellanda.com/xmlv1/";
$timeout = 20;
        $data = array('xml' => $data_request);
        $headers = array(
            "Content-type: application/x-www-form-urlencoded",
        );
        $ch = curl_init();
        $payload = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
          $response = curl_exec($ch);
          curl_close($ch);
           $xml = simplexml_load_string($response);
        $json = json_encode($xml);
          echo $json;
    }

    
    function travelandapreBooking(){
        $roomRateIn = $_POST['roomRate'];
        $roomRate= json_decode($roomRateIn);
        
         $url = "http://xmldemo.travellanda.com/xmlv1/";
        $timeout = 20;
        $reqdata = "<Request>
        <Head>
        <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
        <Password>rY8qm76g5dGH</Password>
        <RequestType>HotelPolicies</RequestType>
        </Head>
        <Body>";
        foreach($roomRate as $roomRate1)
        {
          $reqdata .="  
            <OptionId>".$roomRate1->OptionId."</OptionId>
            
          "; 
        }
        
        
        $reqdata .="</Body>
        </Request>";
        
        // print_r($reqdata);die();
        
        $data = array('xml' => $reqdata);
        
        // print_r($data);die();
        
        $headers = array(
            "Content-type: application/x-www-form-urlencoded",
        );
        $ch = curl_init();
        $payload = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $rawdata = curl_exec($ch);
        
    }
    
    function travelandaCnfrmBooking(){
        
        $rooms_details= $_POST['rooms_details'];
       $h_option_id= $_POST['h_option_id'];
          $room_search= $_POST['room_search'];
        $children_details= $_POST['children_details'];
        $t_passenger= $_POST['t_passenger'];
           $lead_passenger_details= $_POST['lead_passenger_details'];
        $other_passenger_details= $_POST['other_passenger_details'];
        
        
         $rooms_details= json_decode($rooms_details);
        $children_details= json_decode($children_details);
         $lead_passenger_details= json_decode( $lead_passenger_details);
        $other_passenger_details= json_decode($other_passenger_details);
        
         $url = "http://xmldemo.travellanda.com/xmlv1/";
        $timeout = 20; 
   
   if($room_search == 1)
   {
      
      
      $data_request="<Request>
<Head>
<Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
<Password>rY8qm76g5dGH</Password>
<RequestType>HotelBooking</RequestType>
</Head>
<Body>
<OptionId>". $h_option_id ."</OptionId>
<YourReference>XMLTEST</YourReference>
<Rooms>";


    
$data_request .="
 <Room>
 
<RoomId>". $rooms_details[0]->Rooms->Room->RoomId ."</RoomId>

<PaxNames>";

 

 $data_request .="
 <AdultName>
<Title>". $lead_passenger_details->lead_title ."</Title>
<FirstName>". $lead_passenger_details->lead_first_name ."</FirstName>
<LastName>".$lead_passenger_details->lead_last_name."</LastName>
</AdultName>";

if(isset($other_passenger_details))
{
  $count=0;  
foreach($other_passenger_details as $other_passenger_details)
{
    
    if($t_passenger > $count)
    {
    
   $data_request .="
 <AdultName>
<Title>". $other_passenger_details->title ."</Title>
<FirstName>". $other_passenger_details->other_first_name ."</FirstName>
<LastName>". $other_passenger_details->other_last_name ."</LastName>
</AdultName>";

}
$count=$count+1;
}
}
// if(isset($children_details))
// {
// foreach ($res_data->ChildrenAge as $item)
// {
  $data_request .="<ChildName>
<FirstName>ather</FirstName>
<LastName>ather</LastName>
</ChildName>";
// }
// }
$data_request .="
</PaxNames>
</Room>

"; 
  
   }
   else
   {
     $data_request="<Request>
<Head>
<Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
<Password>rY8qm76g5dGH</Password>
<RequestType>HotelBooking</RequestType>
</Head>
<Body>
<OptionId>". $h_option_id ."</OptionId>
<YourReference>XMLTEST</YourReference>
<Rooms>";

foreach($rooms_details[0]->Rooms->Room as $rooms_details)
{
    
$data_request .="
 <Room>
 
<RoomId>". $rooms_details->RoomId ."</RoomId>

<PaxNames>";
 $other_passenger_details = Session()->get('other_adults',[]);
 

 $data_request .="
 <AdultName>
<Title>". $lead_passenger_details->lead_title ."</Title>
<FirstName>". $lead_passenger_details->lead_first_name ."</FirstName>
<LastName>".$lead_passenger_details->lead_last_name."</LastName>
</AdultName>";

if(isset($other_passenger_details))
{
  $count=0;  
foreach($other_passenger_details as $other_passenger_details)
{
    
    if($t_passenger > $count)
    {
    
   $data_request .="
 <AdultName>
<Title>". $other_passenger_details->title ."</Title>
<FirstName>". $other_passenger_details->other_first_name ."</FirstName>
<LastName>". $other_passenger_details->other_last_name ."</LastName>
</AdultName>";

}
$count=$count+1;
}
}
// if(isset($children_details))
// {
// foreach ($res_data->ChildrenAge as $item)
// {
  $data_request .="<ChildName>
<FirstName>ather</FirstName>
<LastName>ather</LastName>
</ChildName>";
// }
// }
$data_request .="
</PaxNames>
</Room>

";   
   }
        

// echo $data_request;


}

$data_request .="</Rooms>
</Body>
</Request>";

//  echo $data_request;
//  die();
      
      
      
        $data = array('xml' => $data_request);
        $headers = array(
            "Content-type: application/x-www-form-urlencoded",
        );
        $ch = curl_init();
        $payload = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $rawdata = curl_exec($ch);
        
    }
    ?>


