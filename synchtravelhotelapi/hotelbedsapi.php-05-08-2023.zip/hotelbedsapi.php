
<?php

// hotelbeds Apis
if(isset($_POST)){

    $case = $_POST['case'];
  
 if($case =='serach_hotelbeds'){
        
        serach_hotelbeds();
    }

    
    
}
function pr($x){
	    $apiKey = '833583586f0fd4fccd3757cd8a57c0a8';
        $secret = 'ae2dc887d0';
        $signature = hash("sha256", $apiKey.$secret.time());
        return $signature;
        // print_r($signature);
	}
function serach_hotelbeds(){
    
   
    
$newstart= $_POST['CheckIn'];
    $newend= $_POST['CheckOut'];
    $res_hotel_beds= $_POST['res_hotel_beds'];
    $lat =$_POST['lat'];
    $long =$_POST['long'];


$res_hotel_beds=json_decode($res_hotel_beds);

//print_r();die();
    

    

$curl = curl_init();
    
    $geolocation=array(
                        "latitude" => $lat,
                        "longitude" => $long,
                        "radius" => 20,
                        "unit" => "km",
                  );
              
    $data = array(
                'platform'=>"207",
                'stay'=>array(
                    'checkIn' =>$newstart,
                    'checkOut' => $newend,
                ),
                'occupancies' => $res_hotel_beds,
                    'geolocation' =>  $geolocation,
                );
                
                
    
               $hotel_bed_request_data = $data;
                
    $signature = pr($data);  
    //print_r($data);die();
    $data=json_encode($data);
    
    
    
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.test.hotelbeds.com/hotel-api/1.0/hotels',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>$data,
    CURLOPT_HTTPHEADER => array(
    'Api-key: 833583586f0fd4fccd3757cd8a57c0a8',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json'
    ),
    ));
    
    $response = curl_exec($curl);

    curl_close($curl);
    echo $response;

}


function gethotelbedsBooking(){
    
    $roomRateIn= $_POST['roomRate'];
    $roomRate= json_decode($roomRateIn);
     $data_res = '{
     "platform ID":"207",
    "rooms":[
    ';
    foreach($roomRate as $roomRate)
    {
        
  $data_res .='
    
        {
            "rateKey": "'.$roomRate->rate_rateKey.'"
        },
        
        
      ';
    }
    
    $data_res .='
        
    ]
   
    
     ';
    
   $data_res .='
    }';

$data_res = substr_replace($data_res, '', strrpos($data_res, ','), 1);

$signature = pr($data_res);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.test.hotelbeds.com/hotel-api/1.0/checkrates',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>$data_res,
  CURLOPT_HTTPHEADER => array(
    'Api-key: 833583586f0fd4fccd3757cd8a57c0a8',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
 echo $response;
curl_close($curl);
    
    
}

function getcnfrmhotelbedsBooking(){
    
    $lead_passenger_details= $_POST['lead_passenger_details'];
    $room_searching= $_POST['room_searching'];
    $other_passenger_details= $_POST['other_passenger_details'];
    $other_child= $_POST['other_child'];
    $remarks_hotelbeds= $_POST['remarks_hotelbeds'];
     $hotel_bed_remarks= $_POST['hotel_bed_remarks'];

    
    
    
    if($room_searching == 1)
   {
    $data_res = '{
    
    "holder": {
        "name": "'. $lead_passenger_details->lead_first_name .'",
        "surname": "'. $lead_passenger_details->lead_last_name .'"
    },
    "platform ID":"207",
    "rooms": [
    ';
    $room_count=1;
    foreach($hotel_beds_select->hotel->rooms as $rooms)
    {
        
    foreach($rooms->rates as $rates)
    {
        
  $data_res .='
    
        {
           "rateKey": "'.$rates->rateKey.'",
 "paxes": [
 
                {
                    "roomId": "'.$room_count.'",
                    "type": "AD",
                    "name": "'.$lead_passenger_details->lead_first_name.'",
                    "surname": "'.$lead_passenger_details->lead_last_name.'"
                },
 
        ';
        
        
        $count=0;
        $count1=1;
      
        $other_adults= Session()->get('other_adults');
        // print_r($other_adults);die();
        if(isset($other_adults))
        {
            
       
        foreach($other_adults as $other_adults)
    {
        if($t_passenger > $count)
        {
           
       
       $data_res .='
       
                {
                    "roomId": "'.$room_count.'",
                    "type": "AD",
                    "name": "'.$other_adults->other_first_name.'",
                    "surname": "'.$other_adults->other_last_name.'"
                },
                ';
                
              
                
       
        
        
        
        }
     $count=$count+1;
     
    $count1=$count1+1;
   }
    
    if(isset($other_child))
    {
    foreach($other_child as $other_child)
    {
        
            
       
       $data_res .='
       
                {
                    "roomId": "'.$room_count.'",
                    "type": "CH",
                    "name": "'.$other_child->other_first_name.'",
                    "surname": "'.$other_child->other_last_name.'"
                },
                ';
                
        
    
   }
   
        }
      $data_res= substr_replace($data_res, '', strrpos($data_res, ','), 1);
   
    }
    else
    {
       $data_res .='
       
       
                {
                    "roomId": "'.$room_count.'",
                    "type": "AD",
                    "name": "'.$lead_passenger_details->lead_first_name.'",
                    "surname": "'.$lead_passenger_details->lead_last_name.'"
                },
                '; 
    }
        $data_res .='        
        ]
        }, 
      ';
      
    
    }
    
}
  $data_res= substr_replace($data_res, '', strrpos($data_res, ','), 1);
    $data_res .='
       
   ],
   
    
     ';
    
   $data_res .='
  
    "clientReference": "IntegrationAgency",
    "remark": "'.$hotel_bed_remarks .'",
    "tolerance": 2
}';   
   }
   else
   {
   $data_res = '{
    
    "holder": {
        "name": "'. $lead_passenger_details->lead_first_name .'",
        "surname": "'. $lead_passenger_details->lead_last_name .'"
    },
    "platform ID":"207",
    "rooms": [
    ';
    $room_count=1;
    foreach($hotel_beds_select->hotel->rooms as $rooms)
    {
        
    foreach($rooms->rates as $rates)
    {
        
  $data_res .='
    
        {
           "rateKey": "'.$rates->rateKey.'",
 "paxes": [
 
 
                {
                    "roomId": "'.$room_count.'",
                    "type": "AD",
                    "name": "'.$lead_passenger_details->lead_first_name.'",
                    "surname": "'.$lead_passenger_details->lead_last_name.'"
                },
        ';
        
        
        $count=0;
        $count1=1;
       $temp=1;
        $counter=1;
        $other_adults= Session()->get('other_adults');
        // print_r($other_adults);die();
        if(isset($other_adults))
        {
            
       
        foreach($other_adults as $other_adults)
    {
        if($t_passenger > $count)
        {
            if($temp <= 1)
            {
       
       $data_res .='
       
                {
                    "roomId": "'.$counter.'",
                    "type": "AD",
                    "name": "'.$other_adults->other_first_name.'",
                    "surname": "'.$other_adults->other_last_name.'"
                },
                ';
                
                $temp=$temp+1;
                
        }
        else
        {
            $counter=$counter+1;
            $temp=0;
           $data_res .='
       
                {
                    "roomId": "'.$counter.'",
                    "type": "AD",
                    "name": "'.$other_adults->other_first_name.'",
                    "surname": "'.$other_adults->other_last_name.'"
                },
                ';
                
                $temp=$temp+1;  
        }
        
        
        }
     $count=$count+1;
     
    $count1=$count1+1;
   }
    
    if(isset($other_child))
    {
    foreach($other_child as $other_child)
    {
        
            
       
       $data_res .='
       
                {
                    "roomId": "'.$count1.'",
                    "type": "CH",
                    "name": "'.$other_child->other_first_name.'",
                    "surname": "'.$other_child->other_last_name.'"
                },
                ';
                
        
    
   }
   
        }
      $data_res= substr_replace($data_res, '', strrpos($data_res, ','), 1);
   
    }
    else
    {
       $data_res .='
       
       
                {
                    "roomId": "'.$room_count.'",
                    "type": "AD",
                    "name": "'.$lead_passenger_details->lead_first_name.'",
                    "surname": "'.$lead_passenger_details->lead_last_name.'"
                },
                '; 
    }
        $data_res .='        
        ]
        }, 
      ';
      
    
    }
    
}
  $data_res= substr_replace($data_res, '', strrpos($data_res, ','), 1);
    $data_res .='
       
   ],
   
    
     ';
    
   $data_res .='
  
    "clientReference": "IntegrationAgency",
    "remark": "'.$hotel_bed_remarks .'",
    "tolerance": 2
}';

}
   

   
   
//  print_r($data_res);die();  
   

// $data=$data;
//   $data=json_encode($data);
//   print_r($data);die;
$signature = pr($data_res);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.test.hotelbeds.com/hotel-api/1.0/bookings',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>$data_res,
  CURLOPT_HTTPHEADER => array(
    'Api-key: 833583586f0fd4fccd3757cd8a57c0a8',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
echo $response;
curl_close($curl); 

$res=json_decode($response);
    
}
?>


