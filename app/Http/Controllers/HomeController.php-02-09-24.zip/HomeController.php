<?php

namespace App\Http\Controllers;

use App\Mail\SendMail;
use App\Models\Leave;
use Illuminate\Http\Request;
use Auth;
use Session;
use DB;
use Illuminate\Support\Facades\Hash;
class HomeController extends Controller
{
    
  public function all_currency_get()
    {
      
      $currency = DB::table('countries')->get(); 
      //print_r($currency);die();
      return response()->json(['message'=>'success','currency'=>$currency]);
    }
    
    public function register_customer_submit(Request $request){
        $token              = $request->token;
        $title              = $request->title;
        $first_name         = $request->first_name;
        $last_name          = $request->last_name;
        $email              = $request->email;
        $company_name       = $request->company_name;
        $company_address    = $request->company_address;
        $country            = $request->country;
        $city               = $request->city;
        $phone_no           = $request->phone_no;
        $zip_code           = $request->zip_code;
        $otp_code           = $request->otp_code;
        $password           = Hash::make($request->password);
        $b2b_agents_get     = DB::table('b2b_agents')->where('email',$email)->where('token',$token)->first();
      
        if(isset($b2b_agents_get)){
            return response()->json(['status'=>'error','message'=>'Account Already Registered! ']);  
        }
        else{
            $b2b_agents             = DB::table('b2b_agents')->insert([
                'token'             => $token,
                'title'             => $title,
                'first_name'        => $first_name,
                'last_name'         => $last_name,
                'email'             => $email,
                'company_name'      => $company_name,
                'company_address'   => $company_address,
                'country'           => $country,
                'city'              => $city,
                'phone_no'          => $phone_no,
                'zip_code'          => $zip_code,
                'password'          => $password,
                'otp_code'          => $otp_code,
                //   'varified_at'=>'0',
                'varified_at'       => '1',
            ]);
            return response()->json(['status'=>'success','message'=>$b2b_agents,'message1']);  
        }
    }
    
    
    public function login_customer_submit(Request $request){
        $b2b_agents = DB::table('b2b_agents')->where('email',$request->email)->where('token',$request->token)->first();
        // return $b2b_agents;
        if(isset($b2b_agents)){
            if($request->email == $b2b_agents->email && Hash::check($request->password, $b2b_agents->password) && $b2b_agents->varified_at == 1 && $request->token == $b2b_agents->token){
                if($b2b_agents->approve_Status == 1){
                    return response()->json(['status'=>'success','b2b_agent'=>$b2b_agents]);
                }else{
                    return response()->json(['status'=>'error','message'=>'Please Aprrove Your Account','error_code'=>1]);
                }
            }
            else{
                if(!Hash::check($request->password, $b2b_agents->password)){
                    return response()->json(['status'=>'error','message'=>'Please Correct Your Password','error_code'=>1]);
                }
                
                if($b2b_agents->varified_at != 1){
                    return response()->json(['status'=>'error','message'=>'Please Varified The Account','error_code'=>2]);
                }
                
                if($request->token != $b2b_agents->token){
                    return response()->json(['status'=>'error','message'=>'Please Register Your Account','error_code'=>3]);
                }
            }
        }
        else{
            return response()->json(['status'=>'error','message'=>'Please Register Your Account','error_code'=>4]);   
        }
    }
    
public function sendVerificationEmail(Request $request)
{
    $token=$request->token;
        $email=$request->email;
      $otp_code=$request->otp_code;
      $b2b_agents=DB::table('b2b_agents')->where('email',$email)->update([
          'otp_code'=>$otp_code,
          ]);
          return response()->json(['status'=>'success','message'=>$b2b_agents]); 
}

public function sendVerificationOtpCode(Request $request)
{
   $token=$request->token;
      $otp_code=$request->otp_code;
      $b2b_agents=DB::table('b2b_agents')->where('otp_code',$otp_code)->update([
          'varified_at'=>1,
          ]);
          return response()->json(['status'=>'success','message'=>$b2b_agents]); 
}

public function submitForgetPasswordForm(Request $request)
{
   $token=$request->token;
      $email=$request->email;
      $reset_password_token=$request->reset_password_token;
      $b2b_agents=DB::table('b2b_agents')->where('email',$email)->update([
          'reset_password_token'=>$reset_password_token,
          ]);
      
      
        return response()->json(['status'=>'success','message'=>$b2b_agents]); 
}

public function submitResetPasswordForm(Request $request)
{
   $token=$request->token;
      $email=$request->email;
      $password_reset_token=$request->password_reset_token;
      $password=$request->password;
      $confirm_password=$request->confirm_password;
      if($password == $confirm_password)
      {
       $b2b_agents=DB::table('b2b_agents')->where('email',$email)->where('reset_password_token',$password_reset_token)->update([
          'password'=>Hash::make($password),
          ]);
      
     return response()->json(['status'=>'success','message'=>$b2b_agents]);   
      }
      else
      {
       return response()->json(['status'=>'error','message'=>'password Are Not Match']);   
      }
       
}








}
