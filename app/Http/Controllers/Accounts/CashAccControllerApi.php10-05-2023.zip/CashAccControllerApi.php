<?php

namespace App\Http\Controllers\Accounts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\ReceviedPayments;
use App\Models\Payments;

use App\Models\CustomerSubcription\CustomerSubcription;
use DB;
class CashAccControllerApi extends Controller
{
    //
    
    public function subcritions_details(Request $request){

        $userData = CustomerSubcription::where('Auth_key',$request->token)->first();
        if($userData){
            
            
            return response()->json([
                'status'=>'success',
                'data'=>$userData
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    public function cash_accounts_list(Request $request){
        // print_r($request->all());
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            $accounts_data = DB::table('cash_accounts')->where('customer_id',$userData->id)->get();
            
            return response()->json([
                'status'=>'success',
                'data'=>$accounts_data
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    public function cash_accounts_ledger(Request $request){
        // print_r($request->all());
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            $accounts_ledger_data = DB::table('cash_accountledgers')->where('account_id',$request->id)->get();
            $accounts_data = DB::table('cash_accounts')->where('id',$request->id)->first();
            
            return response()->json([
                'status'=>'success',
                'data'=>$accounts_ledger_data,
                'account_data'=>$accounts_data
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>'',
                'account_data'
            ]);
        }
    }
    
    public function view_pay_recv(Request $request){
        // print_r($request->all());
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            $accounts_ledger_data = DB::table('recevied_payments')->where('id',$request->id)->first();
            
            $accounts_data = DB::table('cash_accounts')->where('id',$accounts_ledger_data->received_from)->first();
            
            return response()->json([
                'status'=>'success',
                'data'=>$accounts_ledger_data,
                'account_data'=>$accounts_data
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>'',
                'account_data'
            ]);
        }
    }
    
    
    
   public function add_payment_recv(Request $request){
        // print_r($request->all());
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            $accounts_data = DB::table('cash_accounts')->where('customer_id',$userData->id)->get();
            $agents_data = DB::table('Agents_detail')->where('customer_id',$userData->id)->get();
            $customers_data = DB::table('booking_customers')->where('customer_id',$userData->id)->get();
            $hotels_supplier_data = DB::table('rooms_Invoice_Supplier')->where('customer_id',$userData->id)->select('id','balance','payable','room_supplier_name')->get();
            $flight_supplier_data = DB::table('supplier')->where('customer_id',$userData->id)->select('id','balance','contactpersonname','companyname')->get();
            $transfer_supplier_data = DB::table('transfer_Invoice_Supplier')->where('customer_id',$userData->id)->select('id','balance','room_supplier_name','room_supplier_company_name')->get();
            
            $third_party_companies = DB::table('3rd_party_commissions')->where('customer_id',$userData->id)->get();
            
            
            return response()->json([
                'status'=>'success',
                'cash_accounts'=>$accounts_data,
                'agents'=>$agents_data,
                'customers'=>$customers_data,
                'hotels_supplier_data'=>$hotels_supplier_data,
                'transfer_supplier_data'=>$transfer_supplier_data,
                'flight_supplier_data'=>$flight_supplier_data,
                'third_party_companies'=>$third_party_companies
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    
    
    public function cash_accounts_add(Request $request){
        // print_r($request->all());
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            
            $request_data = json_decode($request->req_data);
            
               
                                                 
            DB::table('cash_accounts')->insert([
                'name'=>$request_data->name,
                'account_no'=>$request_data->account_no,
                'opening_balance'=>$request_data->opening_balance,
                'balance'=>$request_data->opening_balance,
                'customer_id'=>$userData->id
                ]);
            
            $accounts_data = DB::table('cash_accounts')->where('customer_id',$userData->id)->get();
            
            return response()->json([
                'status'=>'success',
                'data'=>$accounts_data
            ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    public function payments_recv_submit(Request $request){
        // print_r($request->all());
        $request_data = json_decode($request->request_data);
        
        // print_r($request_data);
        // die;
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            
            
             DB::beginTransaction();
                try {
                    // Insert Payment in Table 
                    $paymentObj = new ReceviedPayments;
                    $paymentObj->date = $request_data->current_date;
                    $paymentObj->prev_balance = $request_data->account_prev_bal;
                    $paymentObj->updated_balance = $request_data->updated_balnc;
                    $paymentObj->total_received = $request_data->total_payments;
                    $paymentObj->Criteria = json_encode($request_data->criteria);
                    $paymentObj->Content = json_encode($request_data->content);
                    $paymentObj->Content_Ids = json_encode($request_data->content_ids);
                    $paymentObj->Amount = json_encode($request_data->amount);
                    $paymentObj->remarks = json_encode($request_data->remarks);
                    $paymentObj->received_from = $request_data->payment_from;
                    $paymentObj->customer_id = $userData->id;
                    $paymentObj->save();
        
                    foreach($request_data->criteria as $index => $ctr_res){
                        if($ctr_res == 'Agent'){
                            
                             $agent_data = DB::table('Agents_detail')->where('id',$request_data->content_ids[$index])->select('id','balance','agent_Name')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $agent_data->balance - $request_data->amount[$index];
                            
                            
                            
                             
                                    DB::table('agents_ledgers_new')->insert([
                                        'agent_id'=>$agent_data->id,
                                        'payment'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'received_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('Agents_detail')->where('id',$agent_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
                        
                        if($ctr_res == 'Customer'){
                            
                             $customer_data = DB::table('booking_customers')->where('id',$request_data->content_ids[$index])->select('id','balance','name')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $customer_data->balance - $request_data->amount[$index];
                            
                            
                            
                             
                                    DB::table('customer_ledger')->insert([
                                        'booking_customer'=>$customer_data->id,
                                        'payment'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'received_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('booking_customers')->where('id',$customer_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
        
                        // if($ctr_res == 'Account'){
                        //     // Update Account Balance
                        //     $accountBal = CashAccountsBal::where('account_id',$request->content_ids[$index])->first();
                        //     $updatedBalanceAcc = $accountBal->balance -  $request->amount[$index];
                        //     $accountBal->balance = $updatedBalanceAcc;
                        //     $accountBal->save();
                            
                        //     // Insert Account Ledeger 
                        //     $CashAccledgerObj = new CashAccountledger;
                        //     $CashAccledgerObj->payment =  $request->amount[$index];
                        //     $CashAccledgerObj->account_id = $request->content_ids[$index];
                        //     $CashAccledgerObj->balance = $updatedBalanceAcc;
                        //     $CashAccledgerObj->recevied_id = $paymentObj->id;
                        //     $CashAccledgerObj->user_id = Auth::user()->id;
                        //     $CashAccledgerObj->save();
        
                        // }
        
                        // if($ctr_res == 'Customer'){
                        //     // Update Custoemr Balance 
                        //         $CustomerBal = CustomerBalance::where('customer_id',$request->content_ids[$index])->first();
                        //         $custUpdatedBalance = $CustomerBal->balance -  $request->amount[$index];
                        //         $CustomerBal->balance = $custUpdatedBalance;
                        //         $CustomerBal->save();
                        //     // Insert Customer Ledeger 
                        //     $CustomerledgerObj = new Customerledger;
                        //     $CustomerledgerObj->payment = $request->amount[$index];
                        //     $CustomerledgerObj->customer_id = $request->content_ids[$index];
                        //     $CustomerledgerObj->balance = $custUpdatedBalance;
                        //     $CustomerledgerObj->recevied_id = $paymentObj->id;
                        //     $CustomerledgerObj->user_id = Auth::user()->id;
                        //     $CustomerledgerObj->save();
                        // }
                    }
                    // Update Account Balance 
                    
                    
                    $cash_account_data = DB::table('cash_accounts')->where('id',$request_data->payment_from)->select('id','balance','name')->first();
        
                     $updatedBalance =  $cash_account_data->balance + $request_data->total_payments;
                     
                      DB::table('cash_accountledgers')->insert([
                                        'account_id'=>$cash_account_data->id,
                                        'received'=>$request_data->total_payments,
                                        'balance'=>$updatedBalance,
                                        'recevied_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>date('Y-m-d'),
                                        ]);
                                        
                    DB::table('cash_accounts')->where('id',$cash_account_data->id)->update(['balance'=>$updatedBalance]);
        
                    DB::commit();
                    
                    // die;
                        return response()->json([
                            'status'=>'success',
                        ]);
                    
                } catch (\PDOException $e) {
                    // Woopsy
                    echo $e;
                    DB::rollBack();
                  
                    return response()->json(['error'=>'Something Went Wrong Try Again']);
                }
        
            
        //     print_r($request_data);
        //   foreach($request_data->criteria as $index => $ctr_res){
        //     if($ctr_res == 'Agent'){
        //             // Payment Person is Agent
        //             // echo "Enter here ";
        //             $agent_data = DB::table('Agents_detail')->where('id',$request_data->content_ids[$index])->select('id','balance','agent_Name')->first();
        //             // $agent_data = DB::table('Agents_detail')->get();
                    
        //             print_r($agent_data);
        //         }
        //     }
            
            // return response()->json([
            //     'status'=>'success',
            //     'cash_accounts'=>$accounts_data,
            //     'agents'=>$agents_data
            // ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    public function payments_add_submit(Request $request){
        // print_r($request->all());
        $request_data = json_decode($request->request_data);
        
        // print_r($request_data);
        // die;
        $userData = CustomerSubcription::where('Auth_key',$request->token)
                                            ->where('status',1)
                                            ->select('id','status')->first();
        if($userData){
            
            $total_payments = 0;
            
            foreach($request_data->amount as $pay_res){
                $total_payments += $pay_res;
            }
            
             DB::beginTransaction();
                try {
                    // Insert Payment in Table 
                    $paymentObj = new Payments;
                    $paymentObj->date = $request_data->current_date;
                    $paymentObj->prev_balance = $request_data->account_prev_bal;
                    $paymentObj->updated_balance = $request_data->updated_balnc;
                    $paymentObj->total_payments = $total_payments;
                    $paymentObj->Criteria = json_encode($request_data->criteria);
                    $paymentObj->Content = json_encode($request_data->content);
                    $paymentObj->Content_Ids = json_encode($request_data->content_ids);
                    $paymentObj->Amount = json_encode($request_data->amount);
                    $paymentObj->remarks = json_encode($request_data->remarks);
                    $paymentObj->payment_from = $request_data->payment_from;
                    $paymentObj->customer_id = $userData->id;
                    $paymentObj->save();
        
                    foreach($request_data->criteria as $index => $ctr_res){
                        if($ctr_res == 'Agent'){
                            
                             $agent_data = DB::table('Agents_detail')->where('id',$request_data->content_ids[$index])->select('id','balance','agent_Name')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $agent_data->balance + $request_data->amount[$index];
                            
                            
                            
                             
                                    DB::table('agents_ledgers_new')->insert([
                                        'agent_id'=>$agent_data->id,
                                        'received'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('Agents_detail')->where('id',$agent_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
                        
                        if($ctr_res == 'Customer'){
                            
                             $customer_data = DB::table('booking_customers')->where('id',$request_data->content_ids[$index])->select('id','balance','name')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $customer_data->balance + $request_data->amount[$index];
                            
                            
                            
                             
                                    DB::table('customer_ledger')->insert([
                                        'booking_customer'=>$customer_data->id,
                                        'received'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('booking_customers')->where('id',$customer_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
                        
                        if($ctr_res == 'Hotel Supplier'){
                            
                             $supplier_data = DB::table('rooms_Invoice_Supplier')->where('id',$request_data->content_ids[$index])->select('id','balance','payable')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $supplier_data->balance - $request_data->amount[$index];
                            $updatedPayable = $supplier_data->payable - $request_data->amount[$index];
                            
                            
                            
                             
                                    DB::table('hotel_supplier_ledger')->insert([
                                        'supplier_id'=>$supplier_data->id,
                                        'received'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'payable_balance'=>$updatedPayable,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('rooms_Invoice_Supplier')->where('id',$supplier_data->id)->update(['balance'=>$updatedBalance,'payable'=>$updatedPayable]);
                         
                        }
                        
                        if($ctr_res == 'Flight Supplier'){
                            
                             $supplier_data = DB::table('supplier')->where('id',$request_data->content_ids[$index])->select('id','balance')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $supplier_data->balance - $request_data->amount[$index];

                            
                            
                             
                                    DB::table('flight_supplier_ledger')->insert([
                                        'supplier_id'=>$supplier_data->id,
                                        'received'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('supplier')->where('id',$supplier_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
                        
                        if($ctr_res == 'Transfer Supplier'){
                            
                             $supplier_data = DB::table('transfer_Invoice_Supplier')->where('id',$request_data->content_ids[$index])->select('id','balance')->first();
                            // $AgentBal = AgentBalance::where('agent_id',$request->content_ids[$index])->first();
                            $updatedBalance = $supplier_data->balance - $request_data->amount[$index];

                            
                            
                             
                                    DB::table('transfer_supplier_ledger')->insert([
                                        'supplier_id'=>$supplier_data->id,
                                        'received'=>$request_data->amount[$index],
                                        'balance'=>$updatedBalance,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        'remarks'=>$request_data->remarks[$index],
                                        ]);
                            
                                    DB::table('transfer_Invoice_Supplier')->where('id',$supplier_data->id)->update(['balance'=>$updatedBalance]);
                         
                        }
        
                        // if($ctr_res == 'Account'){
                        //     // Update Account Balance
                        //     $accountBal = CashAccountsBal::where('account_id',$request->content_ids[$index])->first();
                        //     $updatedBalanceAcc = $accountBal->balance -  $request->amount[$index];
                        //     $accountBal->balance = $updatedBalanceAcc;
                        //     $accountBal->save();
                            
                        //     // Insert Account Ledeger 
                        //     $CashAccledgerObj = new CashAccountledger;
                        //     $CashAccledgerObj->payment =  $request->amount[$index];
                        //     $CashAccledgerObj->account_id = $request->content_ids[$index];
                        //     $CashAccledgerObj->balance = $updatedBalanceAcc;
                        //     $CashAccledgerObj->recevied_id = $paymentObj->id;
                        //     $CashAccledgerObj->user_id = Auth::user()->id;
                        //     $CashAccledgerObj->save();
        
                        // }
        
                        // if($ctr_res == 'Customer'){
                        //     // Update Custoemr Balance 
                        //         $CustomerBal = CustomerBalance::where('customer_id',$request->content_ids[$index])->first();
                        //         $custUpdatedBalance = $CustomerBal->balance -  $request->amount[$index];
                        //         $CustomerBal->balance = $custUpdatedBalance;
                        //         $CustomerBal->save();
                        //     // Insert Customer Ledeger 
                        //     $CustomerledgerObj = new Customerledger;
                        //     $CustomerledgerObj->payment = $request->amount[$index];
                        //     $CustomerledgerObj->customer_id = $request->content_ids[$index];
                        //     $CustomerledgerObj->balance = $custUpdatedBalance;
                        //     $CustomerledgerObj->recevied_id = $paymentObj->id;
                        //     $CustomerledgerObj->user_id = Auth::user()->id;
                        //     $CustomerledgerObj->save();
                        // }
                    }
                    // Update Account Balance 
                    
                    
                    $cash_account_data = DB::table('cash_accounts')->where('id',$request_data->payment_from)->select('id','balance','name')->first();
        
                     $updatedBalance =  $cash_account_data->balance - $total_payments;
                     
                      DB::table('cash_accountledgers')->insert([
                                        'account_id'=>$cash_account_data->id,
                                        'payment'=>$total_payments,
                                        'balance'=>$updatedBalance,
                                        'payment_id'=>$paymentObj->id,
                                        'customer_id'=>$userData->id,
                                        'date'=>$request_data->current_date,
                                        ]);
                                        
                    DB::table('cash_accounts')->where('id',$cash_account_data->id)->update(['balance'=>$updatedBalance]);
        
                    DB::commit();
                    
                    // die;
                        return response()->json([
                            'status'=>'success',
                        ]);
                    
                } catch (\PDOException $e) {
                    // Woopsy
                    echo $e;
                    DB::rollBack();
                     return response()->json([
                            'status'=>'error',
                        ]);
                    // return redirect()->back()->with(['error'=>'Something Went Wrong Try Again']);
                }
        
            
        //     print_r($request_data);
        //   foreach($request_data->criteria as $index => $ctr_res){
        //     if($ctr_res == 'Agent'){
        //             // Payment Person is Agent
        //             // echo "Enter here ";
        //             $agent_data = DB::table('Agents_detail')->where('id',$request_data->content_ids[$index])->select('id','balance','agent_Name')->first();
        //             // $agent_data = DB::table('Agents_detail')->get();
                    
        //             print_r($agent_data);
        //         }
        //     }
            
            // return response()->json([
            //     'status'=>'success',
            //     'cash_accounts'=>$accounts_data,
            //     'agents'=>$agents_data
            // ]);
        }else{
            return response()->json([
                'status'=>'validation_error',
                'data'=>''
            ]);
        }
    }
    
    
}
