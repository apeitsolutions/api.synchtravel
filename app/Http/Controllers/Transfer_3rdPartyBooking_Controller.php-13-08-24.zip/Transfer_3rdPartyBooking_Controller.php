<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Carbon\Carbon;
use Session;
use DB;
use Validator;
use Stripe;

class Transfer_3rdPartyBooking_Controller extends Controller
{
    public function search_Transfer_Api_static(){
        $data_request = '<TCOML version="NEWFORMAT">
                            <TransferOnly>
                                <P2PAvailability>
                                    <Request>
                                        <Username>Ape12345</Username>
                                        <Password>Ape12345</Password>
                                        <Lang>EN</Lang>
                                        <LatitudeP1>39.5517448</LatitudeP1>
                                        <LongitudeP1>2.7339762</LongitudeP1>
                                        <LatitudeP2>39.485644</LatitudeP2>
                                        <LongitudeP2>2.905978</LongitudeP2>
                                        <PlaceFrom>Mallorca Airport(PMI)</PlaceFrom>
                                        <PlaceTo>Finca Can Titos, Lluchmajor</PlaceTo>
                                        <CountryCodeFrom>ES</CountryCodeFrom>
                                        <CountryCodeTo>ES</CountryCodeTo>
                                        <IsReturn>1</IsReturn>
                                        <ArrDate>15/02/2024</ArrDate>
                                        <ArrTime>1000</ArrTime>
                                        <RetDate>18/02/2024</RetDate>
                                        <RetTime>1000</RetTime>
                                        <Adults>1</Adults>
                                        <Children>0</Children>
                                        <Infants>0</Infants>
                                        <ResponseType>0</ResponseType>
                                        <CalcJ1PickupTime>1</CalcJ1PickupTime>
                                        <CalcJ2PickupTime>1</CalcJ2PickupTime>
                                        <GoogleAPIKey></GoogleAPIKey>
                                    </Request>
                                </P2PAvailability>
                            </TransferOnly>
                        </TCOML>';
        
        
        $data_request1 = '<TCOML version="NEWFORMAT">
                            <TransferOnly>
                                <P2PAvailability>
                                    <Request>
                                        <Username>Ape12345</Username>
                                        <Password>Ape12345</Password>
                                        <Lang>EN</Lang>
                                        <LatitudeP1>41.2974433898926</LatitudeP1>
                                        <LongitudeP1>2.0832941532135</LongitudeP1>
                                        <LatitudeP2>41.3770366</LatitudeP2>
                                        <LongitudeP2>2.1888715</LongitudeP2>
                                        <PlaceFrom>Barcelona El Prat Airport (BCN)</PlaceFrom>
                                        <PlaceTo>Hotel 54 Barceloneta, Passeig de Joan de Borbo, Barcelona, Spain</PlaceTo>
                                        <IsReturn>1</IsReturn>
                                        <ArrDate>2024-06-12</ArrDate>
                                        <ArrTime>1200</ArrTime>
                                        <RetDate>2024-06-19</RetDate>
                                        <RetTime>1200</RetTime>
                                        <Adults>1</Adults>
                                        <Children>0</Children>
                                        <Infants>0</Infants>
                                        <Deposit>1</Deposit>
                                        <CountryCodeFrom>ES</CountryCodeFrom>
                                        <CountryCodeTo>ES</CountryCodeTo>
                                        <ProductType>0</ProductType>
                                        <ResponseType>0</ResponseType>
                                        <ChannelFlag>1</ChannelFlag>
                                        <CalcJ1PickupTime>1</CalcJ1PickupTime>
                                        <CalcJ2PickupTime>1</CalcJ2PickupTime>
                                    </Request>
                                </P2PAvailability>
                            </TransferOnly>
                        </TCOML>';
        
        // return $data_request1;
        
        $url        = "http://test.xmlp2p.com/xml/";
        $timeout    = 7;
        $data       = array('xml' => $data_request1);
        $headers    = array("Content-type: application/x-www-form-urlencoded");
        $ch = curl_init();
        $payload = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        return $response;
        curl_close($ch);
        
        $xml    = simplexml_load_string($response);
        $json   = json_encode($xml, JSON_PRETTY_PRINT);
        $json   = stripslashes($json);
        $json   = json_decode($json);
        
        return $json;
        
        try {
            $sessionID = $json->TransferOnly->P2PResults->SessionID;
        }catch (\Throwable $th) {
            return 'Error Catch';
        }
        
        $details    = $json->TransferOnly->P2PResults->Request;
        $trans      = $json->TransferOnly->P2PResults->Response->Transfers->Transfer;
        $tranfer_Ar = [
                        'trans'     => $trans,
                        'details'   => $details,
                        ];
        return $tranfer_Ar;
        
        // return view('trasnfers', compact('trans', 'sessionID'));
    }
    
    public function search_Transfer_Api($req){
        // dd($req);
        
        //Start Latitude and longitude
        $startlatlng    = $req->startName;
        $startlatlng    = explode(',', $startlatlng);
        $startlat       = $startlatlng[0];
        if(isset($startlatlng[1])){
            $startlng = $startlatlng[1];
        }else{
            $startlng = $startlat;
        }
        
        //destination Latitude and longitude
        $destinationlatlng  = $req->destinationName;
        $destinationlatlng  = explode(',', $destinationlatlng);
        $destinationlat     = $destinationlatlng[0];
        if(isset($destinationlatlng[1])){
            $destinationlng = $destinationlatlng[1];
        }else{
            $destinationlng = $destinationlat;
        }
        
        //Trip type Round(1) or one way(0)
        if ($req->trip_type == 'One-Way') {
            $tyriptype =  0;
        }else{
            $tyriptype =  1;
        }
        
        //star place name
        $startplacename         = $req->startplacename;
        $destinationplacename   = $req->destinationplacename;
        // dd($req,$startplacename,$destinationplacename);
        
        $countryList            = country_Codes();
        
        $countryname            =  $req->startplacecountrycode;
        $countrycodestart       = get_Country_Codes($countryname, $countryList);
        
        $countryname            = $req->destinationplacenamecountrycode;
        $countrycodedestination = get_Country_Codes($countryname, $countryList);
        
        //Arival date and time
        $arrdate    =  $req->pick_up_date;
        $timestamp  = strtotime($arrdate);
        $arrdate    = date('d/m/Y', $timestamp);
        
        $arrtime    = $req->arrtime;
        $timestamp  = strtotime($arrtime);
        $arrtime    = date("Hi", $timestamp);
        
        $retdate    = $req->retdate;
        $timestamp  = strtotime($retdate);
        $retdate    = date('d/m/Y', $timestamp);
        
        $rettime    = $req->rettime;
        $timestamp  = strtotime($rettime);
        $rettime    = date("Hi", $timestamp);
        
        $childerns  = $req->childerns ?? '0';
        $infants    = $req->infants ?? '0';
        $adults     = $req->passenger ?? '';
        
        $data_request = '<TCOML version="NEWFORMAT">
                            <TransferOnly>
                                <P2PAvailability>
                                    <Request>
                                        <Username>Ape12345</Username>
                                        <Password>Ape12345</Password>
                                        <Lang>EN</Lang>
                                        <LatitudeP1>' . $startlat . '</LatitudeP1>
                                        <LongitudeP1>' . $startlng . '</LongitudeP1>
                                        <LatitudeP2>' . $destinationlat . '</LatitudeP2>
                                        <LongitudeP2>' . $destinationlng . '</LongitudeP2>
                                        <PlaceFrom>' . $startplacename . '</PlaceFrom>
                                        <PlaceTo>' . $destinationplacename . '</PlaceTo>
                                        <IsReturn>' . $tyriptype . '</IsReturn>
                                        <ArrDate>' . $arrdate . '</ArrDate>
                                        <ArrTime>' .  $arrtime . '</ArrTime>
                                        <RetDate>' . $retdate . '</RetDate>
                                        <RetTime>' . $rettime . '</RetTime>
                                        <Adults>' .   $adults . '</Adults>
                                        <Children>' . $childerns . '</Children>
                                        <Infants>' . $infants . '</Infants>
                                        <Deposit>1</Deposit>
                                        <CountryCodeFrom>' . $countrycodestart . '</CountryCodeFrom>
                                        <CountryCodeTo>' .  $countrycodedestination . '</CountryCodeTo>
                                        <ProductType>0</ProductType>
                                        <ChannelFlag>1</ChannelFlag>
                                        <ResponseType>0</ResponseType>
                                        <CalcJ1PickupTime>1</CalcJ1PickupTime>
                                        <CalcJ2PickupTime>1</CalcJ2PickupTime>
                                    </Request>
                                </P2PAvailability>
                            </TransferOnly>
                        </TCOML>';
        
        // return $data_request;
        $url        = "http://test.xmlp2p.com/xml/";
        $timeout    = 7;
        $data       = array('xml' => $data_request);
        $headers    = array("Content-type: application/x-www-form-urlencoded");
        $ch         = curl_init();
        $payload    = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response   = curl_exec($ch);
        // return $data_request.' '.$response;
        curl_close($ch);
        
        $xml    = simplexml_load_string($response);
        $json   = json_encode($xml, JSON_PRETTY_PRINT);
        $json   = stripslashes($json);
        // echo $json;die;
        $json_decode   = json_decode($json);
        // return $json_decode;
        
        try {
            $sessionID = $json_decode->TransferOnly->P2PResults->SessionID;
        }catch (\Throwable $th) {
            return 'Error Catch';
        }
        
        $details    = $json_decode->TransferOnly->P2PResults->Request;
        $trans      = $json_decode->TransferOnly->P2PResults->Response->Transfers->Transfer;
        $tranfer_Ar = [
                        'sessionID' => $sessionID,
                        'trans'     => $trans,
                        'details'   => $details,
                        ];
        // Session::put('sessionID',$sessionID);
        return $tranfer_Ar;
    }
    
    public function book_Transfer_Api(Request $req){
        $bookingid      = $req->bookingid;
        $sessionID      = $req->sessionID;
        // $sessionID      = Session::get('sessionID');
        $data_request   =   '<TCOML version="NEWFORMAT">
                                <TransferOnly>
                                    <Booking>
                                        <P2PReserve>
                                            <Username>Ape12345</Username>
                                            <Password>Ape12345</Password>
                                            <SessionID>' . $sessionID . '</SessionID>
                                            <BookingID>' . $bookingid . '</BookingID>
                                        </P2PReserve>
                                    </Booking>
                                </TransferOnly>
                            </TCOML>';
        // return $data_request; 
        $url        = "http://test.xmlp2p.com/xml/";
        $timeout    = 7;
        $data       = array('xml' => $data_request);
        $headers    = array("Content-type: application/x-www-form-urlencoded");
        $ch         = curl_init();
        $payload    = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response   = curl_exec($ch);
        // return $data_request.' '.$response;
        curl_close($ch);
        
        $xml                = simplexml_load_string($response);
        $json               = json_encode($xml, JSON_PRETTY_PRINT);
        $json               = stripslashes($json);
        $data               = json_decode($json);
        // return $data;
        
        if (isset($data->TransferOnly->P2PResults->Reserve)) {
            $transactionNumber  = $data->TransferOnly->P2PResults->Reserve->Response->TransacNo;
            return response()->json(['message'=>'Success','transactionNumber'=>$transactionNumber]);
        }else{
            return response()->json(['error'=>$data->TransferOnly->P2PResults ?? 'Something Went Wrong']);
        }
        
        $transactionNumber  = $data->TransferOnly->P2PResults->Reserve->Response->TransacNo;
        // Session::put('transactionNumber',$transactionNumber);
        return response()->json(['message'=>'Success','transactionNumber'=>$transactionNumber]);
    }
    
    public function search_Disclaimer_Transfer_Api($bookingid,$sessionID){
        // $bookingid      = $req->bookingid;
        // $sessionID      = $req->sessionID;
        // $sessionID      = Session::get('sessionID');
        $data_request   =   '<TCOML version="NEWFORMAT">
                                 <TransferOnly>
                                    <Info>
                                        <Disclaimer>
                                            <Username>Ape12345</Username>
                                            <Password>Ape12345</Password>
                                            <Lang>EN</Lang>
                                            <SessionID>' . $sessionID . '</SessionID>
                                            <BookingID>' . $bookingid . '</BookingID>
                                        </Disclaimer>
                                    </Info>
                                </TransferOnly>
                            </TCOML>';
        // return $data_request;
        $url        = "http://test.xmlp2p.com/xml/";
        $timeout    = 7;
        $data       = array('xml' => $data_request);
        $headers    = array("Content-type: application/x-www-form-urlencoded");
        $ch         = curl_init();
        $payload    = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response   = curl_exec($ch);
        return $response;
        curl_close($ch);
        
        $xml                = simplexml_load_string($response);
        $json               = json_encode($xml, JSON_PRETTY_PRINT);
        $json               = stripslashes($json);
        $data               = json_decode($json);
        // return $data;
        
        return response()->json(['message'=>'success','data'=>$data]);
    }
    
    public function confbook_Transfer_Api(Request $request){
        $req                    = json_decode($request->confirm_Booking_Arr);
        $countryList            = country_Codes();
        $country                = $req->country;
        $countrycodes           = get_Country_Codes($country, $countryList);
        $propertyName           = $req->propertyname;
        $j1PropertyName         = $req->j1propertyname;
        $accomodationAddress    = $req->accomodationaddress;
        $depPoint               = $req->deppoint;
        $depinfo                = $req->depinfo;
        $transactionNumber      = $req->transactionnumber;
        $title                  = $req->title;
        $firstName              = $req->firstname;
        $lastName               = $req->lastname;
        $email                  = $req->email;
        $phone                  = $req->phone;
        $mobile                 = $req->mobile;
        
        $data_request = '<TCOML version="NEWFORMAT" sess="">
                            <TransferOnly>
                                <Booking>
                                    <P2PConfirm>
                                        <Username>Ape12345</Username>
                                        <Password>Ape12345</Password>
                                        <TransacNo>' . $transactionNumber . '</TransacNo>
                                        <ExtrasTransacNo>
                                        
                                        </ExtrasTransacNo>
                                        <AgentBref></AgentBref>
                                        <PropertyName>Hotel Name</PropertyName>
                                        <AccommodationAddress>
                                        Hotel Address
                                        </AccommodationAddress>
                                        <AccommodationAddress2>LHR
                                        </AccommodationAddress2>
                                        <J1_PropertyName></J1_PropertyName>
                                        <J1_AccommodationAddress>
                                        LHR
                                        </J1_AccommodationAddress>
                                        
                                        <J1_AccommodationAddress2>
                                        LHR
                                        </J1_AccommodationAddress2>
                                        <DepPoint>LH</DepPoint>
                                        <RetPoint>LHR</RetPoint>
                                        <DepInfo>L942348</DepInfo>
                                        <RetInfo>L572105</RetInfo>
                                        <DepExtraInfo>EMIRATES</DepExtraInfo>
                                        <RetExtraInfo>EMIRATES</RetExtraInfo>
                                        <Client>
                                            <LastName>' . $lastName . '</LastName>
                                            <FirstName>' . $firstName . '</FirstName>
                                            <Title>' . $title . '</Title>
                                            <Phone>03017188122</Phone>
                                            <Mobile>03017188122</Mobile>
                                            <CountryCode>' . $countrycodes . '</CountryCode>
                                            <Email>' . $email . '</Email>
                                        </Client>
                                        <J1_IATA_Airline>U2</J1_IATA_Airline>
                                        <J2_IATA_Airline>U2</J2_IATA_Airline>
                                        <SendEmailToCustomer>0</SendEmailToCustomer>
                                        <Remark></Remark>
                                        <WA_Flag>1</WA_Flag>
                                    </P2PConfirm>
                                </Booking>
                            </TransferOnly>
                        </TCOML>';
        // return $data_request;
        $url        = "http://test.xmlp2p.com/xml/";
        $timeout    = 7;
        $data       = array('xml' => $data_request);
        $headers    = array("Content-type: application/x-www-form-urlencoded");
        $ch         = curl_init();
        $payload    = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        // return $data_request.' '.$response;
        curl_close($ch);
        
        $xml    = simplexml_load_string($response);
        $json   = json_encode($xml, JSON_PRETTY_PRINT);
        $json   = stripslashes($json);
        $data   = json_decode($json, true);
        // return $data;
        
        if ($data === false){
            return response()->json(['error'=>'Vehical is already booked please select an other']);
        }
        
        if (isset($data['TransferOnly']['P2PResults']['errors']['error']['text'])) {
            $errorMessage = $data['TransferOnly']['P2PResults']['errors']['error']['text'];
            return response()->json(['error'=>$errorMessage]);
        }
        
        return response()->json(['message'=>'success','data'=>$data]);
    }
}