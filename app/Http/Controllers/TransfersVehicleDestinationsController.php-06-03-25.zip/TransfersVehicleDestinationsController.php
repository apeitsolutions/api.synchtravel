<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Carbon\Carbon;
use DB;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\booking_customers;
use Hash;
use App\Http\Controllers\Transfer_3rdPartyBooking_Controller;

class TransfersVehicleDestinationsController extends Controller
{
    public function vehicle_Destination_Listing(Request $request){
        try {
            // Validate Token
            $userData = CustomerSubcription::where('Auth_key', $request->token)->select('id', 'status', 'dashboard_Address')->first();
            if (!$userData) {
                return response()->json(['message' => 'error', 'vehicles_list' => '']);
            }
            
            // Fetch all vehicles
            $vehicles_list = DB::table('tranfer_vehicle')->where('customer_id', $userData->id)->get();
            if ($vehicles_list->isEmpty()) {
                return response()->json(['message' => 'error', 'vehicles_list' => []]);
            }
            
            // Fetch all transfer details
            $transfer_Details = DB::table('tranfer_destination')->where('customer_id', $userData->id)->get();
            
            // Process vehicle list
            foreach ($vehicles_list as $vehicle) {
                $available_Pax  = isset($vehicle->pax_Booked) && $vehicle->pax_Booked > 0 ? $vehicle->vehicle_Passenger - $vehicle->pax_Booked : $vehicle->vehicle_Passenger;
                
                // Set Vehicle Image URL
                $vehicle->Vehicel_Image_URL = $userData->dashboard_Address . '/public/uploads/package_imgs/' . $vehicle->vehicle_image;
                
                $all_Transfer_Details = [];
                
                foreach ($transfer_Details as $val_TD) {
                    if (empty($val_TD->vehicle_details)) {
                        continue;
                    }
                    
                    // Decode JSON safely
                    $vehicle_details_Decoded = json_decode($val_TD->vehicle_details);
                    
                    if (!is_array($vehicle_details_Decoded)) {
                        continue; // Skip if JSON decoding fails
                    }
                    
                    foreach ($vehicle_details_Decoded as $vehicle_details) {
                        if (!isset($vehicle_details->display_on_website) || $vehicle_details->display_on_website !== 'true') {
                            continue;
                        }
                        
                        if ($vehicle->id != $vehicle_details->vehicle_id) {
                            continue;
                        }
                        
                        $transfer_List_Item = (object)[
                            // Destination Details
                            'destination_Id'            => $val_TD->id,
                            'pickup_Date'               => $val_TD->available_from,
                            'dropof_Date'               => $val_TD->available_to,
                            'pickup_City'               => $val_TD->pickup_City,
                            'dropof_City'               => $val_TD->dropof_City,
                            'return_Pickup_City'        => $val_TD->return_pickup_City,
                            'return_Dropof_City'        => $val_TD->return_dropof_City,
                            'more_Destination_Details'  => $val_TD->more_destination_details,
                            'ziyarat_City_Details'      => $val_TD->ziyarat_City_details,
                            'transfer_Type'             => $val_TD->transfer_type,
                            // Supplier Details
                            'supplier_Id'               => $vehicle_details->transfer_supplier_Id ?? null,
                            'supplier_Name'             => $vehicle_details->transfer_supplier ?? null,
                            // Vehicle Price Details
                            'vehicle_Price'             => $vehicle_details->vehicle_Fare ?? 0,
                            'vehicle_Markup_Type'       => $vehicle_details->fare_markup_type ?? null,
                            'vehicle_Markup_Value'      => $vehicle_details->fare_markup ?? 0,
                            'vehicle_Exchange_Rate'     => $vehicle_details->exchange_Rate ?? 1,
                            'vehicle_Total_Price'       => $vehicle_details->total_fare_markup ?? 0,
                            'vehicle_Currency_Symbol'   => $vehicle_details->currency_symbol ?? null,
                            // Conversion Details
                            'conversion_Id'             => $val_TD->conversion_type_Id ?? null,
                            'conversion_Name'           => $val_TD->currency_conversion ?? null,
                        ];
                        
                        if ($available_Pax > 0) {
                            $all_Transfer_Details[] = $transfer_List_Item;
                        }
                    }
                }
                
                $vehicle->destinations_Details = $all_Transfer_Details;
            }
            
            return response()->json(['message' => 'success', 'vehicles_list' => $vehicles_list]);
        } catch (\Exception $e) {
            return response()->json(['message' => 'error', 'vehicles_list' => [], 'error' => $e->getMessage()]);
        }
    }
    
    public function vehicle_Destination_Detailing(Request $request){
        try {
            // Validate Token
            $userData = CustomerSubcription::where('Auth_key', $request->token)->select('id', 'status', 'dashboard_Address')->first();
            if (!$userData) {
                return response()->json(['message' => 'error', 'vehicles_list' => '']);
            }
            
            // Fetch all vehicles
            $vehicles_list = DB::table('tranfer_vehicle')->where('customer_id', $userData->id)->where('id', $request->vehicle_id)->get();
            if ($vehicles_list->isEmpty()) {
                return response()->json(['message' => 'error', 'vehicles_list' => []]);
            }
            
            // Fetch all transfer details
            $transfer_Details = DB::table('tranfer_destination')->where('customer_id', $userData->id)->get();
            
            // Process vehicle list
            foreach ($vehicles_list as $vehicle) {
                $available_Pax  = isset($vehicle->pax_Booked) && $vehicle->pax_Booked > 0 ? $vehicle->vehicle_Passenger - $vehicle->pax_Booked : $vehicle->vehicle_Passenger;
                
                // Set Vehicle Image URL
                $vehicle->Vehicel_Image_URL = $userData->dashboard_Address . '/public/uploads/package_imgs/' . $vehicle->vehicle_image;
                
                $all_Transfer_Details = [];
                
                foreach ($transfer_Details as $val_TD) {
                    if (empty($val_TD->vehicle_details)) {
                        continue;
                    }
                    
                    // Decode JSON safely
                    $vehicle_details_Decoded = json_decode($val_TD->vehicle_details);
                    
                    if (!is_array($vehicle_details_Decoded)) {
                        continue; // Skip if JSON decoding fails
                    }
                    
                    foreach ($vehicle_details_Decoded as $vehicle_details) {
                        if (!isset($vehicle_details->display_on_website) || $vehicle_details->display_on_website !== 'true') {
                            continue;
                        }
                        
                        if ($vehicle->id != $vehicle_details->vehicle_id) {
                            continue;
                        }
                        
                        $transfer_List_Item = (object)[
                            // Destination Details
                            'destination_Id'            => $val_TD->id,
                            'pickup_Date'               => $val_TD->available_from,
                            'dropof_Date'               => $val_TD->available_to,
                            'pickup_City'               => $val_TD->pickup_City,
                            'dropof_City'               => $val_TD->dropof_City,
                            'return_Pickup_City'        => $val_TD->return_pickup_City,
                            'return_Dropof_City'        => $val_TD->return_dropof_City,
                            'more_Destination_Details'  => $val_TD->more_destination_details,
                            'ziyarat_City_Details'      => $val_TD->ziyarat_City_details,
                            'transfer_Type'             => $val_TD->transfer_type,
                            // Supplier Details
                            'supplier_Id'               => $vehicle_details->transfer_supplier_Id ?? null,
                            'supplier_Name'             => $vehicle_details->transfer_supplier ?? null,
                            // Vehicle Price Details
                            'vehicle_Price'             => $vehicle_details->vehicle_Fare ?? 0,
                            'vehicle_Markup_Type'       => $vehicle_details->fare_markup_type ?? null,
                            'vehicle_Markup_Value'      => $vehicle_details->fare_markup ?? 0,
                            'vehicle_Exchange_Rate'     => $vehicle_details->exchange_Rate ?? 1,
                            'vehicle_Total_Price'       => $vehicle_details->total_fare_markup ?? 0,
                            'vehicle_Currency_Symbol'   => $vehicle_details->currency_symbol ?? null,
                            // Conversion Details
                            'conversion_Id'             => $val_TD->conversion_type_Id ?? null,
                            'conversion_Name'           => $val_TD->currency_conversion ?? null,
                        ];
                        
                        if ($available_Pax > 0) {
                            $all_Transfer_Details[] = $transfer_List_Item;
                        }
                    }
                }
                
                $vehicle->destinations_Details = $all_Transfer_Details;
            }
            
            return response()->json(['message' => 'success', 'vehicles_list' => $vehicles_list]);
        } catch (\Exception $e) {
            return response()->json(['message' => 'error', 'vehicles_list' => [], 'error' => $e->getMessage()]);
        }
    }
    
    public function vehicle_Destination_Confirm_Booking(Request $request){
        $transfer_data          = json_decode($request->transfer_data);
        $lead_passenger         = $transfer_data->lead_passenger_details;
        $transfer_destination   = json_decode($request->transfer_destination_data);
        $transfer_price_data    = $transfer_data->transfer_price_details;
        $hotel_booked           = false;
        if(isset($request->hotel_booked)){
            $hotel_booked       = true;
        }
        DB::beginTransaction();
        try {   
                if(isset($request->booking_From) && $request->booking_From != ''){
                    $booking_From                       = '3rd Party Apis';
                }else{
                    $booking_From                       = NULL;
                }
                
                $userData                               = CustomerSubcription::where('Auth_key',$request->token)->select('id','status','hotel_Booking_Tag')->first();
                $booking_customer_id                    = "";
                $customer_exist                         = DB::table('booking_customers')->where('customer_id',$userData->id)->where('email',$lead_passenger->lead_email)->first();
                if(isset($customer_exist) && $customer_exist != null && $customer_exist != ''){
                    $booking_customer_id                = $customer_exist->id;
                }else{
                   
                    if($lead_passenger->lead_title == "Mr"){
                       $gender                          = 'male';
                    }else{
                        $gender                         = 'female';
                    }
                    
                    $password                           = Hash::make('admin123');
                    
                    $customer_detail                    = new booking_customers();
                    $customer_detail->name              = $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name;
                    $customer_detail->opening_balance   = 0;
                    $customer_detail->balance           = 0;
                    $customer_detail->email             = $lead_passenger->lead_email;
                    $customer_detail->password          = $password;
                    $customer_detail->phone             = $lead_passenger->lead_phone;
                    $customer_detail->gender            = $gender;
                    $customer_detail->country           = $lead_passenger->lead_country;
                    $customer_detail->customer_id       = $userData->id;
                    $result                             = $customer_detail->save();
                    $booking_customer_id = $customer_detail->id;
                }
                
                $randomNumber   = random_int(1000000, 9999999);
                if(isset($userData->hotel_Booking_Tag) && $userData->hotel_Booking_Tag != null && $userData->hotel_Booking_Tag != ''){
                    $invoiceId  = $userData->hotel_Booking_Tag.$randomNumber;
                }else{
                    $invoiceId  = $randomNumber;
                }
                
                if(isset($transfer_destination->vehicle_Id) && $transfer_destination->vehicle_Id > 0){
                    
                    if($transfer_destination->pax_Remaining > 0){
                        $pax_Remaining  = $transfer_destination->pax_Remaining - $transfer_destination->pax_To_Book;
                    }else{
                        $pax_Remaining  = $transfer_destination->pax_Total - $transfer_destination->pax_To_Book;
                    }
                    $pax_To_Book        = $transfer_destination->pax_Total - $pax_Remaining;
                    
                    DB::table('tranfer_vehicle')->where('id',$transfer_destination->vehicle_Id)->update([
                        'pax_Booked'    => $pax_To_Book,
                        'pax_Remaining' => $pax_Remaining,
                    ]);
                }
                
                DB::table('transfers_new_booking')->insert([
                    'invoice_no'                    => $invoiceId,
                    'booking_status'                => 'Confirmed',
                    'payment_method'                => $request->slc_pyment_method,
                    'departure_date'                => $transfer_destination->pickup_date,
                    'no_of_paxs'                    => $transfer_price_data->no_of_paxs_transfer,
                    'hotel_booked'                  => $hotel_booked,
                    'lead_passenger_data'           => json_encode($lead_passenger),
                    'other_passenger_data'          => json_encode($transfer_data->other_passenger_details),
                    'transfer_destination_id'       => $transfer_price_data->destination_avail_id,
                    'transfer_data'                 => $request->transfer_destination_data,
                    'transfer_price_exchange'       => $transfer_price_data->exchange_price_transfer,
                    'transfer_total_price_exchange' => $transfer_price_data->exchange_price_total_transfer,
                    'exchange_currency'             => $transfer_price_data->exchange_curreny_transfer ?? '',
                    'transfer_price'                => $transfer_destination->total_fare_markup,
                    'transfer_total_price'          => $transfer_price_data->original_price_total_transfer,
                    'currency'                      => $transfer_price_data->original_curreny_transfer,
                    'booking_customer_id'           => $booking_customer_id,
                    'lead_passenger'                => $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name,
                    'customer_id'                   => $userData->id,
                    'booking_From'                  => $booking_From,
                    'response_confirm_booking'      => $request->response_confirm_booking ?? '',
                ]);
                
                if($request->token == config('token_UmrahShop') || $request->token == config('token_HashimTravel')){
                    // return $request;
                    // $invoiceId          = 'AL111111';
                    // $status_RB          = 'Confirmed';
                    $check_Mail         = self::MailSend($request,$invoiceId);
                    // return $check_Mail;
                }
                
                DB::commit();
                return response()->json(['status'=>'success','Invoice_no'=>$invoiceId]);
        } catch (Throwable $e) {
             DB::rollback();
            echo $e;
            return response()->json(['message'=>'error','booking_id'=> '']);
        }
    }
}