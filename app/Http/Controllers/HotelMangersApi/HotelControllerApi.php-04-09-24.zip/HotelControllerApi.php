<?php

namespace App\Http\Controllers\HotelMangersApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\hotel_manager\Rooms;
use App\Models\admin\RoomsType;
use App\Models\hotel_manager\RoomGallery;
use App\Models\hotel_manager\Hotels;
use App\Models\MetaInfo;
use App\Models\Policies;
use App\Models\country;
use App\Models\city;
use Session;
use concat;
use Auth;
use DB;

class HotelControllerApi extends Controller
{
    public function hotels_fillters(Request $request){
    $hotel_city = $request->hotel_city;
    
    $hotels = Hotels::where('property_city',$hotel_city)
    ->where('owner_id',$request->customer_id)
    ->get();
    
    return response()->json([
    'hotels'=>'Hotels Are Found',
    'hotels_data' => $hotels,
    ]);
    
    }
    
    public function hotels_fillters_by_name(Request $request){
        $slc_hotel_name = $request->slc_hotel_name;
        
        $hotels = Hotels::where('property_name',$slc_hotel_name)->get();
        
        return response()->json([
        'hotels'=>'Hotels Are Found',
        'hotels_data' => $hotels,
        ]);
    
    } 
    
    public function getCurrentWeek(){
    
        $monday = strtotime("last monday");
        
        $monday = date('w', $monday)==date('w') ? $monday+(7*86400) : $monday;
        
        $sunday = strtotime(date("Y-m-d",$monday)." +6 days");
        
        $this_week_sd = date("Y-m-d",$monday);
        
        $this_week_ed = date("Y-m-d",$sunday);
        
        
        
        return $data = ['first_day' => $this_week_sd, 'last_day' => $this_week_ed];
    
    }
    
    public function hotel_arrival_list(){
        $date=date('Y-m-d');
        
        $year = date('Y') . '-12-31';
        
        $first_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-01')));
        
        $last_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-t')));
        $current_week = $this->getCurrentWeek();
        
        
        $arrival_detail_today= DB::table('hotel_booking')->orderBy('id', 'desc')->where('check_in','=',date('y-m-d'))->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','hotelbeddetailRQ')->get();
        $arrival_detail_week= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_in', [$current_week['first_day'],$current_week['last_day']])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','tbo_BookingDetail_rs','hotelbeddetailRQ')->get();
        $arrival_detail_this_month= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_in', [$first_day_of_this_month,$last_day_of_this_month])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','hotelbeddetailRQ')->get();
        
        
        
        return response()->json([
        'arrival_detail_today' => $arrival_detail_today,
        'arrival_detail_week' => $arrival_detail_week,
        'arrival_detail_this_month' => $arrival_detail_this_month,
        
        'first_day_this_week' => $current_week['first_day'],
        'last_day_this_week' => $current_week['last_day'],
        'first_day_of_this_month' => $first_day_of_this_month,
        'last_day_of_this_month' => $last_day_of_this_month,
        
        ]);
    }
    
    public function hotel_departure_list(){
        $date=date('Y-m-d');
        
        $year = date('Y') . '-12-31';
        
        $first_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-01')));
        
        $last_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-t')));
        $current_week = $this->getCurrentWeek();
        
        $arrival_detail_today= DB::table('hotel_booking')->orderBy('id', 'desc')->where('check_out','=',date('y-m-d'))->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        $arrival_detail_week= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_out', [$current_week['first_day'],$current_week['last_day']])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        $arrival_detail_this_month= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_out', [$first_day_of_this_month,$last_day_of_this_month])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        
        
        
        return response()->json([
        'departure_detail_today' => $arrival_detail_today,
        'departure_detail_week' => $arrival_detail_week,
        'departure_detail_this_month' => $arrival_detail_this_month,
        
        ]);
    }
    
    public function showeditHotelFrom(Request $request){
        $all_countries = country::all();
        
        $id = $request->customer_id;
        $hotel_id = $request->id;
        $user_hotels = Hotels::find($hotel_id);
        $MetaInfo =  MetaInfo::where('hotel_id',$hotel_id)->first();
        $Policies =  Policies::where('hotel_id',$hotel_id)->first();
        //   $user_hotels = Hotels::join('countries','hotels.property_country','=','countries.id')
        //                  ->join('cities','hotels.property_city','=','cities.name')
        //                  ->where('hotels.owner_id',$id)
        //                  ->orderBy('hotels.created_at', 'desc')
        //                  ->get(['hotels.*','countries.name','cities.name']);
        
        // $city_D     = DB::table('cities')->get();
        // dd($hotel_id);
        
        return response()->json([
            'all_countries' => $all_countries,
            'user_hotels' => $user_hotels,
            'MetaInfo' => $MetaInfo,
            'Policies' => $Policies,
            // 'city_D' => $city_D,
        ]);
        // return view('template/frontend/userdashboard/pages/hotel_manager.add_hotel',compact('all_countries'));
   }
    
    public function updateHotel(Request $request){
        $id     = $request->id;
        $hotel  = Hotels::find($id);
        if($hotel){
            // dd($request->property_country);
            
            $hotel->image_Url_Other_Dashboard =  NULL; 
            
            $hotel->property_name =  $request->property_name; 
            $hotel->currency_symbol =  $request->currency_symbol;
            $hotel->currency_value =  $request->currency_value;
            $hotel->property_desc =  $request->property_desc; 
            $hotel->property_google_map =  $request->property_google_map; 
            $hotel->latitude =  $request->latitude; 
            $hotel->longitude =  $request->longitude;
            $hotel->property_country =  $request->property_country; 
            $hotel->property_city =  $request->property_city;  
            $hotel->price_type =  $request->price_type; 
            $hotel->star_type =  $request->star_type; 
            $hotel->status =  $request->status; 
            $hotel->property_type =  $request->property_type; 
            $hotel->b2c_markup =  $request->b2c_markup; 
            $hotel->b2b_markup =  $request->b2b_markup; 
            $hotel->b2e_markup =  $request->b2e_markup; 
            $hotel->service_fee =  $request->service_fee; 
            $hotel->tax_type =  $request->tax_type; 
            $hotel->tax_value =  $request->tax_value; 
            // Facilities
            $hotel->facilities = $request->facilities; 
            // Contact
            $hotel->hotel_email =  $request->hotel_email; 
            $hotel->hotel_website =  $request->hotel_website; 
            $hotel->property_phone =  $request->property_phone; 
            $hotel->property_address =  $request->property_address;
            $hotel->room_gallery =  $request->room_gallery;
            
            $hotel->property_img =  $request->property_img; 
            $user_id = $request->customer_id;
            $hotel->owner_id = $user_id;
            $result = $hotel->update();
        }
        else{
            $result = 'Not Updated'; 
        }
       
        $hotelId = $id;
        // Save Meta Info
        $metaInfo = MetaInfo::where('hotel_id',$hotelId)->first();
        if($metaInfo){
            $metaInfo->meta_title =  $request->meta_title; 
            $metaInfo->keywords =  $request->keywords; 
            $metaInfo->meta_desc =  $request->meta_desc; 
            $metaInfo->hotel_id  = $hotelId;
            $meta_info_Result = $metaInfo->update();   
        }
        else{
            $meta_info_Result='Not Updated'; 
        }
        
        // Save Poilices
        $policies = Policies::where('hotel_id',$hotelId)->first();
        if($policies){
            $policies->check_in_form = $request->hotel_check_in;
            $policies->check_out_to = $request->hotel_check_out;
            $policies->payment_option = $request->payment_option;
            $policies->policy_and_terms = $request->policy_and_terms;
            $policies->hotel_id = $hotelId;
            // dd($hotel);
            $policies_Result = $policies->update();   
        }
        else{
            $policies_Result='Not Updated'; 
        }
        
        return response()->json([
            'message'           => 'Success',
            'result'            => $result,
            'meta_info_Result'  => $meta_info_Result,
            'policies_Result'   => $policies_Result,
        ]);
    }
   
    public function index(Request $request){
        // dd('ok');
        $id = $request->customer_id;
        //   $user_hotels = Hotels::join('countries','hotels.property_country','=','countries.id')
        //                  ->join('cities','hotels.property_city','=','cities.name')
        //                  ->where('hotels.owner_id',$id)
        //                  ->orderBy('hotels.created_at', 'desc')
        //                  ->get(['hotels.*','countries.name','cities.name']);
        $user_hotels = Hotels::where('owner_id',$id)
                        ->orWhereJsonContains('allowed_Clients', [['client_Id' => $id]])
                        ->orderBy('created_at', 'desc')->get();
        return response()->json([
            'user_hotels' => $user_hotels,
        ]);
    }
    
    // Other Dashboard
    public function hotel_list_All(Request $request){
        $id             = $request->customer_id;
        $user_hotel_arr = [];
        $user_hotels    = DB::table('hotels')
                            ->where('owner_id','!=',$id)
                            // ->where('owner_id',4)
                            ->join('meta_infos','hotels.id','meta_infos.hotel_id')
                            ->join('policies','hotels.id','policies.hotel_id')
                            ->where('hotels.image_Url_Other_Dashboard',NULL)
                            ->orderBy('hotels.created_at', 'desc')
                            ->get();
                            // ->take(10)->get();
                            
                            // dd($user_hotels);
                            
        foreach($user_hotels as $val_UH){
            $user_Data              = DB::table('customer_subcriptions')->where('id',$val_UH->owner_id)->select('dashboard_Address','webiste_Address')->first();
            if(isset($user_Data->dashboard_Address) && $user_Data->dashboard_Address != null && $user_Data->dashboard_Address != ''){
                $val_UH->image_Url_Other_Dashboard = $user_Data->dashboard_Address;
            }else{
                $val_UH->image_Url_Other_Dashboard = $user_Data->webiste_Address;
            }
            
            $already_Add_Check      = DB::table('hotels')->where('owner_id',$request->customer_id)->where('from_hotel_id',$val_UH->hotel_id)->first();
            if($already_Add_Check == null){
                array_push($user_hotel_arr,$val_UH);
            }
        }
        
        $unique_User_Hotels = collect($user_hotel_arr)->unique('hotel_id')->values()->all();
        
        // dd($unique_User_Hotels);
        
        return response()->json([
            'user_hotels' => $unique_User_Hotels,
        ]);
    }
    
    public function add_Hotel_OD(Request $req){
        $id             = $req->customer_id;
        $token          = $req->token;
        $hotel_Details  = json_decode($req->hotel_Details);
        // dd($hotel_Details->hotel_id);
        
        DB::beginTransaction();
        try {
            $request                    = $hotel_Details;
            $hotel                      = new Hotels;
            $hotel->property_name       = $request->property_name; 
            $hotel->currency_symbol     = $request->currency_symbol; 
            
            if(isset($request->SU_id) && $request->SU_id != null && $request->SU_id != ''){
                $hotel->SU_id =  $request->SU_id;
            }
            
            $hotel->currency_value      = $request->currency_value; 
            $hotel->property_desc       = $request->property_desc; 
            $hotel->property_google_map = $request->property_google_map; 
            $hotel->latitude            = $request->latitude; 
            $hotel->longitude           = $request->longitude;
            $hotel->property_country    = $request->property_country; 
            $hotel->property_city       = $request->property_city;  
            $hotel->price_type          = $request->price_type; 
            $hotel->star_type           = $request->star_type; 
            $hotel->status              = $request->status; 
            $hotel->property_type       = $request->property_type; 
            $hotel->b2c_markup          = $request->b2c_markup; 
            $hotel->b2b_markup          = $request->b2b_markup; 
            $hotel->b2e_markup          = $request->b2e_markup; 
            $hotel->service_fee         = $request->service_fee; 
            $hotel->tax_type            = $request->tax_type; 
            $hotel->tax_value           = $request->tax_value; 
            $hotel->facilities          = $request->facilities; 
            $hotel->hotel_email         = $request->hotel_email; 
            $hotel->hotel_website       = $request->hotel_website; 
            $hotel->property_phone      = $request->property_phone; 
            $hotel->property_address    = $request->property_address;
            $hotel->room_gallery        = $request->room_gallery;
            $hotel->property_img        = $request->property_img; 
            $user_id                    = $req->customer_id;
            $hotel->owner_id            = $user_id;
            
            $hotel->image_Url_Other_Dashboard   = $request->image_Url_Other_Dashboard;
            $hotel->from_owner_id               = $request->owner_id;
            $hotel->from_hotel_id               = $request->hotel_id;
            
            // dd($hotel);
            
            $result                     = $hotel->save();
            $hotelId                    = $hotel->id;
            
            // Save Meta Info
            $metaInfo                   = new MetaInfo;
            $metaInfo->meta_title       = $request->meta_title; 
            $metaInfo->keywords         = $request->keywords; 
            $metaInfo->meta_desc        = $request->meta_desc; 
            $metaInfo->hotel_id         = $hotelId;
            $meta_info_Result           = $metaInfo->save();
            
            // Save Poilices
            $policies                   = new Policies;
            $policies->check_in_form    = $request->check_in_form;
            $policies->check_out_to     = $request->check_out_to;
            $policies->payment_option   = $request->payment_option;
            $policies->policy_and_terms = $request->policy_and_terms;
            $policies->hotel_id         = $hotelId;
            $policies_Result            = $policies->save();
            
            // Rooms
            $check_Rooms = DB::table('rooms')->where('rooms.owner_id',$hotel_Details->owner_id)->where('rooms.hotel_id',$hotel_Details->hotel_id)
                            ->join('room_galleries','rooms.id','room_galleries.room_id')->get();
            if(count($check_Rooms) > 0){
                // dd('IF');
                function dateDiffInDays($date1, $date2){
                    $diff = strtotime($date2) - strtotime($date1);
                    return abs(round($diff / 86400));
                }
                
                function getBetweenDates($startDate, $endDate){
                    $rangArray  = [];
                    $startDate  = strtotime($startDate);
                    $endDate    = strtotime($endDate);
                    $startDate  += (86400);
                    for ($currentDate = $startDate; $currentDate <= $endDate; $currentDate += (86400)) {
                        $date           = date('Y-m-d', $currentDate);
                        $rangArray[]    = $date;
                    }
                    return $rangArray;
                }
                
                foreach($check_Rooms as $val_CR){
                    
                    // dd($val_CR);
                    
                    $Rooms                                  = new Rooms;
                    
                    if(isset($val_CR->SU_id) && $val_CR->SU_id != null && $val_CR->SU_id != ''){
                        $Rooms->SU_id                       =  $val_CR->SU_id;
                    }
                    
                    $Rooms->from_owner_id                   = $request->owner_id;
                    $Rooms->from_room_id                    = $val_CR->room_id;
                    
                    $Rooms->hotel_id                        = $hotelId;
                    $Rooms->rooms_on_rq                     = $val_CR->rooms_on_rq;
                    $Rooms->room_type_id                    = $val_CR->room_type_id; 
                    $Rooms->room_type_name                  = $val_CR->room_type_name; 
                    $Rooms->room_type_cat                   = $val_CR->room_type_cat; 
                    $Rooms->room_view                       = $val_CR->room_view; 
                    $Rooms->price_type                      = $val_CR->price_type; 
                    $Rooms->adult_price                     = $val_CR->adult_price;
                    $Rooms->child_price                     = $val_CR->child_price; 
                    $Rooms->quantity                        = $val_CR->quantity;  
                    $Rooms->min_stay                        = $val_CR->min_stay; 
                    $Rooms->max_child                       = $val_CR->max_child; 
                    $Rooms->max_adults                      = $val_CR->max_adults; 
                    $Rooms->extra_beds                      = $val_CR->extra_beds; 
                    $Rooms->extra_beds_charges              = $val_CR->extra_beds_charges; 
                    $Rooms->availible_from                  = $val_CR->availible_from; 
                    $Rooms->availible_to                    = $val_CR->availible_to; 
                    $Rooms->room_option_date                = $val_CR->room_option_date; 
                    $Rooms->price_week_type                 = $val_CR->price_week_type; 
                    $Rooms->price_all_days                  = $val_CR->price_all_days;
                    $Rooms->room_supplier_name              = $val_CR->room_supplier_name;
                    $Rooms->room_meal_type                  = $val_CR->room_meal_type;
                    $Rooms->weekdays                        = $val_CR->weekdays;
                    $Rooms->weekdays_price                  = $val_CR->weekdays_price;
                    $Rooms->weekends                        = $val_CR->weekends;
                    $Rooms->weekends_price                  = $val_CR->weekends_price; 
                    $Rooms->room_description                = $val_CR->room_description;
                    $Rooms->amenitites                      = $val_CR->amenitites;
                    $Rooms->status                          = $val_CR->status;
                    $Rooms->room_img                        = $val_CR->room_img; 
                    $Rooms->more_room_type_details          = ''; 
                    // $user_id                                = $request->owner_id;
                    $Rooms->owner_id                        = $user_id;
                    
                    $Rooms->cancellation_details            = $val_CR->cancellation_details;
                    $Rooms->additional_meal_type            = $val_CR->additional_meal_type;
                    $Rooms->additional_meal_type_charges    = $val_CR->additional_meal_type_charges;
                    $Rooms->display_on_web                  = $val_CR->display_on_web;
                    $Rooms->markup_type                     = $val_CR->markup_type;
                    $Rooms->markup_value                    = $val_CR->markup_value;
                    $Rooms->price_all_days_wi_markup        = $val_CR->price_all_days_wi_markup;
                    $Rooms->weekdays_price_wi_markup        = $val_CR->weekdays_price_wi_markup;
                    $Rooms->weekends_price_wi_markup        = $val_CR->weekends_price_wi_markup;
                    $result                                 = $Rooms->save();
                    $Roomsid                                = $Rooms->id;
                    
                    $supplier_data = DB::table('rooms_Invoice_Supplier')->where('id',$Rooms->room_supplier_name)->select('id','balance','payable')->first();
                    
                    if(isset($supplier_data)){
                        $week_days_total        = 0;
                        $week_end_days_totals   = 0;
                        $total_price            = 0;
                        if($Rooms->price_week_type == 'for_all_days'){
                            $avaiable_days      = dateDiffInDays($Rooms->availible_from, $Rooms->availible_to);
                            $total_price        = $Rooms->price_all_days * $avaiable_days;
                        }else{
                            $avaiable_days      = dateDiffInDays($Rooms->availible_from, $Rooms->availible_to);
                            $all_days           = getBetweenDates($Rooms->availible_from, $Rooms->availible_to);
                            $week_days          = json_decode($Rooms->weekdays);
                            $week_end_days      = json_decode($Rooms->weekends);
                            
                            foreach($all_days as $day_res){
                                $day                    = date('l', strtotime($day_res));
                                $day                    = trim($day);
                                $week_day_found         = false;
                                $week_end_day_found     = false;
                                
                                foreach($week_days as $week_day_res){
                                    if($week_day_res == $day){
                                        $week_day_found = true;
                                    }
                                }
                                
                                if($week_day_found){
                                    $week_days_total        += $Rooms->weekdays_price;
                                }else{
                                    $week_end_days_totals   += $Rooms->weekends_price;
                                }
                            }
                            
                            $total_price        = $week_days_total + $week_end_days_totals;
                        }
                        
                        $all_days_price         = $total_price * $Rooms->quantity;
                        $supplier_balance       = $supplier_data->balance + $all_days_price;
                        
                        DB::table('hotel_supplier_ledger')->insert([
                            'supplier_id'       => $supplier_data->id,
                            'payment'           => $all_days_price,
                            'balance'           => $supplier_balance,
                            'payable_balance'   => $supplier_data->payable,
                            'room_id'           => $Roomsid,
                            'customer_id'       => $user_id,
                            'date'              => date('Y-m-d'),
                            'available_from'    => $Rooms->availible_from,
                            'available_to'      => $Rooms->availible_to,
                            'room_quantity'     => $Rooms->quantity,
                        ]);
                        DB::table('rooms_Invoice_Supplier')->where('id',$supplier_data->id)->update(['balance'=>$supplier_balance]);
                    }
                    
                    if(isset($val_CR->more_room_type_details) && !empty($val_CR->more_room_type_details)){
                        $more_rooms = json_decode($val_CR->more_room_type_details);
                        
                        foreach($more_rooms as $room_more_res){
                            $meal_policy            = $room_more_res->more_meal_policy;
                            $meal_policy            = json_encode($meal_policy);
                            $concellation_policy    = $room_more_res->more_concellation_policy;
                            $guests_pay_days        = $room_more_res->more_guests_pay_days;
                            $guests_pay             = $room_more_res->more_guests_pay;
                            $prepaymentpolicy       = $room_more_res->more_prepaymentpolicy;
                            
                            
                            $cancellation_details       = (object)[
                                'meal_policy'           => $meal_policy,
                                'concellation_policy'   => $concellation_policy,
                                'guests_pay_days'       => $guests_pay_days,
                                'guests_pay'            => $guests_pay,
                                'prepaymentpolicy'      => $prepaymentpolicy,
                            ];
                            $cancellation_details               = json_encode($cancellation_details);
                            $room_insert_id                     = DB::table('rooms')->insertGetId([
                                'room_gen_id'                   => $room_more_res->room_gen_id,
                                'hotel_id'                      => $hotelId,
                                'rooms_on_rq'                   => $room_more_res->more_rooms_on_rq,
                                'room_type_id'                  => $room_more_res->more_room_type,
                                'room_type_name'                => $room_more_res->more_room_type_name,
                                'room_type_cat'                 => $room_more_res->more_room_type_id,
                                'room_view'                     => $room_more_res->more_room_view,
                                'price_type'                    => NULL,
                                'adult_price'                   => NULL,
                                'child_price'                   => NULL, 
                                'quantity'                      => $room_more_res->more_quantity,
                                'booked'                        => $room_more_res->more_quantity_booked,
                                'min_stay'                      => $room_more_res->more_min_stay, 
                                'max_child'                     => $room_more_res->more_max_childrens, 
                                'max_adults'                    => $room_more_res->more_max_adults,
                                'extra_beds'                    => $room_more_res->more_extra_beds, 
                                'extra_beds_charges'            => $room_more_res->more_extra_beds_charges, 
                                'availible_from'                => $room_more_res->more_room_av_from,
                                'availible_to'                  => $room_more_res->more_room_av_to,
                                'room_option_date'              => $room_more_res->more_room_option_date, 
                                'price_week_type'               => $room_more_res->more_week_price_type,
                                'price_all_days'                => $room_more_res->more_price_all_days,
                                'room_supplier_name'            => $room_more_res->more_room_supplier_name,
                                'room_meal_type'                => $room_more_res->more_room_meal_type,
                                'weekdays'                      => $room_more_res->more_weekdays,
                                'weekdays_price'                => $room_more_res->more_week_days_price,
                                'weekends'                      => $room_more_res->more_weekend,
                                'weekends_price'                => $room_more_res->more_week_end_price,
                                'room_description'              => $val_CR->room_description,
                                'amenitites'                    => $val_CR->amenitites,
                                'status'                        => $val_CR->status,
                                'more_room_type_details'        => NULL,
                                'owner_id'                      => $user_id,
                                'cancellation_details'          => $cancellation_details,
                                'additional_meal_type'          => $room_more_res->more_additional_meal_type,
                                'additional_meal_type_charges'  => $room_more_res->more_additional_meal_type_charges,
                                'display_on_web'                => $room_more_res->display_on_web,
                                'markup_type'                   => $room_more_res->markup_type,
                                'markup_value'                  => $room_more_res->markup_value,
                                'price_all_days_wi_markup'      => $room_more_res->price_all_days_wi_markup,
                                'weekdays_price_wi_markup'      => $room_more_res->weekdays_price_wi_markup,
                                'weekends_price_wi_markup'      => $room_more_res->weekends_price_wi_markup,
                            ]);
                            $supplier_data = DB::table('rooms_Invoice_Supplier')->where('id',$room_more_res->more_room_supplier_name)->select('id','balance','payable')->first();
                            
                            if(isset($supplier_data)){
                                // echo "Enter hre ";
                                
                                $week_days_total        = 0;
                                $week_end_days_totals   = 0;
                                $total_price        = 0;
                                if($room_more_res->more_week_price_type == 'for_all_days'){
                                    $avaiable_days  = dateDiffInDays($room_more_res->more_room_av_from, $room_more_res->more_room_av_to);
                                    $total_price    = $room_more_res->more_price_all_days * $avaiable_days;
                                }else{
                                    $avaiable_days  = dateDiffInDays($room_more_res->more_room_av_from, $room_more_res->more_room_av_to);
                                    $all_days       = getBetweenDates($room_more_res->more_room_av_from, $room_more_res->more_room_av_to);
                                    $week_days      = json_decode($room_more_res->more_weekdays);
                                    $week_end_days  = json_decode($room_more_res->more_weekend);
                                    
                                    foreach($all_days as $day_res){
                                        $day                = date('l', strtotime($day_res));
                                        $day                = trim($day);
                                        $week_day_found     = false;
                                        $week_end_day_found = false;
                                        
                                        foreach($week_days as $week_day_res){
                                            if($week_day_res == $day){
                                                $week_day_found = true;
                                            }
                                        }
                                        
                                        if($week_day_found){
                                            $week_days_total        += $room_more_res->more_week_days_price;
                                        }else{
                                            $week_end_days_totals   += $room_more_res->more_week_end_price;
                                        }
                                    }
                                    $total_price    = $week_days_total + $week_end_days_totals;
                                }
                                
                                $all_days_price     = $total_price * $room_more_res->more_quantity;
                                $supplier_balance   = $supplier_data->balance + $all_days_price;
                                
                                
                                DB::table('hotel_supplier_ledger')->insert([
                                    'supplier_id'       => $supplier_data->id,
                                    'payment'           => $all_days_price,
                                    'balance'           => $supplier_balance,
                                    'payable_balance'   => $supplier_data->payable,
                                    'room_id'           => $room_insert_id,
                                    'customer_id'       => $user_id,
                                    'date'              => date('Y-m-d'),
                                    'available_from'    => $room_more_res->more_room_av_from,
                                    'available_to'      => $room_more_res->more_room_av_to,
                                    'room_quantity'     => $room_more_res->more_quantity,
                                ]);
                                
                                DB::table('rooms_Invoice_Supplier')->where('id',$supplier_data->id)->update(['balance'=>$supplier_balance]);
                            } 
                        }
                    }
                    
                    $roomGallery                = new RoomGallery();
                    $roomGallery->img_name      = $val_CR->img_name;
                    $roomGallery->room_id       = $Roomsid;
                    $roomGallery                = $roomGallery->save();
                }
            }
            // Rooms
            
            DB::commit();
            
            return response()->json([
                'message' => 'Success',
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong Try Again']); 
        }
        
        return response()->json([
            'user_hotels' => $user_hotel_arr,
        ]);
    }
    // Other Dashboard
    
    public function view_Rates_Wise_Hotels(Request $request){
        $id                         = $request->customer_id;
        $remaining_Hotel_Wise_Data  = [];
        $makkah_Hotel_Wise_Data     = [];
        $madina_Hotel_Wise_Data     = [];
        $user_hotels                = [];
        $user_Rooms                 = [];
        
        $hotel_Details              = DB::table('hotels')->where('owner_id',$id)->orderBy('hotels.created_at', 'desc')->get();
        // ->take(10)
        // dd($hotel_Details);
        
        foreach($hotel_Details as $val_UH){
            $hotel_Rooms = DB::table('rooms')->where('owner_id',$val_UH->owner_id)->where('hotel_id',$val_UH->id)->get();
            if(!empty($hotel_Rooms) && count($hotel_Rooms) > 0){
                array_push($user_hotels,$val_UH);
                $room_Wise_Data = [];
                foreach($hotel_Rooms as $val_HR){
                    array_push($user_Rooms,$val_HR);
                    array_push($room_Wise_Data,$val_HR);
                }
                $single_Hotel_Wise_Data = [
                    'hotel' => $val_UH,
                    'rooms' => $room_Wise_Data
                ];
                
                if($val_UH->property_city != 'Makkah' && $val_UH->property_city != 'Medina' && $val_UH->property_city != 'medina' && $val_UH->property_city != 'Al-Madinah al-Munawwarah'){
                    array_push($remaining_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
                
                if($val_UH->property_city == 'Makkah' || $val_UH->property_city == 'makkah'){
                    array_push($makkah_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
                
                if($val_UH->property_city == 'Madina' || $val_UH->property_city == 'madina' || $val_UH->property_city == 'Medina' || $val_UH->property_city == 'medina' || $val_UH->property_city == 'Al-Madinah al-Munawwarah'){
                    array_push($madina_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
            }
        }
        
        return response()->json([
            'user_hotels'               => $user_hotels,
            'user_Rooms'                => $user_Rooms,
            'remaining_Hotel_Wise_Data' => $remaining_Hotel_Wise_Data,
            'makkah_Hotel_Wise_Data'    => $makkah_Hotel_Wise_Data,
            'madina_Hotel_Wise_Data'    => $madina_Hotel_Wise_Data,
        ]);
    }
    
    public function view_Rates_Wise_Hotels_Makkah(Request $request){
        $id                         = $request->customer_id;
        $makkah_Hotel_Wise_Data     = [];
        $hotel_Details              = DB::table('hotels')->where('owner_id',$id)->orderBy('hotels.created_at', 'desc')->get();
        
        foreach($hotel_Details as $val_UH){
            $hotel_Rooms = DB::table('rooms')->where('owner_id',$val_UH->owner_id)->where('hotel_id',$val_UH->id)->get();
            if(!empty($hotel_Rooms) && count($hotel_Rooms) > 0){
                $room_Wise_Data = [];
                foreach($hotel_Rooms as $val_HR){
                    array_push($room_Wise_Data,$val_HR);
                }
                $single_Hotel_Wise_Data = [
                    'hotel' => $val_UH,
                    'rooms' => $room_Wise_Data
                ];
                
                if($val_UH->property_city == 'Makkah' || $val_UH->property_city == 'makkah'){
                    array_push($makkah_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
            }
        }
        
        return response()->json([
            'makkah_Hotel_Wise_Data'    => $makkah_Hotel_Wise_Data,
        ]);
    }
    
    public function view_Rates_Wise_Hotels_Madina(Request $request){
        $id                         = $request->customer_id;
        $madina_Hotel_Wise_Data     = [];
        $hotel_Details              = DB::table('hotels')->where('owner_id',$id)->orderBy('hotels.created_at', 'desc')->get();
        
        foreach($hotel_Details as $val_UH){
            $hotel_Rooms = DB::table('rooms')->where('owner_id',$val_UH->owner_id)->where('hotel_id',$val_UH->id)->get();
            if(!empty($hotel_Rooms) && count($hotel_Rooms) > 0){
                $room_Wise_Data = [];
                foreach($hotel_Rooms as $val_HR){
                    array_push($room_Wise_Data,$val_HR);
                }
                $single_Hotel_Wise_Data = [
                    'hotel' => $val_UH,
                    'rooms' => $room_Wise_Data
                ];
                
                if($val_UH->property_city == 'Madina' || $val_UH->property_city == 'madina' || $val_UH->property_city == 'Medina' || $val_UH->property_city == 'medina' || $val_UH->property_city == 'Al-Madinah al-Munawwarah'){
                    array_push($madina_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
            }
        }
        
        return response()->json([
            'madina_Hotel_Wise_Data'    => $madina_Hotel_Wise_Data,
        ]);
    }
    
    public function view_Rates_Wise_Hotels_Madina_Test(Request $request){
        $id                         = $request->customer_id;
        $madina_Hotel_Wise_Data     = [];
        
        $c1 = 'Madina';
        $c2 = 'madina';
        $c3 = 'Medina';
        $c4 = 'medina';
        $c5 = 'Al-Madinah al-Munawwarah';
        
        // dd($c1);
        
        $hotel_Details              = DB::table('hotels')
                                        ->where(function ($query) use ($id, $c1, $c2, $c3, $c4, $c5) {
                                            $query->where('owner_id', $id)
                                            ->where(function ($q) use ($c1, $c2, $c3, $c4, $c5) {
                                                $q->orWhere('property_city', $c1)
                                                ->orWhere('property_city', $c2)
                                                ->orWhere('property_city', $c3)
                                                ->orWhere('property_city', $c4)
                                                ->orWhere('property_city', $c5);
                                            });
                                        })->orderBy('hotels.created_at', 'desc')->get();
        // dd($hotel_Details);
        
        foreach($hotel_Details as $val_UH){
            $hotel_Rooms = DB::table('rooms')->where('owner_id',$val_UH->owner_id)->where('hotel_id',$val_UH->id)->get();
            if(!empty($hotel_Rooms) && count($hotel_Rooms) > 0){
                
                dd($hotel_Rooms);
                
                $room_Wise_Data = [];
                foreach($hotel_Rooms as $val_HR){
                    array_push($room_Wise_Data,$val_HR);
                }
                
                $single_Hotel_Wise_Data = [
                    'hotel' => $val_UH,
                    'rooms' => $room_Wise_Data
                ];
                
                if($val_UH->property_city == 'Madina' || $val_UH->property_city == 'madina' || $val_UH->property_city == 'Medina' || $val_UH->property_city == 'medina' || $val_UH->property_city == 'Al-Madinah al-Munawwarah'){
                    array_push($madina_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
            }
        }
        
        
        
        foreach($hotel_Details as $val_UH){
            $hotel_Rooms = DB::table('rooms')->where('owner_id',$val_UH->owner_id)->where('hotel_id',$val_UH->id)->get();
            if(!empty($hotel_Rooms) && count($hotel_Rooms) > 0){
                $room_Wise_Data = [];
                foreach($hotel_Rooms as $val_HR){
                    array_push($room_Wise_Data,$val_HR);
                }
                
                $single_Hotel_Wise_Data = [
                    'hotel' => $val_UH,
                    'rooms' => $room_Wise_Data
                ];
                
                if($val_UH->property_city == 'Madina' || $val_UH->property_city == 'madina' || $val_UH->property_city == 'Medina' || $val_UH->property_city == 'medina' || $val_UH->property_city == 'Al-Madinah al-Munawwarah'){
                    array_push($madina_Hotel_Wise_Data,$single_Hotel_Wise_Data);
                }
            }
        }
        
        return response()->json([
            'madina_Hotel_Wise_Data'    => $madina_Hotel_Wise_Data,
        ]);
    }

    public function showAddHotelFrom(){
        $all_countries = country::all();
        
       
        return response()->json([
            'all_countries' => $all_countries,
        ]);
        // return view('template/frontend/userdashboard/pages/hotel_manager.add_hotel',compact('all_countries'));
   }

    public function addHotel(Request $request){
        // Data
        $hotel = new Hotels;
        $hotel->property_name =  $request->property_name; 
        $hotel->currency_symbol =  $request->currency_symbol; 
        
        if(isset($request->SU_id) && $request->SU_id != null && $request->SU_id != ''){
            $hotel->SU_id =  $request->SU_id;
        }
        
        $hotel->currency_value =  $request->currency_value; 
        
        $hotel->property_desc =  $request->property_desc; 
        $hotel->property_google_map =  $request->property_google_map; 
        $hotel->latitude =  $request->latitude; 
        $hotel->longitude =  $request->longitude;
        $hotel->property_country =  $request->property_country; 
        $hotel->property_city =  $request->property_city;  
        $hotel->price_type =  $request->price_type; 
        $hotel->star_type =  $request->star_type; 
        $hotel->status =  $request->status; 
        $hotel->property_type =  $request->property_type; 
        $hotel->b2c_markup =  $request->b2c_markup; 
        $hotel->b2b_markup =  $request->b2b_markup; 
        $hotel->b2e_markup =  $request->b2e_markup; 
        $hotel->service_fee =  $request->service_fee; 
        $hotel->tax_type =  $request->tax_type; 
        $hotel->tax_value =  $request->tax_value; 
        // Facilities
        $hotel->facilities = $request->facilities; 
        // Contact
        $hotel->hotel_email =  $request->hotel_email; 
        $hotel->hotel_website =  $request->hotel_website; 
        $hotel->property_phone =  $request->property_phone; 
        $hotel->property_address =  $request->property_address;
        $hotel->room_gallery = $request->room_gallery;
        
        $hotel->property_img =  $request->property_img; 
        $user_id = $request->customer_id;
        
        
        $hotel->owner_id = $user_id;
        $result = $hotel->save();
        $hotelId = $hotel->id;
        // Save Meta Info
        $metaInfo = new MetaInfo;
        $metaInfo->meta_title =  $request->meta_title; 
        $metaInfo->keywords =  $request->keywords; 
        $metaInfo->meta_desc =  $request->meta_desc; 
        $metaInfo->hotel_id  = $hotelId;
        $meta_info_Result = $metaInfo->save();
        // Save Poilices
        $policies = new Policies;
        $policies->check_in_form = $request->hotel_check_in;
        $policies->check_out_to = $request->hotel_check_out;
        $policies->payment_option = $request->payment_option;
        $policies->policy_and_terms = $request->policy_and_terms;
        $policies->hotel_id = $hotelId;
        // dd($hotel);
        $policies_Result = $policies->save();
        // End Data
        
        return response()->json([
            'message' => 'Success',
        ]);
   }

    // Hotel
    public function hotel_Room(){
      $start_date = $_POST['start_date'];
      $end_date   = $_POST['end_date'];
      $cityID     = $_POST['cityID'];
       $rooms  = DB::table('rooms')->where('availible_from','<=',$start_date)->where('availible_to','>=',$end_date)
                ->join('rooms_types','rooms.room_type_id','=','rooms_types.id')
                ->join('hotels','rooms.hotel_id','=','hotels.id')->where('property_city','=',$cityID)
                ->get();
      echo $rooms ;
   }

    // Room
    public function roomID($id){
        $rooms = Rooms::where('hotel_id',$id)->join('rooms_types','rooms.room_type_id','=','rooms_types.id')->get();
        echo $rooms ;
   }
   
    public function get_hotel_booking(Request $request){
       $token=$request->token;
       $hotels_booking=DB::table('hotel_booking')->where('auth_token',$token)->where('provider','hotels')->limit(5)->orderBy('id', 'DESC')->get();
       $customer_subcriptions=DB::table('customer_subcriptions')->where('Auth_key',$token)->first();
       return response()->json([
            'hotels_booking' => $hotels_booking,
            'customer_subcriptions' => $customer_subcriptions,
           
        ]);
    }
   
    // hotel_Bookings
    public function hotel_Bookings(Request $request){
        $system_url = DB::table('customer_subcriptions')->where('id',$request->customer_id)->select('webiste_Address')->first();
        $data       = DB::table('hotels_bookings')->where('customer_id',$request->customer_id)->orderBy('id', 'desc')->get();
        return response()->json([
            'data'          => $data,
            'system_url'    => $system_url->webiste_Address,
        ]);
    }
    
    public function hotel_Bookings_Client(Request $request){
        $system_url     = DB::table('customer_subcriptions')->where('id',$request->customer_id)->select('webiste_Address')->first();
        $all_Details    = [];
        $client_Details = DB::table('customer_subcriptions')->where('id',$request->client_Id)->get();
        foreach($client_Details as $val_CD){
            if($request->hotel_Id != NULL){
                $allowedHotels = DB::table('hotels')->where('owner_id',$request->customer_id)->where('id',$request->hotel_Id)->get();
            }else{
                $allowedHotels = DB::table('hotels')->where('owner_id',$request->customer_id)->whereJsonContains('allowed_Clients', [['client_Id' => (string) $val_CD->id]])->get();
            }
            if(!empty($allowedHotels) && count($allowedHotels) > 0){
                foreach($allowedHotels as $val_HD){
                    $total_Booking_Quantity = 0;
                    $total_Revenue          = 0;
                    $hotels_Bookings        = DB::table('hotels_bookings')->where('customer_id',$val_CD->id)->where('provider','Custome_hotel')->get();
                    if(!empty($hotels_Bookings) && count($hotels_Bookings) > 0){
                        foreach($hotels_Bookings as $val_HB) {
                            $reservation_request    = json_decode($val_HB->reservation_request);
                            $hotel_checkout_select  = json_decode($reservation_request->hotel_checkout_select);
                            if($hotel_checkout_select->hotel_id == $val_HD->id){
                                array_push($all_Details,$val_HB);
                            }
                        }
                    }
                }
            }
        }
        
        return response()->json([
            'data'          => $all_Details,
            'system_url'    => $system_url->webiste_Address,
        ]);
    }
    
    public function delete_hotels(Request $request){
        DB::beginTransaction();
        try {
            $room_Exist = DB::table('hotels')
                            ->join('rooms','hotels.id','=','rooms.hotel_id')
                            ->where('hotels.owner_id',$request->customer_id)
                            ->where('hotels.id',$request->id)->get();
            
            if(count($room_Exist) > 0){
                return response()->json(['message'=>'Room_Exist']);
            }else{
                DB::table('hotels')->where('owner_id',$request->customer_id)->where('id',$request->id)->delete();
                // DB::table('rooms')->where('owner_id',$request->customer_id)->where('hotel_id',$request->id)->delete();
                DB::table('meta_infos')->where('hotel_id',$request->id)->delete();
                DB::table('policies')->where('hotel_id',$request->id)->delete();
            }
            
            DB::commit();
            return response()->json(['message'=>'success']);
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;die;
            return response()->json(['message'=>'error']);
        }
    }
}
