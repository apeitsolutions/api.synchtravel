<?php

namespace App\Http\Controllers\HotelMangersApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\hotel_manager\Rooms;
use App\Models\admin\RoomsType;
use App\Models\hotel_manager\Hotels;
use App\Models\MetaInfo;
use App\Models\Policies;
use App\Models\country;
use App\Models\city;
use Session;

use Auth;
use DB;

class HotelControllerApi extends Controller
{
    public function hotels_fillters(Request $request){
    $hotel_city = $request->hotel_city;
    
    $hotels = Hotels::where('property_city',$hotel_city)
    ->where('owner_id',$request->customer_id)
    ->get();
    
    return response()->json([
    'hotels'=>'Hotels Are Found',
    'hotels_data' => $hotels,
    ]);
    
    }
    
    public function hotels_fillters_by_name(Request $request){
        $slc_hotel_name = $request->slc_hotel_name;
        
        $hotels = Hotels::where('property_name',$slc_hotel_name)->get();
        
        return response()->json([
        'hotels'=>'Hotels Are Found',
        'hotels_data' => $hotels,
        ]);
    
    } 
    
    public function getCurrentWeek(){
    
        $monday = strtotime("last monday");
        
        $monday = date('w', $monday)==date('w') ? $monday+(7*86400) : $monday;
        
        $sunday = strtotime(date("Y-m-d",$monday)." +6 days");
        
        $this_week_sd = date("Y-m-d",$monday);
        
        $this_week_ed = date("Y-m-d",$sunday);
        
        
        
        return $data = ['first_day' => $this_week_sd, 'last_day' => $this_week_ed];
    
    }
    
    public function hotel_arrival_list(){
        $date=date('Y-m-d');
        
        $year = date('Y') . '-12-31';
        
        $first_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-01')));
        
        $last_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-t')));
        $current_week = $this->getCurrentWeek();
        
        
        $arrival_detail_today= DB::table('hotel_booking')->orderBy('id', 'desc')->where('check_in','=',date('y-m-d'))->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','hotelbeddetailRQ')->get();
        $arrival_detail_week= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_in', [$current_week['first_day'],$current_week['last_day']])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','tbo_BookingDetail_rs','hotelbeddetailRQ')->get();
        $arrival_detail_this_month= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_in', [$first_day_of_this_month,$last_day_of_this_month])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status','hotelbeddetailRQ')->get();
        
        
        
        return response()->json([
        'arrival_detail_today' => $arrival_detail_today,
        'arrival_detail_week' => $arrival_detail_week,
        'arrival_detail_this_month' => $arrival_detail_this_month,
        
        'first_day_this_week' => $current_week['first_day'],
        'last_day_this_week' => $current_week['last_day'],
        'first_day_of_this_month' => $first_day_of_this_month,
        'last_day_of_this_month' => $last_day_of_this_month,
        
        ]);
    }
    
    public function hotel_departure_list(){
        $date=date('Y-m-d');
        
        $year = date('Y') . '-12-31';
        
        $first_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-01')));
        
        $last_day_of_this_month = date('Y-m-d',strtotime(date('Y-m-t')));
        $current_week = $this->getCurrentWeek();
        
        $arrival_detail_today= DB::table('hotel_booking')->orderBy('id', 'desc')->where('check_out','=',date('y-m-d'))->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        $arrival_detail_week= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_out', [$current_week['first_day'],$current_week['last_day']])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        $arrival_detail_this_month= DB::table('hotel_booking')->orderBy('id', 'desc')->wherebetween('check_out', [$first_day_of_this_month,$last_day_of_this_month])->where('provider','!=',NULL)->select('id','search_id','check_in','check_out','lead_passenger_details','provider','hotel_checkavailability','rooms_checkavailability','tboDetailRS','tboSelectionRS','travellandadetailRS','travellandaSelectionRS','hotelbeddetailRS','hotelbedSelectionRS','ratehawk_details_rs1','ratehawk_selection_rs','created_at','booking_status')->get();
        
        
        
        return response()->json([
        'departure_detail_today' => $arrival_detail_today,
        'departure_detail_week' => $arrival_detail_week,
        'departure_detail_this_month' => $arrival_detail_this_month,
        
        ]);
    }
    
    public function showeditHotelFrom(Request $request){
        $all_countries = country::all();
        
        $id = $request->customer_id;
        $hotel_id = $request->id;
        $user_hotels = Hotels::find($hotel_id);
        $MetaInfo =  MetaInfo::where('hotel_id',$hotel_id)->first();
        $Policies =  Policies::where('hotel_id',$hotel_id)->first();
        //   $user_hotels = Hotels::join('countries','hotels.property_country','=','countries.id')
        //                  ->join('cities','hotels.property_city','=','cities.name')
        //                  ->where('hotels.owner_id',$id)
        //                  ->orderBy('hotels.created_at', 'desc')
        //                  ->get(['hotels.*','countries.name','cities.name']);
        
        // $city_D     = DB::table('cities')->get();
        // dd($hotel_id);
        
        return response()->json([
            'all_countries' => $all_countries,
            'user_hotels' => $user_hotels,
            'MetaInfo' => $MetaInfo,
            'Policies' => $Policies,
            // 'city_D' => $city_D,
        ]);
        // return view('template/frontend/userdashboard/pages/hotel_manager.add_hotel',compact('all_countries'));
   }
    
    public function updateHotel(Request $request){
        $id     = $request->id;
        $hotel  = Hotels::find($id);
        if($hotel){
            // dd($request->property_country);
            $hotel->property_name =  $request->property_name; 
            $hotel->currency_symbol =  $request->currency_symbol;
            $hotel->currency_value =  $request->currency_value;
            $hotel->property_desc =  $request->property_desc; 
            $hotel->property_google_map =  $request->property_google_map; 
            $hotel->latitude =  $request->latitude; 
            $hotel->longitude =  $request->longitude;
            $hotel->property_country =  $request->property_country; 
            $hotel->property_city =  $request->property_city;  
            $hotel->price_type =  $request->price_type; 
            $hotel->star_type =  $request->star_type; 
            $hotel->status =  $request->status; 
            $hotel->property_type =  $request->property_type; 
            $hotel->b2c_markup =  $request->b2c_markup; 
            $hotel->b2b_markup =  $request->b2b_markup; 
            $hotel->b2e_markup =  $request->b2e_markup; 
            $hotel->service_fee =  $request->service_fee; 
            $hotel->tax_type =  $request->tax_type; 
            $hotel->tax_value =  $request->tax_value; 
            // Facilities
            $hotel->facilities = $request->facilities; 
            // Contact
            $hotel->hotel_email =  $request->hotel_email; 
            $hotel->hotel_website =  $request->hotel_website; 
            $hotel->property_phone =  $request->property_phone; 
            $hotel->property_address =  $request->property_address;
            $hotel->room_gallery =  $request->room_gallery;
            
            $hotel->property_img =  $request->property_img; 
            $user_id = $request->customer_id;
            $hotel->owner_id = $user_id;
            $result = $hotel->update();
        }
        else{
            $result = 'Not Updated'; 
        }
       
        $hotelId = $id;
        // Save Meta Info
        $metaInfo = MetaInfo::where('hotel_id',$hotelId)->first();
        if($metaInfo){
            $metaInfo->meta_title =  $request->meta_title; 
            $metaInfo->keywords =  $request->keywords; 
            $metaInfo->meta_desc =  $request->meta_desc; 
            $metaInfo->hotel_id  = $hotelId;
            $meta_info_Result = $metaInfo->update();   
        }
        else{
            $meta_info_Result='Not Updated'; 
        }
        
        // Save Poilices
        $policies = Policies::where('hotel_id',$hotelId)->first();
        if($policies){
            $policies->check_in_form = $request->hotel_check_in;
            $policies->check_out_to = $request->hotel_check_out;
            $policies->payment_option = $request->payment_option;
            $policies->policy_and_terms = $request->policy_and_terms;
            $policies->hotel_id = $hotelId;
            // dd($hotel);
            $policies_Result = $policies->update();   
        }
        else{
            $policies_Result='Not Updated'; 
        }
        
        return response()->json([
            'message'           => 'Success',
            'result'            => $result,
            'meta_info_Result'  => $meta_info_Result,
            'policies_Result'   => $policies_Result,
        ]);
    }
   
    public function index(Request $request){
        $id = $request->customer_id;
        //   $user_hotels = Hotels::join('countries','hotels.property_country','=','countries.id')
        //                  ->join('cities','hotels.property_city','=','cities.name')
        //                  ->where('hotels.owner_id',$id)
        //                  ->orderBy('hotels.created_at', 'desc')
        //                  ->get(['hotels.*','countries.name','cities.name']);
        $user_hotels = Hotels::where('owner_id',$id)->orderBy('created_at', 'desc')->get();
        return response()->json([
            'user_hotels' => $user_hotels,
        ]);
    }
    
    // Other Dashboard
    public function hotel_list_All(Request $request){
        $id             = $request->customer_id;
        $user_hotel_arr = [];
        $user_hotels    = DB::table('hotels')->where('owner_id','!=',$id)
                            ->join('meta_infos','hotels.id','meta_infos.hotel_id')
                            ->join('policies','hotels.id','policies.hotel_id')
                            ->orderBy('hotels.created_at', 'desc')
                            ->get();
                            // ->take(10)->get();
        foreach($user_hotels as $val_UH){
            $user_Data              = DB::table('customer_subcriptions')->where('id',$val_UH->owner_id)->select('dashboard_Address')->first();
            $already_Add_Check      = DB::table('hotels')->where('owner_id',$request->customer_id)->where('from_hotel_id',$val_UH->hotel_id)->first();
            if(isset($user_Data->dashboard_Address) && $user_Data->dashboard_Address != null && $user_Data->dashboard_Address != ''){
                $val_UH->image_Url_Other_Dashboard = $user_Data->dashboard_Address;
                if($already_Add_Check == null){
                    array_push($user_hotel_arr,$val_UH);
                }
            }
        }
        return response()->json([
            'user_hotels' => $user_hotel_arr,
        ]);
    }
    
    public function add_Hotel_OD(Request $req){
        $id             = $req->customer_id;
        $token          = $req->token;
        $hotel_Details  = json_decode($req->hotel_Details);
        // dd($hotel_Details);
        
        DB::beginTransaction();
        try {
            $request                    = $hotel_Details;
            $hotel                      = new Hotels;
            $hotel->property_name       = $request->property_name; 
            $hotel->currency_symbol     = $request->currency_symbol; 
            
            if(isset($request->SU_id) && $request->SU_id != null && $request->SU_id != ''){
                $hotel->SU_id =  $request->SU_id;
            }
            
            $hotel->currency_value      = $request->currency_value; 
            $hotel->property_desc       = $request->property_desc; 
            $hotel->property_google_map = $request->property_google_map; 
            $hotel->latitude            = $request->latitude; 
            $hotel->longitude           = $request->longitude;
            $hotel->property_country    = $request->property_country; 
            $hotel->property_city       = $request->property_city;  
            $hotel->price_type          = $request->price_type; 
            $hotel->star_type           = $request->star_type; 
            $hotel->status              = $request->status; 
            $hotel->property_type       = $request->property_type; 
            $hotel->b2c_markup          = $request->b2c_markup; 
            $hotel->b2b_markup          = $request->b2b_markup; 
            $hotel->b2e_markup          = $request->b2e_markup; 
            $hotel->service_fee         = $request->service_fee; 
            $hotel->tax_type            = $request->tax_type; 
            $hotel->tax_value           = $request->tax_value; 
            $hotel->facilities          = $request->facilities; 
            $hotel->hotel_email         = $request->hotel_email; 
            $hotel->hotel_website       = $request->hotel_website; 
            $hotel->property_phone      = $request->property_phone; 
            $hotel->property_address    = $request->property_address;
            $hotel->room_gallery        = $request->room_gallery;
            $hotel->property_img        = $request->property_img; 
            $user_id                    = $req->customer_id;
            $hotel->owner_id            = $user_id;
            
            $hotel->image_Url_Other_Dashboard   = $request->image_Url_Other_Dashboard;
            $hotel->from_owner_id               = $request->owner_id;
            $hotel->from_hotel_id               = $request->hotel_id;
            
            // dd($hotel);
            
            $result                     = $hotel->save();
            $hotelId                    = $hotel->id;
            
            // Save Meta Info
            $metaInfo                   = new MetaInfo;
            $metaInfo->meta_title       = $request->meta_title; 
            $metaInfo->keywords         = $request->keywords; 
            $metaInfo->meta_desc        = $request->meta_desc; 
            $metaInfo->hotel_id         = $hotelId;
            $meta_info_Result           = $metaInfo->save();
            
            // Save Poilices
            $policies                   = new Policies;
            $policies->check_in_form    = $request->check_in_form;
            $policies->check_out_to     = $request->check_out_to;
            $policies->payment_option   = $request->payment_option;
            $policies->policy_and_terms = $request->policy_and_terms;
            $policies->hotel_id         = $hotelId;
            $policies_Result            = $policies->save();
            
            DB::commit();
            
            return response()->json([
                'message' => 'Success',
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong Try Again']); 
        }
        
        return response()->json([
            'user_hotels' => $user_hotel_arr,
        ]);
    }
    // Other Dashboard

    public function showAddHotelFrom(){
        $all_countries = country::all();
        
       
        return response()->json([
            'all_countries' => $all_countries,
        ]);
        // return view('template/frontend/userdashboard/pages/hotel_manager.add_hotel',compact('all_countries'));
   }

    public function addHotel(Request $request){
        // Data
        $hotel = new Hotels;
        $hotel->property_name =  $request->property_name; 
        $hotel->currency_symbol =  $request->currency_symbol; 
        
        if(isset($request->SU_id) && $request->SU_id != null && $request->SU_id != ''){
            $hotel->SU_id =  $request->SU_id;
        }
        
        $hotel->currency_value =  $request->currency_value; 
        
        $hotel->property_desc =  $request->property_desc; 
        $hotel->property_google_map =  $request->property_google_map; 
        $hotel->latitude =  $request->latitude; 
        $hotel->longitude =  $request->longitude;
        $hotel->property_country =  $request->property_country; 
        $hotel->property_city =  $request->property_city;  
        $hotel->price_type =  $request->price_type; 
        $hotel->star_type =  $request->star_type; 
        $hotel->status =  $request->status; 
        $hotel->property_type =  $request->property_type; 
        $hotel->b2c_markup =  $request->b2c_markup; 
        $hotel->b2b_markup =  $request->b2b_markup; 
        $hotel->b2e_markup =  $request->b2e_markup; 
        $hotel->service_fee =  $request->service_fee; 
        $hotel->tax_type =  $request->tax_type; 
        $hotel->tax_value =  $request->tax_value; 
        // Facilities
        $hotel->facilities = $request->facilities; 
        // Contact
        $hotel->hotel_email =  $request->hotel_email; 
        $hotel->hotel_website =  $request->hotel_website; 
        $hotel->property_phone =  $request->property_phone; 
        $hotel->property_address =  $request->property_address;
        $hotel->room_gallery = $request->room_gallery;
        
        $hotel->property_img =  $request->property_img; 
        $user_id = $request->customer_id;
        
        
        $hotel->owner_id = $user_id;
        $result = $hotel->save();
        $hotelId = $hotel->id;
        // Save Meta Info
        $metaInfo = new MetaInfo;
        $metaInfo->meta_title =  $request->meta_title; 
        $metaInfo->keywords =  $request->keywords; 
        $metaInfo->meta_desc =  $request->meta_desc; 
        $metaInfo->hotel_id  = $hotelId;
        $meta_info_Result = $metaInfo->save();
        // Save Poilices
        $policies = new Policies;
        $policies->check_in_form = $request->hotel_check_in;
        $policies->check_out_to = $request->hotel_check_out;
        $policies->payment_option = $request->payment_option;
        $policies->policy_and_terms = $request->policy_and_terms;
        $policies->hotel_id = $hotelId;
        // dd($hotel);
        $policies_Result = $policies->save();
        // End Data
        
        return response()->json([
            'message' => 'Success',
        ]);
   }

    // Hotel
    public function hotel_Room(){
      $start_date = $_POST['start_date'];
      $end_date   = $_POST['end_date'];
      $cityID     = $_POST['cityID'];
       $rooms  = DB::table('rooms')->where('availible_from','<=',$start_date)->where('availible_to','>=',$end_date)
                ->join('rooms_types','rooms.room_type_id','=','rooms_types.id')
                ->join('hotels','rooms.hotel_id','=','hotels.id')->where('property_city','=',$cityID)
                ->get();
      echo $rooms ;
   }

    // Room
    public function roomID($id){
        $rooms = Rooms::where('hotel_id',$id)->join('rooms_types','rooms.room_type_id','=','rooms_types.id')->get();
        echo $rooms ;
   }
   
    public function get_hotel_booking(Request $request){
       $token=$request->token;
       $hotels_booking=DB::table('hotel_booking')->where('auth_token',$token)->where('provider','hotels')->limit(5)->orderBy('id', 'DESC')->get();
       $customer_subcriptions=DB::table('customer_subcriptions')->where('Auth_key',$token)->first();
       return response()->json([
            'hotels_booking' => $hotels_booking,
            'customer_subcriptions' => $customer_subcriptions,
           
        ]);
    }
   
    // hotel_Bookings
    public function hotel_Bookings(Request $request){
        $system_url = DB::table('customer_subcriptions')->where('id',$request->customer_id)->select('webiste_Address')->first();
        $data       = DB::table('hotels_bookings')->where('customer_id',$request->customer_id)->orderBy('id', 'desc')->get();
        return response()->json([
            'data'          => $data,
            'system_url'    => $system_url->webiste_Address,
        ]);
    }
    
    public function delete_hotels(Request $request){
        DB::beginTransaction();
        try {
            $room_Exist = DB::table('hotels')
                            ->join('rooms','hotels.id','=','rooms.hotel_id')
                            ->where('hotels.owner_id',$request->customer_id)
                            ->where('hotels.id',$request->id)->get();
            
            if(count($room_Exist) > 0){
                return response()->json(['message'=>'Room_Exist']);
            }else{
                DB::table('hotels')->where('owner_id',$request->customer_id)->where('id',$request->id)->delete();
                // DB::table('rooms')->where('owner_id',$request->customer_id)->where('hotel_id',$request->id)->delete();
                DB::table('meta_infos')->where('hotel_id',$request->id)->delete();
                DB::table('policies')->where('hotel_id',$request->id)->delete();
            }
            
            DB::commit();
            return response()->json(['message'=>'success']);
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;die;
            return response()->json(['message'=>'error']);
        }
    }
}
