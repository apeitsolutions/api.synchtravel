<?php
namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Session;
use App\Models\Show_Interest;
use App\Models\CustomerSubcription\CustomerSubcription;

class ShowInterestController extends Controller
{
    // Show Interest
    public function create_ShowInterest(Request $request){
        DB::beginTransaction();
        try {
            $userData                           = CustomerSubcription::where('Auth_key',$request->token)->first();
            
            $show_Interest                      = new Show_Interest();
            $show_Interest->customer_id         = $userData->id;
            $show_Interest->token               = $request->token;
            $show_Interest->email_Address       = $request->email_Address;
            $show_Interest->first_Name          = $request->first_Name;
            $show_Interest->last_Name           = $request->last_Name;
            $show_Interest->no_Of_Passengers    = $request->no_Of_Passengers;
            $show_Interest->phone_No            = $request->phone_No;
            $show_Interest->street_Address      = $request->street_Address;
            $show_Interest->city                = $request->city;
            $show_Interest->post_Code           = $request->post_Code;
            $show_Interest->country             = $request->country;
            
            $show_Interest->save();
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Data Added Successfully!']);
            
        } catch (Throwable $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function view_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            $Show_Interest = Show_Interest::where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','Show_Interest'=>$Show_Interest]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function edit_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            $Show_Interest = Show_Interest::where('token',$request->token)->where('id',$request->id)->first();
            return response()->json(['status'=>'success','message'=>'Data Edit Successfully!','Show_Interest'=>$Show_Interest]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function update_ShowInterest(Request $request){
        DB::beginTransaction();
        try {
            $show_Interest                      = Show_Interest::find($request->id);
            $show_Interest->email_Address       = $request->email_Address;
            $show_Interest->first_Name          = $request->first_Name;
            $show_Interest->last_Name           = $request->last_Name;
            $show_Interest->no_Of_Passengers    = $request->no_Of_Passengers;
            $show_Interest->phone_No            = $request->phone_No;
            $show_Interest->street_Address      = $request->street_Address;
            $show_Interest->city                = $request->city;
            $show_Interest->post_Code           = $request->post_Code;
            $show_Interest->country             = $request->country;
            
            $show_Interest->update();
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Data Updated Successfully!','show_Interest'=>$show_Interest]);
            
        } catch (Throwable $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }

    public function deleteseat_ShowInterest(Request $request){
        $suppliers = Show_Interest::where('token',$request->token)->where('id',$request->id)->delete();
        if($suppliers = 1){
            return response()->json(['status'=>'success','message'=>'Data Deleted Successfully!']);
        }else{
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    // Show Interest
}
