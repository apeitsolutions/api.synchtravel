<?php
namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Session;
use App\Models\Show_Interest;

class ShowInterestController extends Controller
{
    // Show Interest
    public function create_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            $show_Interest                      = new Show_Interest();
            
            $show_Interest->customer_id         = $request->customer_id;
            $show_Interest->token               = $request->token;
            $show_Interest->email_Address       = $request->EMAIL;
            $show_Interest->first_Name          = $request->FNAME;
            $show_Interest->last_Name           = $request->LNAME;
            $show_Interest->no_Of_Passengers    = $request->MMERGE5;
            $show_Interest->phone_No            = $request->PHONE;
            $show_Interest->street_Address      = $request->ADDRESS['addr1'];
            $show_Interest->city                = $request->ADDRESS['city'];
            $show_Interest->post_Code           = $request->ADDRESS['zip'];
            $show_Interest->country             = $request->ADDRESS['country'];
            
            $show_Interest->save();
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Data Added Successfully!']);
            
        } catch (Throwable $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function view_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            $Show_Interest = Show_Interest::where('customer_id',$request->customer_id)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','Show_Interest'=>$Show_Interest]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function view_single_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            $Show_Interest = Show_Interest::where('customer_id',$request->customer_id)->where('id',$request->id)->first();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','Show_Interest'=>$Show_Interest]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function deleteseat_ShowInterest(Request $request){
        $suppliers = Show_Interest::where('customer_id',$request->customer_id)->where('id',$request->id)->delete();
        if($suppliers = 1){
            return response()->json(['message'=>'success']);   
        }else{
            return response()->json(['message'=>'error']);
        }
    }
    // Show Interest
    
    public function editseat_ShowInterest(Request $request){
        $flights_details        = DB::table('flight_rute')->where('customer_id',$request->customer_id)->where('id',$request->id)->first();
        $flight_seats_occupied  = DB::table('flight_seats_occupied')->where('token',$request->token)->where('flight_route_id',$request->id)->sum('flight_route_seats_occupied');
        
        $suppliers          = DB::table('supplier')->where('customer_id',$request->customer_id)->get();
        $flight_supplier    = [];
        foreach($suppliers as $key => $suppliersz){
            $type           = [];
            $all_rutes      = DB::table('flight_rute')->where('dep_supplier',$suppliersz->id)->get();
            foreach($all_rutes as $all_rutesz){
                $rute_type_of_supplier = [
                   'multi_rute' => $all_rutesz->dep_flight_type,
                ];
                array_push($type,$rute_type_of_supplier);
            }
            $rute_type_of_supplier = [   
                'multi_rute_suplier'    => $suppliersz,
                'multi_rute'            => $type,
            ];
            array_push($flight_supplier,$rute_type_of_supplier);
        }
        return response()->json(['message'=>'success','flight_supplier'=>$flight_supplier,'flights_details'=>$flights_details,'flight_seats_occupied'=>$flight_seats_occupied]);
    }

    public function updateseat_ShowInterest(Request $request){
        DB::beginTransaction(); 
        try {
            // $flight_invoice = DB::table('add_manage_invoices')->where('flight_supplier',$request->dep_supplier)
            //                 ->select('id','flight_route_type','flight_supplier','flights_details','return_flights_details','flights_Pax_details','markup_details','markup_details')->get();
            
            // if(isset($flight_invoice) && $flight_invoice != null && $flight_invoice != ''){
            //     foreach($flight_invoice as $flight_invoice_val){
                    
            //         $flights_details_E = $flight_invoice_val->flights_details;
            //         if(isset($flights_details_E) && $flights_details_E != null && $flights_details_E != ''){
            //             $flights_details = json_decode($flights_details_E);
            //             foreach($flights_details as $flights_details_val){
            //                 $flight_route_id_occupied = $flights_details_val->flight_route_id_occupied;
            //                 if($flight_route_id_occupied == $request->id){
            //                     $dep_object = json_decode($request->dep_object);
            //                     // dd($flights_details);
            //                     // dd($dep_object);
            //                 }
            //             }
            //         }
                    
            //         $return_flights_details_E = $flight_invoice_val->return_flights_details;
            //         if(isset($return_flights_details_E) && $return_flights_details_E != null && $return_flights_details_E != ''){
            //             $return_flights_details = json_decode($return_flights_details_E);
            //             // dd($return_flights_details);
            //             foreach($return_flights_details as $return_flights_details_val){
            //                 $flight_route_id_occupied = $return_flights_details_val->return_flight_route_id_occupied;
            //                 if($flight_route_id_occupied == $request->id){
            //                     $dep_object = json_decode($request->return_object);
            //                     // dd($return_flights_details);
            //                     // dd($dep_object);
            //                 }
            //             }
            //         }
                    
            //         $flights_Pax_details_E      = $flight_invoice_val->flights_Pax_details;
            //         if(isset($flights_Pax_details_E) && $flights_Pax_details_E != null && $flights_Pax_details_E != ''){
            //             $flights_Pax_details        = json_decode($flights_Pax_details_E);
            //             $currency                   = $request->currency;
            //             foreach($flights_Pax_details as $key => $flights_Pax_details_val){
            //                 $flight_route_id_occupied = $flights_Pax_details_val->flight_route_id_occupied;  
            //                 if($flight_route_id_occupied == $request->id){
                                
            //                     $total_markup_price         = 0;
            //                     $total_without_markup_price = 0;
            //                     // dd($flight_invoice);
            //                     // dd(json_decode($flight_invoice_val->markup_details));
                                
            //                     // Adult
            //                     $flights_adult_seats                                        = $flights_Pax_details_val->flights_adult_seats;
            //                     $flights_cost_per_seats_adult                               = $request->flights_per_person_price;
            //                     $flights_Pax_details[$key]->flights_cost_per_seats_adult    = $request->flights_per_person_price;
            //                     $flights_Pax_details[$key]->flights_total_cost_adult        = $flights_adult_seats * $flights_cost_per_seats_adult;
            //                     $total_without_markup_price                                 = $total_without_markup_price + $flights_adult_seats * $flights_cost_per_seats_adult;
            //                     $flights_markup_type_adult                                  = $flights_Pax_details_val->flights_markup_type_adult;
            //                     if(isset($flights_markup_type_adult) && $flights_markup_type_adult != null && $flights_markup_type_adult != '' && $flights_markup_type_adult != 'Select Markup'){
            //                         $flights_markup_price_adult     = $flights_Pax_details_val->flights_markup_price_adult;
            //                         if($flights_markup_type_adult == '%'){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_adult   = ($flights_cost_per_seats_adult * $flights_markup_price_adult/100) + $flights_cost_per_seats_adult;
            //                             $flights_sale_price_per_seat_adult                              = ($flights_cost_per_seats_adult * $flights_markup_price_adult/100) + $flights_cost_per_seats_adult;
            //                             $flights_Pax_details[$key]->flights_sale_price_adult            = $flights_sale_price_per_seat_adult * $flights_adult_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_adult * $flights_adult_seats;
            //                         }elseif($flights_markup_type_adult == $currency){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_adult   = $flights_cost_per_seats_adult + $flights_markup_price_adult;
            //                             $flights_sale_price_per_seat_adult                              = $flights_cost_per_seats_adult + $flights_markup_price_adult;
            //                             $flights_Pax_details[$key]->flights_sale_price_adult            = $flights_sale_price_per_seat_adult * $flights_adult_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_adult * $flights_adult_seats;
            //                         }
            //                     }else{
            //                         $flights_markup_price_adult                                     = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_per_seat_adult   = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_adult            = '0';
            //                     }
                                
            //                     // Child
            //                     $flights_child_seats                                        = $flights_Pax_details_val->flights_child_seats;
            //                     $flights_cost_per_seats_child                               = $request->flights_per_child_price;
            //                     $flights_Pax_details[$key]->flights_cost_per_seats_child    = $request->flights_per_child_price;
            //                     $flights_Pax_details[$key]->flights_total_cost_child        = $flights_child_seats * $flights_cost_per_seats_child;
            //                     $total_without_markup_price                                 = $total_without_markup_price + $flights_child_seats * $flights_cost_per_seats_child;
            //                     $flights_markup_type_child                                  = $flights_Pax_details_val->flights_markup_type_child;
            //                     if(isset($flights_markup_type_child) && $flights_markup_type_child != null && $flights_markup_type_child != '' && $flights_markup_type_child != 'Select Markup'){
            //                         $flights_markup_price_child     = $flights_Pax_details_val->flights_markup_price_child;
            //                         if($flights_markup_type_child == '%'){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_child   = ($flights_cost_per_seats_child * $flights_markup_price_child/100) + $flights_cost_per_seats_child;
            //                             $flights_sale_price_per_seat_child                              = ($flights_cost_per_seats_child * $flights_markup_price_child/100) + $flights_cost_per_seats_child;
            //                             $flights_Pax_details[$key]->flights_sale_price_child            = $flights_sale_price_per_seat_child * $flights_child_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_child * $flights_child_seats;
            //                         }elseif($flights_markup_type_child == $currency){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_child   = $flights_cost_per_seats_child + $flights_markup_price_child;
            //                             $flights_sale_price_per_seat_child                              = $flights_cost_per_seats_child + $flights_markup_price_child;
            //                             $flights_Pax_details[$key]->flights_sale_price_child            = $flights_sale_price_per_seat_child * $flights_child_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_child * $flights_child_seats;
            //                         }
            //                     }else{
            //                         $flights_markup_price_child                                     = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_per_seat_child   = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_child            = '0';
            //                     }
                                
            //                     // Infant
            //                     $flights_infant_seats                                       = $flights_Pax_details_val->flights_infant_seats;
            //                     $flights_cost_per_seats_infant                              = $request->flights_per_infant_price;
            //                     $flights_Pax_details[$key]->flights_cost_per_seats_infant   = $request->flights_per_infant_price;
            //                     $flights_Pax_details[$key]->flights_total_cost_infant       = $flights_infant_seats * $flights_cost_per_seats_infant;
            //                     $total_without_markup_price                                 = $total_without_markup_price + $flights_infant_seats * $flights_cost_per_seats_infant;
            //                     $flights_markup_type_infant = $flights_Pax_details_val->flights_markup_type_infant;
            //                     if(isset($flights_markup_type_infant) && $flights_markup_type_infant != null && $flights_markup_type_infant != '' && $flights_markup_type_infant != 'Select Markup'){
            //                         $flights_markup_price_infant    = $flights_Pax_details_val->flights_markup_price_infant;
            //                         if($flights_markup_type_infant == '%'){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_infant  = ($flights_cost_per_seats_infant * $flights_markup_price_infant/100) + $flights_cost_per_seats_infant;
            //                             $flights_sale_price_per_seat_infant                             = ($flights_cost_per_seats_infant * $flights_markup_price_infant/100) + $flights_cost_per_seats_infant;
            //                             $flights_Pax_details[$key]->flights_sale_price_infant           = $flights_sale_price_per_seat_infant * $flights_infant_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_infant * $flights_infant_seats;
                                        
            //                         }elseif($flights_markup_type_infant == $currency){
            //                             $flights_Pax_details[$key]->flights_sale_price_per_seat_infant  = $flights_cost_per_seats_infant + $flights_markup_price_infant;
            //                             $flights_sale_price_per_seat_infant                             = $flights_cost_per_seats_infant + $flights_markup_price_infant;
            //                             $flights_Pax_details[$key]->flights_sale_price_infant           = $flights_sale_price_per_seat_infant * $flights_infant_seats;
            //                             $total_markup_price                                             = $total_markup_price + $flights_sale_price_per_seat_infant * $flights_infant_seats;
                                        
            //                         }
            //                     }else{
            //                         $flights_markup_price_infant         = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_per_seat_infant   = '0';
            //                         $flights_Pax_details[$key]->flights_sale_price_infant            = '0';
            //                     }
                                
            //                     // $markup_details = json_decode($flight_invoice_val->markup_details);
            //                     // foreach($markup_details as $keyM => $markup_detailsS){
            //                     //     $markup_Type_Costing = $markup_detailsS->markup_Type_Costing;
            //                     //     // dd($markup_Type_Costing);
            //                     //     if($markup_Type_Costing == 'flight_Type_Costing'){
            //                     //         // dd($total_markup_price);
            //                     //         dd($total_without_markup_price);
            //                     //         $markup_details[$keyM]->markup_price            = $total_markup_price;
            //                     //         $markup_details[$keyM]->without_markup_price    = $total_without_markup_price;
            //                     //     }
            //                     // }
                                
            //                     // dd($flights_Pax_details);
                                
            //                     $flight_invoice_update  = DB::table('add_manage_invoices')->where('id',$flight_invoice_val->id)->update([
            //                         'flight_supplier'           => $request->dep_supplier,
            //                         'flights_Pax_details'       => $flights_Pax_details,
            //                     ]);
                                
            //                     // dd($flights_Pax_details);
                                
            //                 }
            //             }
            //         }
            //     }
            // }
            
            $route_id                                   = DB::table('flight_rute')->where('id',$request->id)->update([
                'dep_supplier'                          => $request->dep_supplier,
                'dep_flight_type'                       => $request->dep_flight_type,
                'dep_airline'                           => $request->dep_airline,
                'dep_no_of_stay'                        => $request->dep_no_of_stay,
                'dep_object'                            => $request->dep_object,
                
                'return_supplier'                       => $request->return_supplier,
                'return_flight_type'                    => $request->return_flight_type,
                'return_airline'                        => $request->return_airline,
                'return_no_of_stay'                     => $request->return_no_of_stay,
                'return_object'                         => $request->return_object,
                
                'flights_per_person_price'              => $request->flights_per_person_price,
                'flights_number_of_seat'                => $request->flights_number_of_seat,
                'flights_per_seat_price'                => $request->flights_per_seat_price,
                'flights_per_child_price'               => $request->flights_per_child_price,
                'flights_per_infant_price'              => $request->flights_per_infant_price,
                'flight_total_price'                    => $request->flights_total_price,
                
                'connected_flights_duration_details'    => $request->connected_flights_duration_details ?? "",
                'terms_and_conditions'                  => $request->terms_and_conditions ?? "",
            ]);
            
            DB::commit();
            if($route_id > 0){
                return response()->json(['message'=>'success']);
            }else{
                return response()->json(['message'=>'error']);
            }
            
        } catch (Throwable $e) {
            DB::rollback();
            echo $e;
            return response()->json(['message'=>'error']);
        }
    }
}
