<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Redirect;
use DB;
use App\Models\travellanda_get_hotel_detail;
use App\Models\travellanda_get_hotel;

class TBOHotel_3rdPartyBooking_Controller extends Controller
{
    // 3rd Party Api
    public function tboholidays_Hotel_Codes(){
        $data = '';
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/hotelcodelist',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
          ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $decode_Response    = json_decode($response);
        $HotelCodes         = $decode_Response->HotelCodes;
        $total_codes        = count($HotelCodes);
        // print_r($HotelCodes);die;
        for($x=0; $x<=$total_codes; $x++){
            // if()
            $code_Exist = DB::table('tboHoliday_Hotel_Codes')->where('HotelCodes',$HotelCodes[$x])->first();
            if($code_Exist == null){
                DB::table('tboHoliday_Hotel_Codes')->insert([
                    'HotelCodes' => $HotelCodes[$x],
                ]);
            }
        }
        $all_Codes = DB::table('tboHoliday_Hotel_Codes')->get();
        dd($all_Codes);
        dd('STOP');
        
        // tboHoliday_Hotel_Codes
    }
    
    public function tboholidays_Country_List(){
        $data = '';
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/CountryList',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
          ),
        ));
        
        $response = curl_exec($curl);
        echo $response;die();
        curl_close($curl);
    }
    
    public function tboholidays_City_List($country_Code){
        $data = '{"CountryCode":"'.$country_Code.'"}';
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/CityList',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
          ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $decode_Response = json_decode($response);
        return $decode_Response->CityList;
    }
    
    public function tboholidays_Search_Hotels(Request $req){
        $GuestNationality = DB::table('tboHoliday_Country_List')->where('Name',$req->Name)->first();
        if($GuestNationality != null){
            $city_list = $this->tboholidays_City_List($GuestNationality->Code);
            dd($city_list);
        }
        // dd($GuestNationality);
        $data='{
            "CheckIn": "2024-02-16",
            "CheckOut": "2024-02-17",
            "HotelCodes": "1247101",
            "GuestNationality": '.$GuestNationality->Code.',
            "PaxRooms": [{
                "Adults": 1,
                "Children": 1,
                "ChildrenAges": [ 1 ]
            }],
            "ResponseTime": 23.0,
            "IsDetailedResponse": false,
            "Filters": {
                "Refundable": false,
                "NoOfRooms": 0,
                "MealType": “All”
            }
        }';
        dd($data);
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/Search',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
          ),
        ));
        
        $response = curl_exec($curl);
        echo $response;die();
        curl_close($curl);
    }
    // 3rd Party Api
}
