<?php
namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Session;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
Use Illuminate\Support\Facades\Input as input;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\country;
use App\Models\b2b_Agents_detail;

class B2BAgentController extends Controller
{
    // Show B2B Agents
    public function view_B2B_Agents(Request $request){
        DB::beginTransaction(); 
        try {
            $b2b_Agents = DB::table('b2b_agents')->where('token',$request->token)->orderBy('id', 'DESC')->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','b2b_Agents'=>$b2b_Agents]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function approve_B2B_Agents(Request $request){
        DB::beginTransaction(); 
        try {
            DB::table('b2b_agents')->where('token',$request->token)->where('id',$request->id)->update(['approve_Status' => 1]);
            DB::commit();
            return response()->json(['status'=>'success','message'=>'B2B Agent Aprroved Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function disable_B2B_Agents(Request $request){
        DB::beginTransaction(); 
        try {
            DB::table('b2b_agents')->where('token',$request->token)->where('id',$request->id)->update(['approve_Status' => NULL]);
            DB::commit();
            return response()->json(['status'=>'success','message'=>'B2B Agent Disable Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function b2b_Agents_Profile(Request $req){
        $all_countries                      = country::all();
        $userData                           = CustomerSubcription::where('Auth_key',$req->token)->select('id','status')->first();
        if($userData){
            $agent_personal_details         = DB::table('b2b_agents')->where('id',$req->agent_id)->first();
            $all_suppliers                  = DB::table('rooms_Invoice_Supplier')->where('customer_id',$userData->id)->get();
            $currency_data                  = DB::table('mange_currencies')->where('customer_id',$userData->id)->get();
            $agents_Lead_details            = DB::table('addLead')->where('customer_id',$userData->id)->where('b2b_agent_Id',$agent_personal_details->id)->first();
            return response()->json([
                'status'                    => 'success',
                'agent_personal_details'    => $agent_personal_details,
                "currency_data"             => $currency_data,
                'all_suppliers'             => $all_suppliers,
                'all_countries'             => $all_countries,
                'agents_Lead_details'       => $agents_Lead_details,
            ]);
        }
    }
    
    public function b2b_Agents_Booking_Statement(Request $request){
        $Agents_detail      = DB::table('b2b_agents')->where('id',$request->id)->first();
        $hotel_Bookings     = DB::table('hotels_bookings')->where('customer_id',$request->customer_id)->orderBy('created_at')->get();
        $transfer_Bookings  = DB::table('transfers_new_booking')->where('customer_id',$request->customer_id)->orderBy('id', 'desc')->get();
        $invoice_Bookings   = DB::table('add_manage_invoices')->where('customer_id',$request->customer_id)->orderBy('id', 'desc')->get();
        return response()->json([
            'status'            =>'success',
            'Agents_detail'     => $Agents_detail,
            'hotel_Bookings'    => $hotel_Bookings,
            'transfer_Bookings' => $transfer_Bookings,
            'invoice_Bookings'  => $invoice_Bookings]);
    }
    
    public function b2b_Agent_Payments_List_Ajax(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->first();
        if($userData){
            $payments_list = DB::table($request->table_name)->where('Criteria',$request->criteria)->where('Content_Ids',$request->Content_Ids)->orderBy('payment_date','asc')->get();
            $customer_data = DB::table($request->person_detail_table)->where('id',$request->Content_Ids)->first();
            $currency_data = DB::table('mange_currencies')->where('customer_id',$userData->id)->get();
            return response()->json([
                "status"        => 'success',
                "payments_list" => $payments_list,
                "customer_data" => $customer_data,
                "currency_data" => $currency_data
            ]);                         
        }
        
    }
    
    function b2b2_Agent_Profile_Bookings(Request $request){
        $userData               = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $all_customers_data     = [];
        if($userData){
            $all_customers_data = $this->b2b_agent_all_bookings_details($request->agent_id);
        }
        $graph_data             = $this->createAgentYearlyGraph($request->agent_id);
        return response()->json(['message'=>'success',
            'agent_data'        => $all_customers_data,
            'graph_data'        => $graph_data
        ]);
    }
    
    public static function b2b_agent_all_bookings_details($agent_id){
        $agent_lists = DB::table('b2b_agents')->where('id',$agent_id)->get();
        
        $all_agent_data = [];
        foreach($agent_lists as $agent_res){
            $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)->get();
            $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)->get();
            
            //  print_r($agent_tour_booking);die;
            
            $booking_all_data = [];
            foreach($agent_tour_booking as $tour_res){
                $tours_costing = DB::table('tours_2')->where('tour_id',$tour_res->tour_id)->select('quad_cost_price','triple_cost_price','double_cost_price','without_acc_cost_price','child_grand_total_cost_price','infant_total_cost_price')->first();
                $booking_details    = DB::table('tours_bookings')->where('invoice_no',$tour_res->invoice_no)->first();
                //  print_r($tours_costing);
                
                $cart_all_data  = json_decode($tour_res->cart_total_data);
                $grand_profit   = 0;
                $grand_cost     = 0;
                $grand_sale     = 0;
                // Profit From Double Adults
                 
                    if($cart_all_data->double_adults > 0){
                        $double_adult_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_adults;
                        $double_profit = $cart_all_data->double_adult_total - $double_adult_total_cost;
                        $grand_profit += $double_profit;
                        $grand_cost += $double_adult_total_cost;
                        $grand_sale += $cart_all_data->double_adult_total;
                    }
                 
                // Profit From Triple Adults
                 
                    if($cart_all_data->triple_adults > 0){
                        $triple_adult_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_adults;
                        $triple_profit = $cart_all_data->triple_adult_total - $triple_adult_total_cost;
                        $grand_profit += $triple_profit;
                        $grand_cost += $triple_adult_total_cost;
                        $grand_sale += $cart_all_data->triple_adult_total;
                    }
                    
    
                 // Profit From Quad Adults
                 
                    if($cart_all_data->quad_adults > 0){
                        $quad_adult_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_adults;
                        $quad_profit = $cart_all_data->quad_adult_total - $quad_adult_total_cost;
                        $grand_profit += $quad_profit;
                         $grand_cost += $quad_adult_total_cost;
                        $grand_sale += $cart_all_data->quad_adult_total;
                    }
                 
                 // Profit From Without Acc
                 
                    if($cart_all_data->without_acc_adults > 0){
                        $without_acc_adult_total_cost = $tours_costing->without_acc_cost_price * $cart_all_data->without_acc_adults;
                        $without_acc_profit = $cart_all_data->without_acc_adult_total - $without_acc_adult_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_adult_total_cost;
                        $grand_sale += $cart_all_data->without_acc_adult_total;
                    }
                 
                 // Profit From Double Childs
                 
                    if($cart_all_data->double_childs > 0){
                        $double_child_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_childs;
                        $double_profit = $cart_all_data->double_childs_total - $double_child_total_cost;
                        $grand_profit += $double_profit;
                        $grand_cost += $double_child_total_cost;
                        $grand_sale += $cart_all_data->double_childs_total;
                    }
                 
                 // Profit From Triple Childs
                 
                   if($cart_all_data->triple_childs > 0){
                        $triple_child_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_childs;
                        $triple_profit = $cart_all_data->triple_childs_total - $triple_child_total_cost;
                        $grand_profit += $triple_profit;
                        $grand_cost += $triple_child_total_cost;
                        $grand_sale += $cart_all_data->triple_childs_total;
                    }
                    
                 // Profit From Quad Childs
                 
                    if($cart_all_data->quad_childs > 0){
                        $quad_child_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_childs;
                        $quad_profit = $cart_all_data->quad_child_total - $quad_child_total_cost;
                        $grand_profit += $quad_profit;
                        $grand_cost += $quad_child_total_cost;
                        $grand_sale += $cart_all_data->quad_child_total;
                    }
                 
                 // Profit From Without Acc Child
    
                    if($cart_all_data->children > 0){
                        $without_acc_child_total_cost = $tours_costing->child_grand_total_cost_price * $cart_all_data->children;
                        $without_acc_profit = $cart_all_data->without_acc_child_total - $without_acc_child_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_child_total_cost;
                        $grand_sale += $cart_all_data->without_acc_child_total;
                    }
    
                // Profit From Double Infant
                    if($cart_all_data->double_infant > 0){
                        $double_infant_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_infant;
                        $double_profit = $cart_all_data->double_infant_total - $double_infant_total_cost;
                        $grand_profit += $double_profit;
                         $grand_cost += $double_infant_total_cost;
                        $grand_sale += $cart_all_data->double_infant_total;
                    }
                 
                 // Profit From Triple Infant
                 
                    if($cart_all_data->triple_infant > 0){
                        $triple_infant_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_infant;
                        $triple_profit = $cart_all_data->triple_infant_total - $triple_infant_total_cost;
                        $grand_profit += $triple_profit;
                         $grand_cost += $triple_infant_total_cost;
                        $grand_sale += $cart_all_data->triple_infant_total;
                    }
                 
                 // Profit From Quad Infant
                 
                    if($cart_all_data->quad_infant > 0){
                        $quad_infant_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_infant;
                        $quad_profit = $cart_all_data->quad_infant_total - $quad_infant_total_cost;
                        $grand_profit += $quad_profit;
                         $grand_cost += $quad_infant_total_cost;
                        $grand_sale += $cart_all_data->quad_infant_total;
                    }
                 
                 // Profit From Without Acc Infant  
                 
                  if($cart_all_data->infants > 0){
                        $without_acc_infant_total_cost = $tours_costing->infant_total_cost_price * $cart_all_data->infants;
                        $without_acc_profit = $cart_all_data->without_acc_infant_total - $without_acc_infant_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_infant_total_cost;
                        $grand_sale += $cart_all_data->without_acc_infant_total;
                  }
                  
                  $over_all_dis = 0;
                //   echo "Grand Total Profit is $grand_profit "; 
                  if($cart_all_data->discount_type == 'amount'){
                      $final_profit = $grand_profit - $cart_all_data->discount_enter_am;
                  }else{
                       $discunt_am_over_all = ($cart_all_data->price * $cart_all_data->discount_enter_am) / 100;
                       $final_profit = $grand_profit - $discunt_am_over_all;
                  }
                 
                  
                 
                //  echo "Grand Total Profit is $final_profit";
                //  print_r($cart_all_data);
                
                $commission_add = '';
                if(isset($cart_all_data->customer_commsion_add_total)){
                    $commission_add = $cart_all_data->customer_commsion_add_total;
                }
    
                 $booking_data = [
                        'booking_type' => 'Package',
                        'invoice_id'=>$tour_res->invoice_no,
                        'booking_id'=>$tour_res->booking_id,
                        'tour_id'=>$tour_res->tour_id,
                        'price'=>$tour_res->tour_total_price,
                        'paid_amount'=>$tour_res->total_paid_amount,
                        'remaing_amount'=> $tour_res->tour_total_price - $tour_res->total_paid_amount,
                        'over_paid_amount'=> $tour_res->over_paid_amount,
                        'tour_name'=>$cart_all_data->name,
                        'profit'=>$final_profit,
                        'discount_am'=>$cart_all_data->discount_Price,
                        'total_cost'=>$grand_cost,
                        'total_sale'=>$grand_sale,
                        'created_at'=>$tour_res->created_at,
                        'commission_am'=>'',
                        'customer_commsion_add_total'=>$commission_add,
                        'currency'=>$tour_res->currency,
                        'confirm'=>$tour_res->confirm,
                        'lead_Name'=>$booking_details->passenger_name,
                        'passenger_detail'=>$booking_details->passenger_detail,
                     ];
                     
                  array_push($booking_all_data,$booking_data);
            }
            
            $invoices_all_data = [];
            foreach($agent_invoice_booking as $inv_res){
                
                $accomodation = json_decode($inv_res->accomodation_details);
                $accomodation_more = json_decode($inv_res->accomodation_details_more);
                $markup_details = json_decode($inv_res->markup_details);
                $more_markup_details = json_decode($inv_res->more_markup_details);
                 
                // Caluclate Flight Price 
                $grand_cost = 0;
                $grand_sale = 0;
                $flight_cost = 0;
                $flight_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'flight_Type_Costing'){
                        $flight_cost = $mark_res->without_markup_price; 
                        $flight_sale = $mark_res->markup_price; 
                    }
                }
                
                $flight_total_cost = (float)$flight_cost * (float)$inv_res->no_of_pax_days;
                $flight_total_sale = (float)$flight_sale * (float)$inv_res->no_of_pax_days;
                
                $flight_profit = $flight_total_sale - $flight_total_cost;
                
                $grand_cost += $flight_total_cost;
                $grand_sale += $flight_total_sale;
                
                // Caluclate Visa Price 
                $visa_cost = 0;
                $visa_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'visa_Type_Costing'){
                        $visa_cost = $mark_res->without_markup_price; 
                        $visa_sale = $mark_res->markup_price; 
                    }
                }
                $visa_total_cost = (float)$visa_cost * (float)$inv_res->no_of_pax_days;
                $visa_total_sale = (float)$visa_sale * (float)$inv_res->no_of_pax_days;
                $visa_profit = $visa_total_sale - $visa_total_cost;
                $grand_cost += $visa_total_cost;
                $grand_sale += $visa_total_sale;
    
                // Caluclate Transportation Price
                $trans_cost = 0;
                $trans_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'transportation_Type_Costing'){
                        $trans_cost = $mark_res->without_markup_price; 
                        $trans_sale = $mark_res->markup_price; 
                    }
                }
                $trans_total_cost = (float)$trans_cost * (float)$inv_res->no_of_pax_days;
                $trans_total_sale = (float)$trans_sale * (float)$inv_res->no_of_pax_days;
                $trans_profit = $trans_total_sale - $trans_total_cost;
                $grand_cost += $trans_total_cost;
                $grand_sale += $trans_total_sale;
                
                // Caluclate Double Room Price
                $double_total_cost = 0;
                $double_total_sale = 0;
                $double_total_profit = 0;
                if(isset($accomodation)){
                    foreach($accomodation as $accmod_res){
                        if($accmod_res->acc_type == 'Double'){
                            (float)$double_cost = $accmod_res->acc_total_amount; 
                            (float)$double_sale = $accmod_res->hotel_invoice_markup ?? 0; 
                            
                             $double_total_cost = $double_total_cost + ((float)$double_cost * (float)$accmod_res->acc_qty);
                             $double_total_sale = $double_total_sale + ((float)$double_sale * (float)$accmod_res->acc_qty);
                             $double_profit = ((float)$double_sale - (float)$double_cost) * (float)$accmod_res->acc_qty;
                             $double_total_profit = $double_total_profit + $double_profit;
                        }
                    }
                }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Double'){
                            $double_cost = $accmod_res->more_acc_total_amount; 
                            $double_sale = $accmod_res->more_hotel_invoice_markup ?? 0; 
                            $double_total_cost = $double_total_cost + ((float)$double_cost * (float)$accmod_res->more_acc_qty);
                            $double_total_sale = $double_total_sale + ((float)$double_sale * (float)$accmod_res->more_acc_qty);
                            $double_profit = ((float)$double_sale - (float)$double_cost) * (float)$accmod_res->more_acc_qty;
                            $double_total_profit = $double_total_profit + $double_profit;
                        }
                    }
                }
                $grand_cost += $double_total_cost;
                $grand_sale += $double_total_sale;
                
                // Caluclate Triple Room Price
                $triple_total_cost = 0;
                $triple_total_sale = 0;
                $triple_total_profit = 0;
                if(isset($accomodation)){
                    foreach($accomodation as $accmod_res){
                        if($accmod_res->acc_type == 'Triple'){
                            $triple_cost = (float)$accmod_res->acc_total_amount; 
                            $triple_sale = (float)$accmod_res->hotel_invoice_markup ?? 0; 
                            $triple_total_cost = $triple_total_cost + ($triple_cost * (float)$accmod_res->acc_qty);
                            $triple_total_sale = $triple_total_sale + ($triple_sale * (float)$accmod_res->acc_qty);
                            $triple_profit = ($triple_sale - $triple_cost) * (float)$accmod_res->acc_qty;
                            $triple_total_profit = $triple_total_profit + $triple_profit;
                        }
                    }
                }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Triple'){
                            $triple_cost = (float)$accmod_res->more_acc_total_amount; 
                            $triple_sale = (float)$accmod_res->more_hotel_invoice_markup ?? 0; 
                            $triple_total_cost = $triple_total_cost + ($triple_cost * (float)$accmod_res->more_acc_qty);
                            $triple_total_sale = $triple_total_sale + ($triple_sale * (float)$accmod_res->more_acc_qty);
                            $triple_profit = ($triple_sale - $triple_cost) * $accmod_res->more_acc_qty;
                            $triple_total_profit = $triple_total_profit + $triple_profit;
                        }
                    }
                }
                $grand_cost += $triple_total_cost;
                $grand_sale += $triple_total_sale;
                 
                // Caluclate Quad Room Price
                $quad_total_cost = 0;
                $quad_total_sale = 0;
                $quad_total_profit = 0;
                if(isset($accomodation)){
                            foreach($accomodation as $accmod_res){
                                if($accmod_res->acc_type == 'Quad'){
                                    $quad_cost = $accmod_res->acc_total_amount; 
                                    $quad_sale = (float)$accmod_res->hotel_invoice_markup ?? 0; 
                                    
                                     $quad_total_cost = $quad_total_cost + ($quad_cost * (float)$accmod_res->acc_qty);
                                     $quad_total_sale = $quad_total_sale + ($quad_sale * (float)$accmod_res->acc_qty);
                                     $quad_profit = ($quad_sale - $quad_cost) * (float)$accmod_res->acc_qty;
                                     $quad_total_profit = $quad_total_profit + $quad_profit;
                                }
                            }
                         }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Quad'){
                            $quad_cost = (float)$accmod_res->more_acc_total_amount; 
                            $quad_sale = (float)$accmod_res->more_hotel_invoice_markup ?? 0; 
                            $quad_total_cost = $quad_total_cost + ($quad_cost * (float)$accmod_res->more_acc_qty);
                            $quad_total_sale = $quad_total_sale + ($quad_sale * (float)$accmod_res->more_acc_qty);
                            $quad_profit = ($quad_sale - $quad_cost) * $accmod_res->more_acc_qty;
                            $quad_total_profit = $quad_total_profit + $quad_profit;
                        }
                    }
                }
                $grand_cost += $quad_total_cost;
                $grand_sale += $quad_total_sale;
                
                // Caluclate Final Price
                $Final_inv_price = $flight_total_sale + $visa_total_sale + $trans_total_sale + $double_total_sale + $triple_total_sale + $quad_total_sale;
                $Final_inv_profit = $flight_profit + $visa_profit + $trans_profit + $double_total_profit + $triple_total_profit + $quad_total_profit;
                
                $select_curreny_data = explode(' ', $inv_res->currency_conversion);
                
                $invoice_curreny = "";
                $customer_curreny_data = explode(' ', $inv_res->currency_Type_AC);
                if(isset($select_curreny_data[2])){
                    $invoice_curreny = $select_curreny_data[2];
                }
                
                $customer_curreny = $invoice_curreny;
                $customer_curreny_data = explode(' ', $inv_res->currency_Type_AC);
                if(isset($customer_curreny_data[2])){
                    $customer_curreny = $customer_curreny_data[2];
                }
                
                $profit = $inv_res->total_sale_price_all_Services - $inv_res->total_cost_price_all_Services ?? $grand_cost;
                $inv_single_data = [
                    'booking_type' => 'Invoice',
                    'invoice_id'=>$inv_res->id,
                    'price'=>$inv_res->total_sale_price_all_Services,
                    'paid_amount'=>$inv_res->total_paid_amount,
                    'remaing_amount'=> $inv_res->total_sale_price_all_Services - $inv_res->total_paid_amount,
                    'over_paid_amount'=>$inv_res->over_paid_amount,
                    'profit'=>$profit,
                    'total_cost'=> $inv_res->total_cost_price_all_Services ?? $grand_cost,
                    'total_sale'=>$inv_res->total_sale_price_all_Services,
                    'invoice_curreny'=> $invoice_curreny,
                    'customer_curreny'=>$customer_curreny,
                    'customer_total'=>$inv_res->total_sale_price_all_Services ?? $inv_res->total_sale_price_AC,
                    'created_at'=>$inv_res->created_at,
                ];
                
                // print_r($inv_single_data);
                $inv_single_data = array_merge($inv_single_data,(array)$inv_res);
                // dd($inv_single_data);
                array_push($invoices_all_data,$inv_single_data);
                 
            }
            
            $total_paid_amount          = DB::table('agents_ledgers_new')->where('b2b_agent_id',$agent_id)->where('received_id','!=',NULL)->sum('payment');
            
            $agent_quotation_booking    = DB::table('addManageQuotationPackage')->where('b2b_agent_Id',$agent_id)->where('quotation_status',NULL)->get();
            
            $agent_data = [
                'agent_id'                  => $agent_res->id,
                'agent_name'                => $agent_res->agent_Name,
                'total_paid_amount'         => $total_paid_amount,
                'agents_tour_booking'       => $booking_all_data,
                'agents_invoices_booking'   => $invoices_all_data,
                'agent_quotation_booking'   => $agent_quotation_booking,
            ];
            array_push($all_agent_data,$agent_data);         
        }
        
        return $all_agent_data;
    }
    
    public function b2b_Agents_Details_ByType(Request $request){
        $userData       = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $request_data   = $request;
        
        $agentallBookingsObject = [];
        $agent_Groups           = [];
        
        if($request_data->date_type == 'data_today_wise'){
            $today_date     = date('Y-m-d');
            $agentsInvoices = DB::table('b2b_agents')
                                ->leftJoin('add_manage_invoices', function ($join) use($today_date) {
                                    $join->on('add_manage_invoices.b2b_agent_Id', '=', 'b2b_agents.id')->whereDate('add_manage_invoices.created_at', $today_date);
                                })->where('b2b_agents.token',$userData->Auth_key)->where('b2b_agents.id',$request->id)
                                ->select('b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.first_name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('SUM(add_manage_invoices.total_sale_price_Company) as Invoices_prices_sum'))
                                ->groupBy('b2b_agents.id')->orderBy('b2b_agents.id','asc')->get();
            foreach($agentsInvoices as $val_AID){
                $booked_GD  = DB::table('addGroupsdetails')
                                ->where('group_Client_Prefix',$val_AID->agent_Refrence_No)
                                ->select('group_Name','total_Invoices','group_Passport_Count','group_Client_Prefix')
                                ->get();
                                
                if($booked_GD->isEmpty()){
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => '',
                    ];
                    array_push($agent_Groups,$data_AG);
                }else{
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => $booked_GD,
                    ];
                    array_push($agent_Groups,$data_AG);
                }
            }
            
            $agentsPackageBookings = DB::table('b2b_agents')
                                    ->leftJoin('cart_details', function ($join) use($today_date) {
                                        $join->on('cart_details.b2b_agent_name', '=', 'b2b_agents.id')->whereDate('cart_details.created_at', $today_date);
                                    })
                                    ->where('b2b_agents.token',$userData->Auth_key)
                                    ->select('b2b_agents.id', 'b2b_agents.first_name','b2b_agents.balance',DB::raw('COUNT(cart_details.id) as packages_booking'),DB::raw('SUM(cart_details.tour_total_price) as packages_prices_sum'))
                                    ->groupBy('b2b_agents.id')
                                    ->orderBy('b2b_agents.id','asc')
                                    ->get();
            foreach($agentsInvoices as $index => $invoice_res){
                $total_prices   = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                $payment_today  = DB::table('agents_ledgers_new')->where('agent_id',$invoice_res->id)->whereDate('date',$today_date)->where('received_id','!=',NULL)->sum('payment');
                $total_price    = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                
                $agentallBookingsObject[] = (Object)[
                        'agent_id' => $invoice_res->id,
                        'agent_Name' => $invoice_res->agent_Name,
                        'company_name' => $invoice_res->company_name,
                        'currency' =>  $invoice_res->currency,
                        'Invoices_booking' => $invoice_res->Invoices_booking,
                        'Invoices_prices_sum' => number_format($invoice_res->Invoices_prices_sum,2),
                        'packages_booking' => $agentsPackageBookings[$index]->packages_booking,
                        'packages_prices_sum' => number_format($agentsPackageBookings[$index]->packages_prices_sum,2),
                        'all_bookings' => $invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking,
                        'all_bookings_num_format' => number_format($invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking),
                        'total_prices' => $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,
                        'total_prices_num_format' => number_format($invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,2),
                        'Paid' => number_format($payment_today,2),
                        'remaining' => number_format($total_price - $payment_today,2)
                    ];
            }
        }
        
        if($request_data->date_type == 'data_week_wise'){
            
            $startOfWeek = Carbon::now()->startOfWeek();
            $start_date = $startOfWeek->format('Y-m-d');
            $end_date = date('Y-m-d');
            
            //  dd($today_date);
             $agentsInvoices = DB::table('b2b_agents')
                                ->leftJoin('add_manage_invoices', function ($join) use($start_date,$end_date) {
                                                    $join->on('add_manage_invoices.b2b_agent_Id', '=', 'b2b_agents.id')
                                                        ->whereDate('add_manage_invoices.created_at','>=', $start_date)
                                                        ->whereDate('add_manage_invoices.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)->where('b2b_agents.id',$request->id)
                                
                                // ->select('b2b_agents.id', 'b2b_agents.agent_Name', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('COUNT(cart_details.id) as packages_booking'))
                                ->select('b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.first_name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('SUM(add_manage_invoices.total_sale_price_Company) as Invoices_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
            foreach($agentsInvoices as $val_AID){
                $booked_GD  = DB::table('addGroupsdetails')
                                ->where('group_Client_Prefix',$val_AID->agent_Refrence_No)
                                ->select('group_Name','total_Invoices','group_Passport_Count','group_Client_Prefix')
                                ->get();
                                
                if($booked_GD->isEmpty()){
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => '',
                    ];
                    array_push($agent_Groups,$data_AG);
                }else{
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => $booked_GD,
                    ];
                    array_push($agent_Groups,$data_AG);
                }
            }
                
                $agentsPackageBookings = DB::table('b2b_agents')
                                ->leftJoin('cart_details', function ($join) use($start_date,$end_date) {
                                                    $join->on('cart_details.b2b_agent_name', '=', 'b2b_agents.id')
                                                        ->whereDate('cart_details.created_at','>=', $start_date)
                                                        ->whereDate('cart_details.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)
                                ->select('b2b_agents.id', 'b2b_agents.first_name','b2b_agents.balance',DB::raw('COUNT(cart_details.id) as packages_booking'),DB::raw('SUM(cart_details.tour_total_price) as packages_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
                
                foreach($agentsInvoices as $index => $invoice_res){
                    $total_prices = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $payment_today = DB::table('agents_ledgers_new')->where('b2b_agent_id',$invoice_res->id)
                                                   ->whereDate('date','>=', $start_date)
                                                   ->whereDate('date','<=', $end_date)
                                                   ->where('received_id','!=',NULL)
                                                   ->sum('payment');
                    $total_price = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $agentallBookingsObject[] = (Object)[
                            'agent_id' => $invoice_res->id,
                            'agent_Name' => $invoice_res->agent_Name,
                            'company_name' => $invoice_res->company_name,
                            'currency' =>  $invoice_res->currency,
                            'Invoices_booking' => $invoice_res->Invoices_booking,
                            'Invoices_prices_sum' => number_format($invoice_res->Invoices_prices_sum,2),
                            'packages_booking' => $agentsPackageBookings[$index]->packages_booking,
                            'packages_prices_sum' => number_format($agentsPackageBookings[$index]->packages_prices_sum,2),
                            'all_bookings' => $invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking,
                            'all_bookings_num_format' => number_format($invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking),
                            'total_prices' => $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,
                            'total_prices_num_format' => number_format($invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,2),
                            'Paid' => number_format($payment_today,2),
                            'remaining' => number_format($total_price - $payment_today,2)
                        ];
                }
        }
        
        if($request_data->date_type == 'data_month_wise'){
            
            $startOfMonth = Carbon::now()->startOfMonth();
            $start_date = $startOfMonth->format('Y-m-d');
            $end_date = date('Y-m-d');
            
            //  dd($today_date);
            $agentsInvoices = DB::table('b2b_agents')
                                ->leftJoin('add_manage_invoices', function ($join) use($start_date,$end_date) {
                                                    $join->on('add_manage_invoices.b2b_agent_Id', '=', 'b2b_agents.id')
                                                        ->whereDate('add_manage_invoices.created_at','>=', $start_date)
                                                        ->whereDate('add_manage_invoices.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)->where('b2b_agents.id',$request->id)
                                
                                // ->select('b2b_agents.id', 'b2b_agents.agent_Name', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('COUNT(cart_details.id) as packages_booking'))
                                ->select('b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.first_name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('SUM(add_manage_invoices.total_sale_price_Company) as Invoices_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
            
            foreach($agentsInvoices as $val_AID){
                $booked_GD  = DB::table('addGroupsdetails')
                                ->where('group_Client_Prefix',$val_AID->agent_Refrence_No)
                                ->select('group_Name','total_Invoices','group_Passport_Count','group_Client_Prefix')
                                ->get();
                                
                if($booked_GD->isEmpty()){
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => '',
                    ];
                    array_push($agent_Groups,$data_AG);
                }else{
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => $booked_GD,
                    ];
                    array_push($agent_Groups,$data_AG);
                }
            }
            
            $agentsPackageBookings =    DB::table('b2b_agents')
                                            ->leftJoin('cart_details', function ($join) use($start_date,$end_date) {
                                            $join->on('cart_details.b2b_agent_name', '=', 'b2b_agents.id')
                                                ->whereDate('cart_details.created_at','>=', $start_date)
                                                ->whereDate('cart_details.created_at','<=', $end_date);
                                            })
                                            ->where('b2b_agents.token',$userData->Auth_key)
                                            ->select('b2b_agents.id', 'b2b_agents.first_name','b2b_agents.balance',DB::raw('COUNT(cart_details.id) as packages_booking'),DB::raw('SUM(cart_details.tour_total_price) as packages_prices_sum'))
                                            ->groupBy('b2b_agents.id')
                                            ->orderBy('b2b_agents.id','asc')
                                            ->get();
            foreach($agentsInvoices as $index => $invoice_res){
                $total_prices = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                
                $payment_today = DB::table('agents_ledgers_new')->where('b2b_agent_id',$invoice_res->id)
                                               ->whereDate('date','>=', $start_date)
                                               ->whereDate('date','<=', $end_date)
                                               ->where('received_id','!=',NULL)
                                               ->sum('payment');
                $total_price = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                
                $agentallBookingsObject[] = (Object)[
                    'agent_id' => $invoice_res->id,
                    'agent_Name' => $invoice_res->agent_Name,
                    'company_name' => $invoice_res->company_name,
                    'currency' =>  $invoice_res->currency,
                    'Invoices_booking' => $invoice_res->Invoices_booking,
                    'Invoices_prices_sum' => number_format($invoice_res->Invoices_prices_sum,2),
                    'packages_booking' => $agentsPackageBookings[$index]->packages_booking,
                    'packages_prices_sum' => number_format($agentsPackageBookings[$index]->packages_prices_sum,2),
                    'all_bookings' => $invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking,
                    'all_bookings_num_format' => number_format($invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking),
                    'total_prices' => $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,
                    'total_prices_num_format' => number_format($invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,2),
                    'Paid' => number_format($payment_today,2),
                    'remaining' => number_format($total_price - $payment_today,2)
                ];
            }
        }
        
        if($request_data->date_type == 'data_year_wise'){
            
            $startOfYear    = Carbon::now()->startOfYear();
            $start_date     = $startOfYear->format('Y-m-d');
            $end_date       = date('Y-m-d');
            
            //  dd($today_date);
             $agentsInvoices = DB::table('b2b_agents')
                                ->leftJoin('add_manage_invoices', function ($join) use($start_date,$end_date) {
                                                    $join->on('add_manage_invoices.b2b_agent_Id', '=', 'b2b_agents.id')
                                                        ->whereDate('add_manage_invoices.created_at','>=', $start_date)
                                                        ->whereDate('add_manage_invoices.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)->where('b2b_agents.id',$request->id)
                                
                                // ->select('b2b_agents.id', 'b2b_agents.agent_Name', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('COUNT(cart_details.id) as packages_booking'))
                                ->select('b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.first_name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('SUM(add_manage_invoices.total_sale_price_Company) as Invoices_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
            
            foreach($agentsInvoices as $val_AID){
                $booked_GD  = DB::table('addGroupsdetails')
                                ->where('group_Client_Prefix',$val_AID->agent_Refrence_No)
                                ->select('group_Name','total_Invoices','group_Passport_Count','group_Client_Prefix')
                                ->get();
                                
                if($booked_GD->isEmpty()){
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => '',
                    ];
                    array_push($agent_Groups,$data_AG);
                }else{
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => $booked_GD,
                    ];
                    array_push($agent_Groups,$data_AG);
                }
            }
            
                $agentsPackageBookings = DB::table('b2b_agents')
                                ->leftJoin('cart_details', function ($join) use($start_date,$end_date) {
                                                    $join->on('cart_details.b2b_agent_name', '=', 'b2b_agents.id')
                                                        ->whereDate('cart_details.created_at','>=', $start_date)
                                                        ->whereDate('cart_details.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)
                                ->select('b2b_agents.id', 'b2b_agents.first_name','b2b_agents.balance',DB::raw('COUNT(cart_details.id) as packages_booking'),DB::raw('SUM(cart_details.tour_total_price) as packages_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
                                
                
                // print_r($agentsInvoices);
                // print_r($agentsPackageBookings);
                // die;
                foreach($agentsInvoices as $index => $invoice_res){
                    $total_prices = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $payment_today = DB::table('agents_ledgers_new')->where('b2b_agent_id',$invoice_res->id)
                                                   ->whereDate('date','>=', $start_date)
                                                   ->whereDate('date','<=', $end_date)
                                                   ->where('received_id','!=',NULL)
                                                   ->sum('payment');
                    $total_price = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $agentallBookingsObject[] = (Object)[
                            'agent_id' => $invoice_res->id,
                            'agent_Name' => $invoice_res->agent_Name,
                            'company_name' => $invoice_res->company_name,
                            'currency' =>  $invoice_res->currency,
                            'Invoices_booking' => $invoice_res->Invoices_booking,
                            'Invoices_prices_sum' => number_format($invoice_res->Invoices_prices_sum,2),
                            'packages_booking' => $agentsPackageBookings[$index]->packages_booking,
                            'packages_prices_sum' => number_format($agentsPackageBookings[$index]->packages_prices_sum,2),
                            'all_bookings' => $invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking,
                            'all_bookings_num_format' => number_format($invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking),
                            'total_prices' => $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,
                            'total_prices_num_format' => number_format($invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,2),
                            'Paid' => number_format($payment_today,2),
                            'remaining' => number_format($total_price - $payment_today,2)
                        ];
                }
        }
        
        if($request_data->date_type == 'data_wise'){
            $start_date = $request_data->start_date;
            $end_date   = $request_data->end_date;
            
            //  dd($today_date);
             $agentsInvoices = DB::table('b2b_agents')
                                ->leftJoin('add_manage_invoices', function ($join) use($start_date,$end_date) {
                                                    $join->on('add_manage_invoices.b2b_agent_Id', '=', 'b2b_agents.id')
                                                        ->whereDate('add_manage_invoices.created_at','>=', $start_date)
                                                        ->whereDate('add_manage_invoices.created_at','<=', $end_date);
                                                })
                                ->where('b2b_agents.token',$userData->Auth_key)->where('b2b_agents.id',$request->id)
                                
                                // ->select('b2b_agents.id', 'b2b_agents.agent_Name', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('COUNT(cart_details.id) as packages_booking'))
                                // 'b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.agent_Name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency'
                                ->select('b2b_agents.id','b2b_agents.agent_Refrence_No', 'b2b_agents.first_name','b2b_agents.company_name','b2b_agents.balance','b2b_agents.currency', DB::raw('COUNT(add_manage_invoices.id) as Invoices_booking'),DB::raw('SUM(add_manage_invoices.total_sale_price_Company) as Invoices_prices_sum'))
                                ->groupBy('b2b_agents.id')
                                ->orderBy('b2b_agents.id','asc')
                                ->get();
            foreach($agentsInvoices as $val_AID){
                $booked_GD  = DB::table('addGroupsdetails')
                                ->where('group_Client_Prefix',$val_AID->agent_Refrence_No)
                                ->select('group_Name','total_Invoices','group_Passport_Count','group_Client_Prefix')
                                ->get();
                                
                if($booked_GD->isEmpty()){
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => '',
                    ];
                    array_push($agent_Groups,$data_AG);
                }else{
                    $data_AG = [
                        'agent_ID'  => $val_AID->id,
                        'agent_RN'  => $val_AID->agent_Refrence_No,
                        'booked_GD' => $booked_GD,
                    ];
                    array_push($agent_Groups,$data_AG);
                }
            }
            
            $agentsPackageBookings  = DB::table('b2b_agents')
                                        ->leftJoin('cart_details', function ($join) use($start_date,$end_date) {
                                            $join->on('cart_details.b2b_agent_name', '=', 'b2b_agents.id')
                                            ->whereDate('cart_details.created_at','>=', $start_date)
                                            ->whereDate('cart_details.created_at','<=', $end_date);
                                        })
                                        ->where('b2b_agents.token',$userData->Auth_key)
                                        ->select('b2b_agents.id', 'b2b_agents.first_name','b2b_agents.balance',DB::raw('COUNT(cart_details.id) as packages_booking'),DB::raw('SUM(cart_details.tour_total_price) as packages_prices_sum'))
                                        ->groupBy('b2b_agents.id')
                                        ->orderBy('b2b_agents.id','asc')
                                        ->get();
                foreach($agentsInvoices as $index => $invoice_res){
                    $total_prices = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $payment_today = DB::table('agents_ledgers_new')->where('b2b_agent_id',$invoice_res->id)
                                                   ->whereDate('date','>=', $start_date)
                                                   ->whereDate('date','<=', $end_date)
                                                   ->where('received_id','!=',NULL)
                                                   ->sum('payment');
                    $total_price = $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum;
                    
                    $agentallBookingsObject[] = (Object)[
                            'agent_id' => $invoice_res->id,
                            'agent_Name' => $invoice_res->agent_Name,
                            'company_name' => $invoice_res->company_name,
                            'currency' =>  $invoice_res->currency,
                            'Invoices_booking' => $invoice_res->Invoices_booking,
                            'Invoices_prices_sum' => number_format($invoice_res->Invoices_prices_sum,2),
                            'packages_booking' => $agentsPackageBookings[$index]->packages_booking,
                            'packages_prices_sum' => number_format($agentsPackageBookings[$index]->packages_prices_sum,2),
                            'all_bookings' => $invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking,
                            'all_bookings_num_format' => number_format($invoice_res->Invoices_booking + $agentsPackageBookings[$index]->packages_booking),
                            'total_prices' => $invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,
                            'total_prices_num_format' => number_format($invoice_res->Invoices_prices_sum + $agentsPackageBookings[$index]->packages_prices_sum,2),
                            'Paid' => number_format($payment_today,2),
                            'remaining' => number_format($total_price - $payment_today,2)
                        ];
                }
        }
        
        if($request_data->filter_type == 'total_revenue'){
            
            $agentallBookingsObject = new Collection($agentallBookingsObject);
            $agentallBookingsObject = $agentallBookingsObject->sortByDesc('total_prices');
            
            // Reindex the collection starting from 0
            $agentallBookingsObject = $agentallBookingsObject->values();
            $agentallBookingsObject = $agentallBookingsObject->toArray();
            
            if(sizeOf($agentallBookingsObject) >= 4){
                $limitedAgentData = array_slice($agentallBookingsObject, 0, 4);
            }else{
                $limitedAgentData = $agentallBookingsObject;
            }
            
            $series_data        = [];
            $categories_data    = [];
            
            // Generate Graph Data Today
            if($request_data->date_type == 'data_today_wise'){
                $date = date('Y-m-d');
                foreach($limitedAgentData as $agent_res){
                    $agent_booking_data = [$agent_res->total_prices];
                    $series_data[] = [
                        'name' => $agent_res->agent_Name,
                        'data' => $agent_booking_data
                    ];
                }
                $categories_data = [$date];
            }
            
            // Generate Graph Data For Week
            if($request_data->date_type == 'data_week_wise'){
               $today = Carbon::now();
                
                // Create a CarbonPeriod instance for the current week
               $startOfWeek = $today->startOfWeek()->toDateString();
                $endOfWeek = $today->endOfWeek()->toDateString();
                
                // Create a CarbonPeriod instance for the current week
                $period = CarbonPeriod::create($startOfWeek, $endOfWeek);
                
                // Get the dates of the current week as an array
                $datesOfWeek = [];
                foreach ($period as $date) {
                    $datesOfWeek[] = $date->toDateString();
                }
                
                // Get Data for Agent 
                
                foreach($limitedAgentData as $agent_res){
                    
                    // Loop On DatesOfWeek
                    
                    $agent_booking_data = [];
                    foreach($datesOfWeek as $date_res){
                        $agentsInvoices = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_res->agent_id)
                                                                          ->whereDate('created_at',$date_res)
                                                                          ->Sum('total_sale_price_all_Services');

                        $agentsPackageBookings =  DB::table('cart_details')->where('b2b_agent_name',$agent_res->agent_id)
                                                                  ->whereDate('created_at',$date_res)
                                                                  ->Sum('tour_total_price');
                                                                   
                        $total_booking_price = $agentsInvoices + $agentsPackageBookings;
                                        
                      
                        
                        $agent_booking_data[] = $total_booking_price;
                    }
                    
                    $series_data[] = [
                            'name' => $agent_res->agent_Name,
                            'data' => $agent_booking_data
                        ];
                }
                
                // Get Data For Categories
                
                $dayNamesOfWeek = [];
                for ($day = 0; $day < 7; $day++) {
                    $dayNamesOfWeek[] = $today->startOfWeek()->addDays($day)->format('l'); // 'l' format represents the full day name
                }
                
                $categories_data = $dayNamesOfWeek;
            }
            
            // Generate Graph Data For Month
            if($request_data->date_type == 'data_month_wise'){
                
                foreach($limitedAgentData as $agent_res){
                    
                    // Start Date Of Month
                    // $currentDate = Carbon::now();
                    $startDate = Carbon::now()->startOfMonth();
                    // $startDate = $currentDate->subMonth()->firstOfMonth();
                    $startDateWeek = $startDate->toDateString();
                    $endDate = $startDate->copy()->addDays(6);
                    $endDateWeek = $endDate->toDateString();
                    
                    $agent_booking_data = [];
                    for($i=1; $i<=5; $i++){
                        // Add 7 days to the start date
                        
                        $agentsInvoices = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_res->agent_id)
                                                                          ->whereDate('add_manage_invoices.created_at','>=', $startDate)
                                                                          ->whereDate('add_manage_invoices.created_at','<=', $endDate)
                                                                          ->Sum('total_sale_price_all_Services');

                        $agentsPackageBookings =  DB::table('cart_details')->where('b2b_agent_name',$agent_res->agent_id)
                                                                  ->whereDate('cart_details.created_at','>=', $startDate)
                                                                  ->whereDate('cart_details.created_at','<=', $endDate)
                                                                  ->Sum('tour_total_price');
                                                                   
                        $total_booking_price = $agentsInvoices + $agentsPackageBookings;
                                        
                      
                        
                        $agent_booking_data[] = $total_booking_price;
                        
                        
                        $startDate = $endDate->copy()->addDays(1);
                        if($i == '4'){
                            $endDate = $startDate->copy()->addDays(2);
                        }else{
                             $endDate = $startDate->copy()->addDays(6);
                        }
                        
                        $startDateWeek = $startDate->toDateString();
                        $endDateWeek = $endDate->toDateString();
                    }
                    
                    $series_data[] = [
                            'name' => $agent_res->agent_Name,
                            'data' => $agent_booking_data
                        ];
                }
                    
               
                    // dd($startDateWeek,$endDateWeek);
                //   print_r($weekDates);
                //   die;
                $categories_data = ['1st Week','2nd Week','3rd Week','4th Week','5th Week'];
            }
            
            // Generate Graph Data For Year
            if($request_data->date_type == 'data_year_wise'){
                
                $currentYear = date('Y');
                $monthsData = [];
            
                for ($month = 1; $month <= 12; $month++) {
                    
                     $startOfMonth = Carbon::create($currentYear, $month, 1)->startOfMonth();
                     $endOfMonth = Carbon::create($currentYear, $month, 1)->endOfMonth();
                     
                      $categories_data[] = $startOfMonth->format('F');
                     
                     $startOfMonth = $startOfMonth->format('Y-m-d');
                     $endOfMonth = $endOfMonth->format('Y-m-d');
    
                    $monthsData[] = (Object)[
                        'month' => $month,
                        'start_date' => $startOfMonth,
                        'end_date' => $endOfMonth,
                    ];
                }
                
                foreach($limitedAgentData as $agent_res){
                    
               
                    
                    $agent_booking_data = [];
                    foreach($monthsData as $month_res){
                        // Add 7 days to the start date
                        
                        $agentsInvoices = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_res->agent_id)
                                                                          ->whereDate('add_manage_invoices.created_at','>=', $month_res->start_date)
                                                                          ->whereDate('add_manage_invoices.created_at','<=', $month_res->end_date)
                                                                          ->Sum('total_sale_price_all_Services');

                        $agentsPackageBookings =  DB::table('cart_details')->where('b2b_agent_name',$agent_res->agent_id)
                                                                  ->whereDate('cart_details.created_at','>=', $month_res->start_date)
                                                                  ->whereDate('cart_details.created_at','<=', $month_res->end_date)
                                                                  ->Sum('tour_total_price');
                                                                   
                        $total_booking_price = $agentsInvoices + $agentsPackageBookings;
                                        
                      
                        
                        $agent_booking_data[] = floor($total_booking_price * 100) / 100;
                       
                    }
                    
                    $series_data[] = [
                            'name' => $agent_res->agent_Name,
                            'data' => $agent_booking_data
                        ];
                }
                // print_r($series_data);
                // die;
    
            }
            
            // Generate Graph Data For Custom Date
            if($request_data->date_type == 'data_wise'){
                $series_data        = [];
                $categories_data    = [];
                
                $startDate      = Carbon::parse($request_data->start_date);
                $currentDate    = $startDate->copy();
                $endDate        = Carbon::parse($request_data->end_date);
                $dateRange      = [];
                
                while ($currentDate->lte($endDate)) {
                    $dateRange[] = $currentDate->format('Y-m-d');
                    $currentDate->addDay();
                }
                
                // dd($limitedAgentData);
                
                $agent_res = $limitedAgentData[0] ?? '';
                if($agent_res != ''){
                    foreach ($dateRange as $date) {
                        $series_data            = [];
                        $agentsInvoices         = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_res->agent_id)
                                                    ->whereDate('add_manage_invoices.created_at', '=', $date)
                                                    ->sum('total_sale_price_all_Services');
                        $agentsPackageBookings  = DB::table('cart_details')->where('b2b_agent_name',$agent_res->agent_id)
                                                    ->whereDate('cart_details.created_at', '=', $date)
                                                    ->sum('tour_total_price');
                        $total_booking_price    = $agentsInvoices + $agentsPackageBookings; 
                        if($total_booking_price > 0){
                            $agent_booking_data[]   = $total_booking_price;
                            $series_data[]          = [
                                'name'              => $agent_res->agent_Name,
                                'data'              => $agent_booking_data
                            ];
                        }else{
                            $agent_booking_data[]   = 0;
                            $series_data[]          = [
                                'name'              => $agent_res->agent_Name,
                                'data'              => $agent_booking_data
                            ];
                        }
                        $categories_data[]          = $date;
                    }
                }
            }
            
            return response()->json([
                'status'            => 'success',
                'data'              => $limitedAgentData,
                'series_data'       => $series_data,
                // 'series_data1'      => $series_data1,
                'categories_data'   => $categories_data,
                'agent_Groups'      => $agent_Groups,
                // 'categories_data1'  => $categories_data1,
            ]);
        }else{
            $agentallBookingsObject = new Collection($agentallBookingsObject);
            
            $agentallBookingsObject = $agentallBookingsObject->sortByDesc('all_bookings');
            
            // Reindex the collection starting from 0
            $agentallBookingsObject = $agentallBookingsObject->values();
            
            $agentallBookingsObject = $agentallBookingsObject->toArray();
            
            if(sizeOf($agentallBookingsObject) >= 4){
                $limitedAgentData = array_slice($agentallBookingsObject, 0, 4);
            }else{
                $limitedAgentData = $limitedAgentData;
            }
            
            // dd($limitedAgentData);
            $series_data = [];
            $categories_data = [];
            
            // Generate Graph Data YesterDay
            if($request_data->date_type == 'data_today_wise'){
            
                $date = date('Y-m-d');
                foreach($limitedAgentData as $agent_res){
                    
                    $agent_booking_data = [$agent_res->all_bookings];
                    $series_data[] = [
                            'name' => $agent_res->agent_Name,
                            'data' => $agent_booking_data
                        ];
                }
                
                $categories_data = [$date];
            }
            
            return response()->json([
                'status'            => 'success',
                'data'              => $limitedAgentData,
                'series_data'       => $series_data,
                'categories_data'   => $categories_data,
                'agent_Groups'      => $agent_Groups,
            ]);
        }
    }
    
    function b2b_Agent_Prices_Type(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $all_customers_data = [];
        if($userData){
            $all_customers_data = $this->b2b_agent_all_bookings_details_Type($request->agent_id,$request->date_type,$request->start_date,$request->end_date);
        }
        $graph_data = $this->createAgentYearlyGraph($request->agent_id);
        return response()->json(['message'=>'success',
            'agent_data' => $all_customers_data,
            'graph_data' => $graph_data
        ]);
    }
    
    public static function b2b_agent_all_bookings_details_Type($agent_id,$date_type,$start_date,$end_date){
        $agent_lists = DB::table('b2b_agents')->where('id',$agent_id)->get();
        
        $all_agent_data = [];
        foreach($agent_lists as $agent_res){
            if($date_type == 'data_today_wise'){
                $today_date             = date('Y-m-d');
                $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)->whereDate('cart_details.created_at', $today_date)->get();
                $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)->whereDate('add_manage_invoices.created_at', $today_date)->get();
            }
            
            if($date_type == 'data_week_wise'){
                $startOfWeek            = Carbon::now()->startOfWeek();
                $start_date             = $startOfWeek->format('Y-m-d');
                $end_date               = date('Y-m-d');
                $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)
                                            ->whereDate('cart_details.created_at','>=', $start_date)->whereDate('cart_details.created_at','<=', $end_date)->get();
                $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)
                                            ->whereDate('add_manage_invoices.created_at','>=', $start_date)->whereDate('add_manage_invoices.created_at','<=', $end_date)->get();
            }
            
            if($date_type == 'data_month_wise'){
                $startOfMonth   = Carbon::now()->startOfMonth();
                $start_date     = $startOfMonth->format('Y-m-d');
                $end_date       = date('Y-m-d');
                $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)
                                            ->whereDate('cart_details.created_at','>=', $start_date)->whereDate('cart_details.created_at','<=', $end_date)->get();
                $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)
                                            ->whereDate('add_manage_invoices.created_at','>=', $start_date)->whereDate('add_manage_invoices.created_at','<=', $end_date)->get();
            }
            
            if($date_type == 'data_year_wise'){
                $startOfYear    = Carbon::now()->startOfYear();
                $start_date     = $startOfYear->format('Y-m-d');
                $end_date       = date('Y-m-d');
                $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)
                                            ->whereDate('cart_details.created_at','>=', $start_date)->whereDate('cart_details.created_at','<=', $end_date)->get();
                $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)
                                            ->whereDate('add_manage_invoices.created_at','>=', $start_date)->whereDate('add_manage_invoices.created_at','<=', $end_date)->get();
            }
            
            if($date_type == 'data_wise'){
                $start_date             = $start_date;
                $end_date               = $end_date;
                $agent_tour_booking     = DB::table('cart_details')->where('b2b_agent_name',$agent_id)
                                            ->whereDate('cart_details.created_at','>=', $start_date)->whereDate('cart_details.created_at','<=', $end_date)->get();
                $agent_invoice_booking  = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)
                                            ->whereDate('add_manage_invoices.created_at','>=', $start_date)->whereDate('add_manage_invoices.created_at','<=', $end_date)->get();
            }
            
            $booking_all_data = [];
            foreach($agent_tour_booking as $tour_res){
                 
                $tours_costing = DB::table('tours_2')->where('tour_id',$tour_res->tour_id)->select('quad_cost_price','triple_cost_price','double_cost_price','without_acc_cost_price','child_grand_total_cost_price','infant_total_cost_price')->first();
                $booking_details    = DB::table('tours_bookings')->where('invoice_no',$tour_res->invoice_no)->first();
                //  print_r($tours_costing);
                
                 
                 $cart_all_data = json_decode($tour_res->cart_total_data);
                 
                 $grand_profit = 0;
                 $grand_cost = 0;
                 $grand_sale = 0;
                 // Profit From Double Adults
                 
                    if($cart_all_data->double_adults > 0){
                        $double_adult_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_adults;
                        $double_profit = $cart_all_data->double_adult_total - $double_adult_total_cost;
                        $grand_profit += $double_profit;
                        $grand_cost += $double_adult_total_cost;
                        $grand_sale += $cart_all_data->double_adult_total;
                    }
                 
                 // Profit From Triple Adults
                 
                    if($cart_all_data->triple_adults > 0){
                        $triple_adult_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_adults;
                        $triple_profit = $cart_all_data->triple_adult_total - $triple_adult_total_cost;
                        $grand_profit += $triple_profit;
                        $grand_cost += $triple_adult_total_cost;
                        $grand_sale += $cart_all_data->triple_adult_total;
                    }
                    
    
                 // Profit From Quad Adults
                 
                    if($cart_all_data->quad_adults > 0){
                        $quad_adult_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_adults;
                        $quad_profit = $cart_all_data->quad_adult_total - $quad_adult_total_cost;
                        $grand_profit += $quad_profit;
                         $grand_cost += $quad_adult_total_cost;
                        $grand_sale += $cart_all_data->quad_adult_total;
                    }
                 
                 // Profit From Without Acc
                 
                    if($cart_all_data->without_acc_adults > 0){
                        $without_acc_adult_total_cost = $tours_costing->without_acc_cost_price * $cart_all_data->without_acc_adults;
                        $without_acc_profit = $cart_all_data->without_acc_adult_total - $without_acc_adult_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_adult_total_cost;
                        $grand_sale += $cart_all_data->without_acc_adult_total;
                    }
                 
                 // Profit From Double Childs
                 
                    if($cart_all_data->double_childs > 0){
                        $double_child_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_childs;
                        $double_profit = $cart_all_data->double_childs_total - $double_child_total_cost;
                        $grand_profit += $double_profit;
                        $grand_cost += $double_child_total_cost;
                        $grand_sale += $cart_all_data->double_childs_total;
                    }
                 
                 // Profit From Triple Childs
                 
                   if($cart_all_data->triple_childs > 0){
                        $triple_child_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_childs;
                        $triple_profit = $cart_all_data->triple_childs_total - $triple_child_total_cost;
                        $grand_profit += $triple_profit;
                        $grand_cost += $triple_child_total_cost;
                        $grand_sale += $cart_all_data->triple_childs_total;
                    }
                    
                 // Profit From Quad Childs
                 
                    if($cart_all_data->quad_childs > 0){
                        $quad_child_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_childs;
                        $quad_profit = $cart_all_data->quad_child_total - $quad_child_total_cost;
                        $grand_profit += $quad_profit;
                        $grand_cost += $quad_child_total_cost;
                        $grand_sale += $cart_all_data->quad_child_total;
                    }
                 
                 // Profit From Without Acc Child
    
                    if($cart_all_data->children > 0){
                        $without_acc_child_total_cost = $tours_costing->child_grand_total_cost_price * $cart_all_data->children;
                        $without_acc_profit = $cart_all_data->without_acc_child_total - $without_acc_child_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_child_total_cost;
                        $grand_sale += $cart_all_data->without_acc_child_total;
                    }
    
                // Profit From Double Infant
                    if($cart_all_data->double_infant > 0){
                        $double_infant_total_cost = $tours_costing->double_cost_price * $cart_all_data->double_infant;
                        $double_profit = $cart_all_data->double_infant_total - $double_infant_total_cost;
                        $grand_profit += $double_profit;
                         $grand_cost += $double_infant_total_cost;
                        $grand_sale += $cart_all_data->double_infant_total;
                    }
                 
                 // Profit From Triple Infant
                 
                    if($cart_all_data->triple_infant > 0){
                        $triple_infant_total_cost = $tours_costing->triple_cost_price * $cart_all_data->triple_infant;
                        $triple_profit = $cart_all_data->triple_infant_total - $triple_infant_total_cost;
                        $grand_profit += $triple_profit;
                         $grand_cost += $triple_infant_total_cost;
                        $grand_sale += $cart_all_data->triple_infant_total;
                    }
                 
                 // Profit From Quad Infant
                 
                    if($cart_all_data->quad_infant > 0){
                        $quad_infant_total_cost = $tours_costing->quad_cost_price * $cart_all_data->quad_infant;
                        $quad_profit = $cart_all_data->quad_infant_total - $quad_infant_total_cost;
                        $grand_profit += $quad_profit;
                         $grand_cost += $quad_infant_total_cost;
                        $grand_sale += $cart_all_data->quad_infant_total;
                    }
                 
                 // Profit From Without Acc Infant  
                 
                  if($cart_all_data->infants > 0){
                        $without_acc_infant_total_cost = $tours_costing->infant_total_cost_price * $cart_all_data->infants;
                        $without_acc_profit = $cart_all_data->without_acc_infant_total - $without_acc_infant_total_cost;
                        $grand_profit += $without_acc_profit;
                        $grand_cost += $without_acc_infant_total_cost;
                        $grand_sale += $cart_all_data->without_acc_infant_total;
                  }
                  
                  $over_all_dis = 0;
                //   echo "Grand Total Profit is $grand_profit "; 
                  if($cart_all_data->discount_type == 'amount'){
                      $final_profit = $grand_profit - $cart_all_data->discount_enter_am;
                  }else{
                       $discunt_am_over_all = ($cart_all_data->price * $cart_all_data->discount_enter_am) / 100;
                       $final_profit = $grand_profit - $discunt_am_over_all;
                  }
                 
                  
                 
                //  echo "Grand Total Profit is $final_profit";
                //  print_r($cart_all_data);
                
                $commission_add = '';
                if(isset($cart_all_data->customer_commsion_add_total)){
                    $commission_add = $cart_all_data->customer_commsion_add_total;
                }
    
                 $booking_data = [
                        'booking_type' => 'Package',
                        'invoice_id'=>$tour_res->invoice_no,
                        'booking_id'=>$tour_res->booking_id,
                        'tour_id'=>$tour_res->tour_id,
                        'price'=>$tour_res->tour_total_price,
                        'paid_amount'=>$tour_res->total_paid_amount,
                        'remaing_amount'=> $tour_res->tour_total_price - $tour_res->total_paid_amount,
                        'over_paid_amount'=> $tour_res->over_paid_amount,
                        'tour_name'=>$cart_all_data->name,
                        'profit'=>$final_profit,
                        'discount_am'=>$cart_all_data->discount_Price,
                        'total_cost'=>$grand_cost,
                        'total_sale'=>$grand_sale,
                        'created_at'=>$tour_res->created_at,
                        'commission_am'=>'',
                        'customer_commsion_add_total'=>$commission_add,
                        'currency'=>$tour_res->currency,
                        'confirm'=>$tour_res->confirm,
                        'lead_Name'=>$booking_details->passenger_name,
                        'passenger_detail'=>$booking_details->passenger_detail,
                     ];
                     
                  array_push($booking_all_data,$booking_data);
            }
            
            $invoices_all_data = [];
            foreach($agent_invoice_booking as $inv_res){
                
                $accomodation = json_decode($inv_res->accomodation_details);
                $accomodation_more = json_decode($inv_res->accomodation_details_more);
                $markup_details = json_decode($inv_res->markup_details);
                $more_markup_details = json_decode($inv_res->more_markup_details);
                 
                // Caluclate Flight Price 
                $grand_cost = 0;
                $grand_sale = 0;
                $flight_cost = 0;
                $flight_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'flight_Type_Costing'){
                        $flight_cost = $mark_res->without_markup_price; 
                        $flight_sale = $mark_res->markup_price; 
                    }
                }
                
                $flight_total_cost = (float)$flight_cost * (float)$inv_res->no_of_pax_days;
                $flight_total_sale = (float)$flight_sale * (float)$inv_res->no_of_pax_days;
                
                $flight_profit = $flight_total_sale - $flight_total_cost;
                
                $grand_cost += $flight_total_cost;
                $grand_sale += $flight_total_sale;
                
                // Caluclate Visa Price 
                $visa_cost = 0;
                $visa_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'visa_Type_Costing'){
                        $visa_cost = $mark_res->without_markup_price; 
                        $visa_sale = $mark_res->markup_price; 
                    }
                }
                $visa_total_cost = (float)$visa_cost * (float)$inv_res->no_of_pax_days;
                $visa_total_sale = (float)$visa_sale * (float)$inv_res->no_of_pax_days;
                $visa_profit = $visa_total_sale - $visa_total_cost;
                $grand_cost += $visa_total_cost;
                $grand_sale += $visa_total_sale;
    
                // Caluclate Transportation Price
                $trans_cost = 0;
                $trans_sale = 0;
                foreach($markup_details as $mark_res){
                    if($mark_res->markup_Type_Costing == 'transportation_Type_Costing'){
                        $trans_cost = $mark_res->without_markup_price; 
                        $trans_sale = $mark_res->markup_price; 
                    }
                }
                $trans_total_cost = (float)$trans_cost * (float)$inv_res->no_of_pax_days;
                $trans_total_sale = (float)$trans_sale * (float)$inv_res->no_of_pax_days;
                $trans_profit = $trans_total_sale - $trans_total_cost;
                $grand_cost += $trans_total_cost;
                $grand_sale += $trans_total_sale;
                
                // Caluclate Double Room Price
                $double_total_cost = 0;
                $double_total_sale = 0;
                $double_total_profit = 0;
                if(isset($accomodation)){
                    foreach($accomodation as $accmod_res){
                        if($accmod_res->acc_type == 'Double'){
                            (float)$double_cost = $accmod_res->acc_total_amount; 
                            (float)$double_sale = $accmod_res->hotel_invoice_markup ?? 0; 
                            
                             $double_total_cost = $double_total_cost + ((float)$double_cost * (float)$accmod_res->acc_qty);
                             $double_total_sale = $double_total_sale + ((float)$double_sale * (float)$accmod_res->acc_qty);
                             $double_profit = ((float)$double_sale - (float)$double_cost) * (float)$accmod_res->acc_qty;
                             $double_total_profit = $double_total_profit + $double_profit;
                        }
                    }
                }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Double'){
                            $double_cost = $accmod_res->more_acc_total_amount; 
                            $double_sale = $accmod_res->more_hotel_invoice_markup ?? 0; 
                            $double_total_cost = $double_total_cost + ((float)$double_cost * (float)$accmod_res->more_acc_qty);
                            $double_total_sale = $double_total_sale + ((float)$double_sale * (float)$accmod_res->more_acc_qty);
                            $double_profit = ((float)$double_sale - (float)$double_cost) * (float)$accmod_res->more_acc_qty;
                            $double_total_profit = $double_total_profit + $double_profit;
                        }
                    }
                }
                $grand_cost += $double_total_cost;
                $grand_sale += $double_total_sale;
                
                // Caluclate Triple Room Price
                $triple_total_cost = 0;
                $triple_total_sale = 0;
                $triple_total_profit = 0;
                if(isset($accomodation)){
                    foreach($accomodation as $accmod_res){
                        if($accmod_res->acc_type == 'Triple'){
                            $triple_cost = (float)$accmod_res->acc_total_amount; 
                            $triple_sale = (float)$accmod_res->hotel_invoice_markup ?? 0; 
                            $triple_total_cost = $triple_total_cost + ($triple_cost * (float)$accmod_res->acc_qty);
                            $triple_total_sale = $triple_total_sale + ($triple_sale * (float)$accmod_res->acc_qty);
                            $triple_profit = ($triple_sale - $triple_cost) * (float)$accmod_res->acc_qty;
                            $triple_total_profit = $triple_total_profit + $triple_profit;
                        }
                    }
                }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Triple'){
                            $triple_cost = (float)$accmod_res->more_acc_total_amount; 
                            $triple_sale = (float)$accmod_res->more_hotel_invoice_markup ?? 0; 
                            $triple_total_cost = $triple_total_cost + ($triple_cost * (float)$accmod_res->more_acc_qty);
                            $triple_total_sale = $triple_total_sale + ($triple_sale * (float)$accmod_res->more_acc_qty);
                            $triple_profit = ($triple_sale - $triple_cost) * $accmod_res->more_acc_qty;
                            $triple_total_profit = $triple_total_profit + $triple_profit;
                        }
                    }
                }
                $grand_cost += $triple_total_cost;
                $grand_sale += $triple_total_sale;
                 
                // Caluclate Quad Room Price
                $quad_total_cost = 0;
                $quad_total_sale = 0;
                $quad_total_profit = 0;
                if(isset($accomodation)){
                            foreach($accomodation as $accmod_res){
                                if($accmod_res->acc_type == 'Quad'){
                                    $quad_cost = $accmod_res->acc_total_amount; 
                                    $quad_sale = (float)$accmod_res->hotel_invoice_markup ?? 0; 
                                    
                                     $quad_total_cost = $quad_total_cost + ($quad_cost * (float)$accmod_res->acc_qty);
                                     $quad_total_sale = $quad_total_sale + ($quad_sale * (float)$accmod_res->acc_qty);
                                     $quad_profit = ($quad_sale - $quad_cost) * (float)$accmod_res->acc_qty;
                                     $quad_total_profit = $quad_total_profit + $quad_profit;
                                }
                            }
                         }
                if(isset($accomodation_more)){
                    foreach($accomodation_more as $accmod_res){
                        if($accmod_res->more_acc_type == 'Quad'){
                            $quad_cost = (float)$accmod_res->more_acc_total_amount; 
                            $quad_sale = (float)$accmod_res->more_hotel_invoice_markup ?? 0; 
                            $quad_total_cost = $quad_total_cost + ($quad_cost * (float)$accmod_res->more_acc_qty);
                            $quad_total_sale = $quad_total_sale + ($quad_sale * (float)$accmod_res->more_acc_qty);
                            $quad_profit = ($quad_sale - $quad_cost) * $accmod_res->more_acc_qty;
                            $quad_total_profit = $quad_total_profit + $quad_profit;
                        }
                    }
                }
                $grand_cost += $quad_total_cost;
                $grand_sale += $quad_total_sale;
                
                // Caluclate Final Price
                $Final_inv_price = $flight_total_sale + $visa_total_sale + $trans_total_sale + $double_total_sale + $triple_total_sale + $quad_total_sale;
                $Final_inv_profit = $flight_profit + $visa_profit + $trans_profit + $double_total_profit + $triple_total_profit + $quad_total_profit;
                
                $select_curreny_data = explode(' ', $inv_res->currency_conversion);
                
                $invoice_curreny = "";
                $customer_curreny_data = explode(' ', $inv_res->currency_Type_AC);
                if(isset($select_curreny_data[2])){
                    $invoice_curreny = $select_curreny_data[2];
                }
                
                $customer_curreny = $invoice_curreny;
                $customer_curreny_data = explode(' ', $inv_res->currency_Type_AC);
                if(isset($customer_curreny_data[2])){
                    $customer_curreny = $customer_curreny_data[2];
                }
                
                $profit = $inv_res->total_sale_price_all_Services - $inv_res->total_cost_price_all_Services ?? $grand_cost;
                $inv_single_data = [
                    'booking_type' => 'Invoice',
                    'invoice_id'=>$inv_res->id,
                    'price'=>$inv_res->total_sale_price_all_Services,
                    'paid_amount'=>$inv_res->total_paid_amount,
                    'remaing_amount'=> $inv_res->total_sale_price_all_Services - $inv_res->total_paid_amount,
                    'over_paid_amount'=>$inv_res->over_paid_amount,
                    'profit'=>$profit,
                    'total_cost'=> $inv_res->total_cost_price_all_Services ?? $grand_cost,
                    'total_sale'=>$inv_res->total_sale_price_all_Services,
                    'invoice_curreny'=> $invoice_curreny,
                    'customer_curreny'=>$customer_curreny,
                    'customer_total'=>$inv_res->total_sale_price_all_Services ?? $inv_res->total_sale_price_AC,
                    'created_at'=>$inv_res->created_at,
                ];
                
                // print_r($inv_single_data);
                $inv_single_data = array_merge($inv_single_data,(array)$inv_res);
                // dd($inv_single_data);
                array_push($invoices_all_data,$inv_single_data);
                 
            }
            
            $total_paid_amount          = DB::table('agents_ledgers_new')->where('b2b_agent_id',$agent_id)->where('received_id','!=',NULL)->sum('payment');
            
            $agent_quotation_booking    = DB::table('addManageQuotationPackage')->where('b2b_agent_Id',$agent_id)->where('quotation_status',NULL)->get();
            
            $agent_data = [
                'agent_id'                  => $agent_res->id,
                'agent_name'                => $agent_res->agent_Name,
                'total_paid_amount'         => $total_paid_amount,
                'agents_tour_booking'       => $booking_all_data,
                'agents_invoices_booking'   => $invoices_all_data,
                'agent_quotation_booking'   => $agent_quotation_booking,
            ];
            array_push($all_agent_data,$agent_data);         
        }
        
        return $all_agent_data;
    }
    
    function createAgentYearlyGraph($agent_id){
        $series_data = [];
        $categories_data = [];
        
        $currentYear = date('Y');
        $monthsData = [];
        
        for ($month = 1; $month <= 12; $month++) {
            
             $startOfMonth = Carbon::create($currentYear, $month, 1)->startOfMonth();
             $endOfMonth = Carbon::create($currentYear, $month, 1)->endOfMonth();
             
              $categories_data[] = $startOfMonth->format('F');
             
             $startOfMonth = $startOfMonth->format('Y-m-d');
             $endOfMonth = $endOfMonth->format('Y-m-d');

            $monthsData[] = (Object)[
                'month' => $month,
                'start_date' => $startOfMonth,
                'end_date' => $endOfMonth,
            ];
        }
        
        $agent_booking_data = [];
        foreach($monthsData as $month_res){
            // Add 7 days to the start date
            
            $agentInvoices = DB::table('add_manage_invoices')->where('b2b_agent_Id',$agent_id)
                                                              ->whereDate('add_manage_invoices.created_at','>=', $month_res->start_date)
                                                              ->whereDate('add_manage_invoices.created_at','<=', $month_res->end_date)
                                                              ->Sum('total_sale_price_all_Services');

            $agentPackageBookings =  DB::table('cart_details')->where('b2b_agent_name',"$agent_id")
                                                      ->whereDate('cart_details.created_at','>=', $month_res->start_date)
                                                      ->whereDate('cart_details.created_at','<=', $month_res->end_date)
                                                      ->Sum('tour_total_price');
                                                       
            $total_booking_price = $agentInvoices + $agentPackageBookings;
                            
          
            
            $agent_booking_data[] = floor($total_booking_price * 100) / 100;
           
        }
        
        $series_data[] = [
            'data' => $agent_booking_data
        ];
        
        return [
            'series_data' => $series_data,
            'categories_data' => $categories_data,
        ];
    }
    
    public function b2b_edit_Agents(Request $request){
        DB::beginTransaction(); 
        try {
            $edit_Agents    = DB::table('b2b_agents')->where('token',$request->token)->where('id',$request->id)->first();
            $countries      = DB::table('countries')->get();
            return response()->json(['status'=>'success','edit_Agents'=>$edit_Agents,'countries'=>$countries]); 
            DB::commit();
            return response()->json(['status'=>'success','message'=>'B2B Agent Disable Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function b2b_update_Agents(Request $request){
        $id                                         = $request->id;
        $Agents_detail                              = b2b_Agents_detail::find($id);
        if($Agents_detail){
            $Agents_detail->title               = $request->title;
            $Agents_detail->first_name          = $request->first_name;
            $Agents_detail->last_name           = $request->last_name;
            $Agents_detail->email               = $request->email;
            $Agents_detail->company_name        = $request->company_name;
            $Agents_detail->company_address     = $request->company_address;
            $Agents_detail->phone_no            = $request->phone_no;
            $Agents_detail->country             = $request->country;
            $Agents_detail->city                = $request->city;
            $Agents_detail->update();
            return response()->json(['status'=>'success','Success'=>'B2B Agent Updated Successful!']);
        }
        else{
            return response()->json(['Agents_detail'=>$Agents_detail,'Error'=>'Agents Not Updated!']);
        }
    }
    // Show B2B Agents
}
