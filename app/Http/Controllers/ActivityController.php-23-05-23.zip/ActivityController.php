<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerSubcription\CustomerSubcription;

use DB;
use App\Models\country;
class ActivityController extends Controller
{
    public function Error_Authenticate(){
        $Error_Message = 'Permissions denied! Please contact Synch Travel Support.';
        return view('Error_Authenticate',compact('Error_Message'));
    }
    
    public function get_activities_list(Request $request){
        $customer_id    = $request->customer_id;
        $userData       = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            if($userData->status == 1){
                $activities     = DB::table('new_activites')
                                    ->where('customer_id',$customer_id)
                                    ->select('id','title','sale_price','child_sale_price','duration','featured_image','banner_image','location','activity_content','activity_date','currency_symbol','min_people','max_people','Availibilty','activity_content','package_author','starts_rating')
                                    ->orderBy('created_at', 'desc')
                                    ->get();
                return response()->json([
                    'message'       => 'success',
                    'activities'    => $activities,
                ]);
            }else{
                return response()->json([
                    'message'       => 'error',
                ]);
            }
        }
    }
  
    public function submit_activity_cities(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $customer_id=$userData->id;
        if($userData){
            if($userData->status == 1){
                $categories=DB::table('activities_cities')->insert([
                    'title'=>$request->title,
                    'slug'=>$request->slug,
                    'image'=>$request->image,
                    'placement'=>$request->placement,
                    'description'=>$request->description,
                    'customer_id'=>$request->customer_id,
                ]);
                return response()->json(['message'=>'success']);
            }else{
                return response()->json(['message'=>'error']);
            }
        }
    }
  
    public function get_activities_list_wi_limit(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->where('status','1')->select('id','status')->first();
        $customer_id=$userData->id;
        if($userData){
            $activities=DB::table('new_activites')
                ->where('customer_id',$customer_id)
                ->select('id','title','sale_price','child_sale_price','duration','featured_image','banner_image','location','activity_content','activity_date','currency_symbol','min_people','max_people','Availibilty','activity_content','package_author','starts_rating')
                ->orderBy('created_at', 'desc')
                ->limit(4)
                ->get();
            
            $activities_cities=DB::table('activities_cities')
                ->where('customer_id',$customer_id)
                ->limit(8)
                ->get();
        
            return response()->json([
                'message'       => 'success',
                'activities'    => $activities,
                'activities_cities'    => $activities_cities,
            ]);
        }else{
            return response()->json([
                    'message'       => 'error',
                ]);
        }
    }
  
    public function get_activites_lists_wi_cities(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $customer_id=$userData->id;
        if($userData){
            if($userData->status == 1){
                $activities=DB::table('new_activites')
                ->where('customer_id',$customer_id)
                ->where('activities_city',$request->city_id)
                ->select('id','title','sale_price','child_sale_price','duration','featured_image','banner_image','location','activity_content','activity_date','currency_symbol','min_people','max_people','Availibilty','activity_content','package_author','starts_rating')
                ->orderBy('created_at', 'desc')
                ->limit(4)
                ->get();
        
            
                return response()->json([
                    'message'       => 'success',
                    'activities'    => $activities,
                ]);
            }else{
                return response()->json([
                    'message'       => 'error',
                ]);
            }
        }else{
            return response()->json([
                'message'       => 'error',
            ]);
        }
    }
  
    public function index_activities(Request $request){
        $userData       = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $customer_id    = $userData->id;
        if($userData){
            if($userData->status == 1){
                $activities     = DB::table('new_activites')
                                    ->where('customer_id',$customer_id)
                                    ->select('id','title','sale_price','child_sale_price','duration','featured_image','banner_image','location','activity_content','activity_date','currency_symbol','min_people','max_people','Availibilty','activity_content','package_author','starts_rating')
                                    ->orderBy('created_at', 'desc')->limit(10)->get();
                return response()->json([
                    'message'       => 'success',
                    'activities'    => $activities,
                ]);
            }
        }else{
            return response()->json([
                'message'       => 'error',
            ]);
        }
    }
  
    public function save_activities(Request $request){
        // echo "print from admin ";
        
        $request_data = json_decode($request->request_data);
        // print_r($request_data);
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            if($userData->status == 1){
                $generate_id=rand(0,9999999);
              
                $complete_date = explode('-',$request_data->activtiy_dates);
    
                $start_date = explode('/',$complete_date[0]);
                $month = $start_date[0];
                $day = $start_date[1];
                $year = trim($start_date[2],' ');
                $end_date = explode('/',$complete_date[1]);
                $month_end = $end_date[0];
                $month_end = trim($month_end,' ');
                $day_end = $end_date[1];
                $year_end = $end_date[2];
    
                $start_date = "$year-$month-$day";
                $end_date = "$year_end-$month_end-$day_end";
                  if(isset($request_data->activities_cities)){
                        $activities_cities = $request_data->activities_cities;
                    }else{
                        $activities_cities = "";
                    }
                    
                     DB::beginTransaction();
                     try {
                         
                        $Id = DB::table('new_activites')->insertGetId([
                          
                             'generate_id' => $generate_id,
                             'title' => $request_data->title,
                             'country' => $request_data->activity_country,
                             'city' => $request_data->activity_city,
                             'activities_city' => $activities_cities,
                             'currency_symbol' => $request_data->currency_symbol,
                             'duration' => $request_data->duration,
                             'location' => $request_data->location,
                             'activity_content' => $request_data->activity_content,
                             'categories' => $request_data->categories,
                             'tour_attributes' => $request_data->tour_attributes,
                             'min_people' => $request_data->min_people,
                             'max_people' => $request_data->max_people,
                             'video_link' => $request_data->video_link,
                             'package_feature' => $request_data->package_feature,
                             'package_author' => $request_data->package_author,
                             'publish_status' => $request_data->publish_status,
                             'Availibilty' => $request_data->Availibilty,
                             'whats_included' => $request_data->whats_included,
                             'whats_excluded' => $request_data->whats_excluded,
                             'cost_price' => $request_data->cost_price,
                             'sale_price' => $request_data->sale_price,
                             'child_cost_price' => $request_data->child_cost_price,
                             'child_sale_price' => $request_data->child_sale_price,
                             'featured_image' => $request_data->featured_image,
                             'banner_image' => $request_data->banner_image,
                             'what_expect' => $request_data->expect_arr,
                             'faqs_arr' => $request_data->faqs_arr,
                             'addtional_service_arr' => $request_data->addtional_service_arr,
                             'gallery_images' => $request_data->gallery_images,
                             'activity_date' => $request_data->activtiy_dates,
                             'checkout_message' => $request_data->checkout_message,
                             'cancellation_policy' => $request_data->cancellation_policy,
                             'meeting_and_pickups' => $request_data->meeting_and_pickups,
                             'payment_getway' => $request_data->payment_getway,
                             'payment_modes' => $request_data->payment_modes,
                             'starts_rating' => $request_data->stars_rating,
                             'start_date' => $start_date,
                             'end_date' => $end_date,
                             'customer_id' => $userData->id,
                          ]);
                          
                        if($Id){
                           
                                if(isset($request_data->activities_cities)){
                                $activities_cities = $request_data->activities_cities;
                                    }else{
                                  $activities_cities = "";
                              }
                               $data = DB::table('new_activites_batches')->insert([
                              
                                 'generate_id' => $generate_id,
                                 'title' => $request_data->title,
                                 'country' => $request_data->activity_country,
                                 'city' => $request_data->activity_city,
                                 'activities_city' => $activities_cities,
                                 'currency_symbol' => $request_data->currency_symbol,
                                 'duration' => $request_data->duration,
                                 'location' => $request_data->location,
                                 'activity_content' => $request_data->activity_content,
                                 'categories' => $request_data->categories,
                                 'tour_attributes' => $request_data->tour_attributes,
                                 'min_people' => $request_data->min_people,
                                 'max_people' => $request_data->max_people,
                                 'video_link' => $request_data->video_link,
                                 'package_feature' => $request_data->package_feature,
                                 'package_author' => $request_data->package_author,
                                 'publish_status' => $request_data->publish_status,
                                 'Availibilty' => $request_data->Availibilty,
                                 'whats_included' => $request_data->whats_included,
                                 'whats_excluded' => $request_data->whats_excluded,
                                 'cost_price' => $request_data->cost_price,
                                 'sale_price' => $request_data->sale_price,
                                 'child_cost_price' => $request_data->child_cost_price,
                                 'child_sale_price' => $request_data->child_sale_price,
                                 'featured_image' => $request_data->featured_image,
                                 'banner_image' => $request_data->banner_image,
                                 'what_expect' => $request_data->expect_arr,
                                 'faqs_arr' => $request_data->faqs_arr,
                                 'addtional_service_arr' => $request_data->addtional_service_arr,
                                 'gallery_images' => $request_data->gallery_images,
                                 'activity_date' => $request_data->activtiy_dates,
                                 'checkout_message' => $request_data->checkout_message,
                                 'meeting_and_pickups' => $request_data->meeting_and_pickups,
                                 'cancellation_policy' => $request_data->cancellation_policy,
                                 'payment_getway' => $request_data->payment_getway,
                                 'payment_modes' => $request_data->payment_modes,
                                 'customer_id' => $userData->id,
                                 'activity_id' => $Id,
                                 
                              ]);
                          
                            $record_found = DB::table('country_activities_count')
                              ->where('country_id', $request_data->activity_country)
                              ->where('customer_id', $userData->id)
                              ->exists();
                          
                            if($record_found){
                                $record_found = DB::table('country_activities_count')
                              ->where('country_id', $request_data->activity_country)
                              ->where('customer_id', $userData->id)
                              ->increment('activity_count', 1);
                            }else{
                                $data = DB::table('country_activities_count')->insert([
                                 'country_id' => $request_data->activity_country,
                                 'customer_id' => $userData->id,
                                 'activity_count' => 1,
                                    'country_img' => '',
                                ]);
                            }
    
                          return response()->json(['message'=>'success']);
                        }
                        DB::commit();  
                        } catch (Throwable $e) {

                            DB::rollback();
                            return response()->json(['message'=>'error','booking_id'=> '']);
                        }
                    
                   
            }else{
                return response()->json(['message'=>'falid']);
            }
        }else{
            return response()->json(['message'=>'falid']);
        }
    }
    
    public function update_activities(Request $request){
           $request_data = json_decode($request->request_data);
        
            $userData = CustomerSubcription::where('Auth_key',$request->token)->where('status','1')->select('id','status')->first();
            // dd($userData);
            if($userData){
                 
                    $complete_date = explode('-',$request_data->activtiy_dates);
        
                    $start_date = explode('/',$complete_date[0]);
                    $month = $start_date[0];
                    $day = $start_date[1];
                    $year = trim($start_date[2],' ');
                    $end_date = explode('/',$complete_date[1]);
                    $month_end = $end_date[0];
                    $month_end = trim($month_end,' ');
                    $day_end = $end_date[1];
                    $year_end = $end_date[2];
        
                     $start_date = "$year-$month-$day";
                    $end_date = "$year_end-$month_end-$day_end";
                  
                    $generate_id=rand(0,9999999);
                    if($request_data->package_update_type == 'new'){
                        $generate_id = $generate_id;
                    }
                    else{
                        $generate_id = $request_data->prev_generate_code;
                    }
                    
                    if(isset($request_data->activities_cities)){
                        $activities_cities = $request_data->activities_cities;
                    }
                    else{
                      $activities_cities = "";
                  }
                  DB::beginTransaction();
                     try {
                            $result = DB::table('new_activites')
                                      ->where('id', $request_data->id)
                                      ->update([
                                             'title' => $request_data->title,
                                             'generate_id' => $generate_id,
                                             'country' => $request_data->activity_country,
                                             'city' => $request_data->activity_city,
                                             'activities_city' => $activities_cities,
                                             'currency_symbol' => $request_data->currency_symbol,
                                             'duration' => $request_data->duration,
                                             'location' => $request_data->location,
                                             'activity_content' => $request_data->activity_content,
                                             'categories' => $request_data->categories,
                                             'tour_attributes' => $request_data->tour_attributes,
                                             'min_people' => $request_data->min_people,
                                             'max_people' => $request_data->max_people,
                                             'video_link' => $request_data->video_link,
                                             'package_feature' => $request_data->package_feature,
                                             'package_author' => $request_data->package_author,
                                             'publish_status' => $request_data->publish_status,
                                             'Availibilty' => $request_data->Availibilty,
                                             'whats_included' => $request_data->whats_included,
                                             'whats_excluded' => $request_data->whats_excluded,
                                             'cost_price' => $request_data->cost_price,
                                             'sale_price' => $request_data->sale_price,
                                             'child_cost_price' => $request_data->child_cost_price,
                                             'child_sale_price' => $request_data->child_sale_price,
                                             'featured_image' => $request_data->featured_image,
                                             'banner_image' => $request_data->banner_image,
                                             'what_expect' => $request_data->expect_arr,
                                             'faqs_arr' => $request_data->faqs_arr,
                                             'addtional_service_arr' => $request_data->addtional_service_arr,
                                             'gallery_images' => $request_data->gallery_images,
                                             'activity_date' => $request_data->activtiy_dates,
                                             'checkout_message' => $request_data->checkout_message,
                                             'cancellation_policy' => $request_data->cancellation_policy,
                                             'meeting_and_pickups' => $request_data->meeting_and_pickups,
                                             'payment_getway' => $request_data->payment_getway,
                                             'payment_modes' => $request_data->payment_modes,
                                             'starts_rating' => $request_data->stars_rating,
                                             'start_date' => $start_date,
                                             'end_date' => $end_date,
                                             'customer_id' => $userData->id,
                                          ]);
                          
                               
                                if($request_data->package_update_type == 'old'){
                                     if(isset($request_data->activities_cities)){
                                             $activities_cities = $request_data->activities_cities;
                                          }else{
                                              $activities_cities = "";
                                          }
                                    $data = DB::table('new_activites_batches')
                                      ->where('generate_id',$request_data->prev_generate_code)
                                      ->update([
                                     'title' => $request_data->title,
                                     'country' => $request_data->activity_country,
                                      'city' => $request_data->activity_city,
                                      'activities_city' => $activities_cities,
                                     'currency_symbol' => $request_data->currency_symbol,
                                     'duration' => $request_data->duration,
                                     'location' => $request_data->location,
                                     'activity_content' => $request_data->activity_content,
                                     'categories' => $request_data->categories,
                                     'tour_attributes' => $request_data->tour_attributes,
                                     'min_people' => $request_data->min_people,
                                     'max_people' => $request_data->max_people,
                                     'video_link' => $request_data->video_link,
                                     'package_feature' => $request_data->package_feature,
                                     'package_author' => $request_data->package_author,
                                     'publish_status' => $request_data->publish_status,
                                     'Availibilty' => $request_data->Availibilty,
                                     'whats_included' => $request_data->whats_included,
                                     'whats_excluded' => $request_data->whats_excluded,
                                     'cost_price' => $request_data->cost_price,
                                     'sale_price' => $request_data->sale_price,
                                     'child_cost_price' => $request_data->child_cost_price,
                                     'child_sale_price' => $request_data->child_sale_price,
                                     'featured_image' => $request_data->featured_image,
                                     'banner_image' => $request_data->banner_image,
                                     'what_expect' => $request_data->expect_arr,
                                     'faqs_arr' => $request_data->faqs_arr,
                                     'addtional_service_arr' => $request_data->addtional_service_arr,
                                     'gallery_images' => $request_data->gallery_images,
                                     'activity_date' => $request_data->activtiy_dates,
                                     'checkout_message' => $request_data->checkout_message,
                                     'meeting_and_pickups' => $request_data->meeting_and_pickups,
                                     'cancellation_policy' => $request_data->cancellation_policy,
                                     'payment_getway' => $request_data->payment_getway,
                                     'payment_modes' => $request_data->payment_modes,
                                     'customer_id' => $userData->id,
                                  ]);
                                }else{
                                    $data = DB::table('new_activites_batches')
                                      ->insert([
                                     'title' => $request_data->title,
                                     'generate_id' => $generate_id,
                                     'country' => $request_data->activity_country,
                                      'city' => $request_data->activity_city,
                                      'activities_city' => $request_data->activities_cities,
                                     'currency_symbol' => $request_data->currency_symbol,
                                     'duration' => $request_data->duration,
                                     'location' => $request_data->location,
                                     'activity_content' => $request_data->activity_content,
                                     'categories' => $request_data->categories,
                                     'tour_attributes' => $request_data->tour_attributes,
                                     'min_people' => $request_data->min_people,
                                     'max_people' => $request_data->max_people,
                                     'video_link' => $request_data->video_link,
                                     'package_feature' => $request_data->package_feature,
                                     'package_author' => $request_data->package_author,
                                     'publish_status' => $request_data->publish_status,
                                     'Availibilty' => $request_data->Availibilty,
                                     'whats_included' => $request_data->whats_included,
                                     'whats_excluded' => $request_data->whats_excluded,
                                     'cost_price' => $request_data->cost_price,
                                     'sale_price' => $request_data->sale_price,
                                     'child_cost_price' => $request_data->child_cost_price,
                                     'child_sale_price' => $request_data->child_sale_price,
                                     'featured_image' => $request_data->featured_image,
                                     'banner_image' => $request_data->banner_image,
                                     'what_expect' => $request_data->expect_arr,
                                     'faqs_arr' => $request_data->faqs_arr,
                                     'addtional_service_arr' => $request_data->addtional_service_arr,
                                     'gallery_images' => $request_data->gallery_images,
                                     'activity_date' => $request_data->activtiy_dates,
                                     'checkout_message' => $request_data->checkout_message,
                                     'meeting_and_pickups' => $request_data->meeting_and_pickups,
                                     'cancellation_policy' => $request_data->cancellation_policy,
                                     'payment_getway' => $request_data->payment_getway,
                                     'payment_modes' => $request_data->payment_modes,
                                     'customer_id' => $userData->id,
                                     'activity_id' => $request_data->id,
                                      ]);
                                }
                              
                                if($request_data->activity_country !== $request_data->activity_prev_country){
                                    // country::where('id', $request_data->activity_prev_country)->decrement('activites_count', 1);
                                    // country::where('id', $request_data->activity_country)->increment('activites_count', 1);
                                    
                                     $record_found = DB::table('country_activities_count')
                                      ->where('country_id', $request_data->activity_country)
                                      ->where('customer_id', $userData->id)
                                      ->exists();
                                      
                                      if($record_found){
                                            $record_found = DB::table('country_activities_count')
                                          ->where('country_id', $request_data->activity_country)
                                          ->where('customer_id', $userData->id)
                                          ->increment('activity_count', 1);
                                          
                                           $record_found = DB::table('country_activities_count')
                                          ->where('country_id', $request_data->activity_prev_country)
                                          ->where('customer_id', $userData->id)
                                          ->decrement('activity_count', 1);
                                      }else{
                                          $data = DB::table('country_activities_count')->insert([
                                         'country_id' => $request_data->activity_country,
                                         'customer_id' => $userData->id,
                                         'activity_count' => 1,
                                         'country_img' => '',
                                         ]);
                                      }
                              
        
                              }
                               DB::commit();  
                               return response()->json(['message'=>'success']);
                        } catch (Throwable $e) {

                            DB::rollback();
                            return response()->json(['message'=>'error']);
                        }
                        
                  
            }else{
                return response()->json(['message'=>'error']);
            }
        
        
    }
}
