<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Carbon\Carbon;
use DB;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\booking_customers;
use Hash;
use App\Http\Controllers\Transfer_3rdPartyBooking_Controller;

class TransfersReactController extends Controller
{
    public function transfers_All_Destinations(Request $request){
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            $transfer_Locations = [];
            if(isset($request->name_pickup_location_plc) && $request->name_pickup_location_plc != null && $request->name_pickup_location_plc != ''){
                $transfer_Locations  = DB::table('tranfer_destination')
                                        ->where('pickup_City','LIKE','%'.''.$request->name_pickup_location_plc.'%')
                                        ->where('customer_id','=',$userData->id)
                                        ->select('pickup_City')
                                        ->limit(20)
                                        ->get();
            }
            
            if(isset($request->name_drop_off_location_plc) && $request->name_drop_off_location_plc != null && $request->name_drop_off_location_plc != ''){
                $transfer_Locations  = DB::table('tranfer_destination')->where('dropof_City','LIKE','%'.''.$request->name_drop_off_location_plc.'%')
                                        ->where('customer_id','=',$userData->id)
                                        ->select('dropof_City')
                                        ->limit(20)
                                        ->get();
            }
            return response()->json(['message'=>'Success','transfer_Locations'=>$transfer_Locations]);    
        }
        return response()->json(['message'=>'error','transfer_Locations'=>[]]);    
    }
    
    public function transfers_search_new(Request $request){
        // return $request;
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        // return $userData;
        if($userData){
            $transfer_data      = DB::table('tranfer_destination')
                                    // ->where('pickup_api_City','LIKE','%'.$request->name_pickup_location_plc.'%')
                                    ->where('pickup_City','LIKE','%'.$request->name_pickup_location_plc.'%')
                                    // ->where('dropof_api_City','LIKE','%'.$request->name_drop_off_location_plc.'%')
                                    ->where('dropof_City','LIKE','%'.$request->name_drop_off_location_plc.'%')
                                    ->where('transfer_type','=',$request->trip_type)
                                    ->where('customer_id',$userData->id)
                                    ->where('available_from','<=',$request->pick_up_date)
                                    ->where('available_to','>=',$request->pick_up_date)
                                    ->get();
            // return $transfer_data;
            
            $startName_Array        = explode(',', $request->startName);
            $departure_Latitude     = $startName_Array[0];
            $destinationName_Array  = explode(',', $request->destinationName);
            $return_Latitude        = $destinationName_Array[0];
            
            $all_transfer_list = [];
            if(isset($transfer_data)){
                foreach($transfer_data as $transfer_res){
                    $supplier_details = json_decode($transfer_res->vehicle_details);
                    // return $supplier_details;
                    if(isset($supplier_details)){
                        foreach($supplier_details as $supplier_res){
                            if($supplier_res->display_on_website == 'true'){
                                $vehicle_data = DB::table('tranfer_vehicle')->where('id',$supplier_res->vehicle_id)->first();
                                // return $vehicle_data;
                                if(isset($vehicle_data->vehicle_Passenger)){
                                    // return $supplier_details;
                                    if($vehicle_data->vehicle_Passenger >= $request->passenger){
                                        
                                        $conversoin_data = DB::table('mange_currencies')->where('id',$transfer_res->conversion_type_Id)->first();
                                        
                                        if(isset($request->site_URL)){
                                            $img_URL = $request->site_URL.'/'.$vehicle_data->vehicle_image;
                                        }else{
                                            $img_URL = $vehicle_data->vehicle_image;
                                        }
                                        
                                        $pick_up_datetime   = new DateTime($request->pick_up_date . ' ' . $request->arrtime);
                                        $ret_datetime       = new DateTime($request->retdate . ' ' . $request->rettime);
                                        $duration           = $pick_up_datetime->diff($ret_datetime);
                                        $total_hours        = $duration->days * 24 + $duration->h;
                                        $total_minutes      = $total_hours * 60 + $duration->i;
                                        $total_duration     = $total_hours . " hours " . $duration->i . " minutes";
                                        
                                        $pax_Remaining = 0;
                                        if(isset($vehicle_data->pax_Booked) && $vehicle_data->pax_Booked > 0){
                                            $pax_Remaining = $vehicle_data->vehicle_Passenger - $vehicle_data->pax_Booked;
                                        }else{
                                            $pax_Remaining = $vehicle_data->vehicle_Passenger;
                                        }
                                        
                                        // return $supplier_res;
                                        
                                        $transfer_list_item = (Object)[
                                            'booking_From'              => '',
                                            'destination_id'            => $transfer_res->id,
                                            'customer_id'               => $transfer_res->customer_id,
                                            'search_passenger'          => $request->passenger,
                                            'no_of_vehicles'            => $request->no_of_vehicles,
                                            'country'                   => $request->pick_up_location_country,
                                            'pickup_date'               => $request->pick_up_date,
                                            'pickup_City'               => $transfer_res->pickup_City,
                                            'dropof_City'               => $transfer_res->dropof_City,
                                            'return_pickup_City'        => $transfer_res->return_pickup_City,
                                            'return_dropof_City'        => $transfer_res->return_dropof_City,
                                            'pickup_api_City'           => $transfer_res->pickup_api_City,
                                            'dropof_api_City'           => $transfer_res->dropof_api_City,
                                            'more_destination_details'  => $transfer_res->more_destination_details,
                                            'ziyarat_City_details'      => $transfer_res->ziyarat_City_details,
                                            'transfer_type'             => $transfer_res->transfer_type,
                                            'currency_conversion'       => $transfer_res->currency_conversion,
                                            'conversion_type_Id'        => $transfer_res->conversion_type_Id,
                                            'transfer_supplier_Id'      => $supplier_res->transfer_supplier_Id,
                                            'transfer_supplier'         => $supplier_res->transfer_supplier,
                                            'vehicle_Name'              => $supplier_res->vehicle_Name,
                                            'vehicle_image'             => $img_URL,
                                            'vehicle_Fare'              => $supplier_res->vehicle_Fare,
                                            'fare_markup_type'          => $supplier_res->fare_markup_type,
                                            'fare_markup'               => $supplier_res->fare_markup,
                                            'exchange_Rate'             => $supplier_res->exchange_Rate,
                                            'total_fare_markup'         => $supplier_res->total_fare_markup,
                                            'currency_symbol'           => $supplier_res->currency_symbol,
                                            'sale_currency'             => $conversoin_data->sale_currency ?? '',
                                            'OccupancyFrom'             => 1,
                                            'OccupancyTo'               => $vehicle_data->vehicle_Passenger ?? '',
                                            'SmallBagAllowance'         => 1,
                                            'BigBagAllowance'           => $vehicle_data->vehicle_Baggage ?? '',
                                            'TransferType'              => $transfer_res->transfer_type ?? '',
                                            'VehicleClass'              => $vehicle_data->vehicle_Type ?? '',
                                            'VehicleMake'               => $vehicle_data->vehicle_Type ?? '',
                                            'duration'                  => $total_duration ?? '',
                                            'departure_Latitude'        => $departure_Latitude ?? '',
                                            'return_Latitude'           => $return_Latitude ?? '',
                                            'deppoint'                  => $request->deppoint ?? '',
                                            'RetPoint'                  => $request->RetPoint ?? '',
                                            'pax_To_Book'               => $request->passenger ?? '0',
                                            'pax_Total'                 => $vehicle_data->vehicle_Passenger ?? '0',
                                            'pax_Booked'                => $vehicle_data->pax_Booked ?? '0',
                                            'pax_Remaining'             => $pax_Remaining,
                                            'sharing_Transfer'          => $request->sharing_Transfer ?? '',
                                            'vehicle_Id'                => $vehicle_data->id,
                                        ];
                                        
                                        if($pax_Remaining >= $request->passenger){
                                            $all_transfer_list[] = $transfer_list_item;
                                        }
                                    }
                                }
                                // print_r($vehicle_data);
                            }
                            
                            // 
                        }
                    }
                    // print_r($supplier_details);
                }
            }
            
            // return $transfer_data;
            
            $sessionID = '';
            if(isset($request->sharing_Transfer) || $request->sharing_Transfer != 1){
                // 3rd Party Api's
                $request_data           = $request;
                $trasnfer_Details_Api   = Transfer_3rdPartyBooking_Controller::search_Transfer_Api($request_data);
                
                // return $trasnfer_Details_Api;
                
                if(isset($trasnfer_Details_Api['trans']) && $trasnfer_Details_Api['trans'] != ''){
                    $details                = $trasnfer_Details_Api['details'];
                    // return $details;
                    $arrival_time_str       = $details->ArrTime;
                    $arrival_time           = DateTime::createFromFormat('Hi', $arrival_time_str);
                    $current_time           = new DateTime();
                    $time_difference        = $arrival_time->diff($current_time);
                    $days                   = $time_difference->format('%a');
                    $hours                  = $time_difference->format('%h');
                    $minutes                = $time_difference->format('%i');
                    $total_duration_message = '';
                    
                    if ($days > 0) {
                        $total_duration_message .= "$days days ";
                    }
                    
                    if ($hours > 0) {
                        $total_duration_message .= "$hours hours ";
                    }
                    
                    if ($minutes > 0) {
                        $total_duration_message .= "$minutes minutes";
                    }
                    
                    // return $trasnfer_Details_Api;
                    if(is_array($trasnfer_Details_Api['trans'])){
                        foreach($trasnfer_Details_Api['trans'] as $transfer_res){
                            $extras_Avline  = [];
                            $VehicleClass   = $transfer_res->VehicleClass ?? '';
                            $VehicleMake    = $transfer_res->VehicleMake ?? '';
                            
                            if(empty((array)$VehicleClass)) {
                                $VehicleClass = '';
                            }
                            
                            if(empty((array)$VehicleMake)) {
                                $VehicleMake = '';
                            }
                            
                            $search_Extras  = Transfer_3rdPartyBooking_Controller::search_Extras_Transfer_Api($transfer_res->BookingID,$trasnfer_Details_Api['sessionID']);
                            $data_EX        = $search_Extras->getData()->data;
                            
                            if(isset($data_EX->TransferOnly->P2PResults->errors->error)){
                                $request_Extras     = '';
                                $response_Extras    = '';
                            }else{
                                $request_Extras     = $data_EX->TransferOnly->P2PResults->Extras->Request;
                                $response_Extras    = $data_EX->TransferOnly->P2PResults->Extras->Response;
                                // return count($response_Extras->Avline);
                                foreach($response_Extras->Avline as $val_Avline){
                                    $data_extras_Avline = [
                                        'ExtrasID'              => $val_Avline->ExtrasID ?? '',
                                        'ExtrasCode'            => $val_Avline->ExtrasCode ?? '',
                                        'MaxNumberOfExtras'     => $val_Avline->MaxNumberOfExtras ?? '',
                                        'Price'                 => $val_Avline->Price ?? '',
                                        'Extras_Description'    => $val_Avline->Extras_Description ?? '',
                                    ];
                                    array_push($extras_Avline,$data_extras_Avline);
                                }
                            }
                            
                            $transfer_list_item = (Object)[
                                'booking_From'              => '3rd Party API',
                                'destination_id'            => $transfer_res->BookingID,
                                'customer_id'               => $userData->id,
                                'search_passenger'          => $request_data->passenger,
                                'no_of_vehicles'            => $request_data->no_of_vehicles,
                                'country'                   => $request_data->pick_up_location_country,
                                'pickup_date'               => $request_data->pick_up_date,
                                'pickup_City'               => $details->PlaceFrom,
                                'dropof_City'               => $details->PlaceTo,
                                'return_pickup_City'        => $transfer_res->return_pickup_City ?? '',
                                'return_dropof_City'        => $transfer_res->return_dropof_City ?? '',
                                'pickup_api_City'           => $request_data->name_pickup_location_plc ?? '',
                                'dropof_api_City'           => $request_data->name_drop_off_location_plc ?? '',
                                'more_destination_details'  => $transfer_res->more_destination_details ?? '',
                                'ziyarat_City_details'      => $transfer_res->ziyarat_City_details ?? '',
                                'transfer_type'             => $request_data->trip_type,
                                'currency_conversion'       => $details->Currency,
                                'conversion_type_Id'        => $transfer_res->conversion_type_Id ?? '1',
                                'transfer_supplier_Id'      => $transfer_res->SupplierID,
                                'transfer_supplier'         => $supplier_res->transfer_supplier ?? '',
                                'vehicle_Name'              => $transfer_res->Vehicle,
                                'vehicle_image'             => $transfer_res->VehicleImage,
                                'vehicle_Fare'              => $transfer_res->Price,
                                'fare_markup_type'          => $supplier_res->fare_markup_type ?? '',
                                'fare_markup'               => $transfer_res->fare_markup ?? '',
                                'exchange_Rate'             => $supplier_res->exchange_Rate ?? '',
                                'total_fare_markup'         => $transfer_res->Price,
                                'currency_symbol'           => $supplier_res->currency_symbol ?? $details->Currency ?? '',
                                'sale_currency'             => $conversoin_data->sale_currency ?? $details->Currency ?? '',
                                'OccupancyFrom'             => $transfer_res->OccupancyFrom ?? '0' ,
                                'OccupancyTo'               => $transfer_res->OccupancyTo ?? '0',
                                'SmallBagAllowance'         => $transfer_res->SmallBagAllowance ?? '0',
                                'BigBagAllowance'           => $transfer_res->BigBagAllowance ?? '0',
                                'TransferType'              => $transfer_res->TransferType ?? '',
                                'VehicleClass'              => $VehicleClass,
                                'VehicleMake'               => $VehicleMake,
                                'duration'                  => $total_duration_message ?? '',
                                'request_Extras'            => json_encode($request_Extras) ?? '',
                                'response_Extras'           => json_encode($response_Extras) ?? '',
                                'extras_Avline'             => json_encode($extras_Avline) ?? '',
                                'departure_Latitude'        => $departure_Latitude ?? '',
                                'return_Latitude'           => $return_Latitude ?? '',
                                'deppoint'                  => $request->deppoint ?? '',
                                'RetPoint'                  => $request->RetPoint ?? ''
                            ];
                            $all_transfer_list[] = $transfer_list_item;
                        }
                    }else{
                        $transfer_res   = $trasnfer_Details_Api['trans'];
                        $extras_Avline  = [];
                        $VehicleClass   = $transfer_res->VehicleClass ?? '';
                        $VehicleMake    = $transfer_res->VehicleMake ?? '';
                        
                        if(empty((array)$VehicleClass)) {
                            $VehicleClass = '';
                        }
                        
                        if(empty((array)$VehicleMake)) {
                            $VehicleMake = '';
                        }
                        
                        $search_Extras  = Transfer_3rdPartyBooking_Controller::search_Extras_Transfer_Api($transfer_res->BookingID,$trasnfer_Details_Api['sessionID']);
                        $data_EX        = $search_Extras->getData()->data;
                        
                        if(isset($data_EX->TransferOnly->P2PResults->errors->error)){
                            $request_Extras     = '';
                            $response_Extras    = '';
                        }else{
                            $request_Extras     = $data_EX->TransferOnly->P2PResults->Extras->Request;
                            $response_Extras    = $data_EX->TransferOnly->P2PResults->Extras->Response;
                            // return count($response_Extras->Avline);
                            foreach($response_Extras->Avline as $val_Avline){
                                $data_extras_Avline = [
                                    'ExtrasID'              => $val_Avline->ExtrasID,
                                    'ExtrasCode'            => $val_Avline->ExtrasCode,
                                    'MaxNumberOfExtras'     => $val_Avline->MaxNumberOfExtras,
                                    'Price'                 => $val_Avline->Price,
                                    'Extras_Description'    => $val_Avline->Extras_Description,
                                ];
                                array_push($extras_Avline,$data_extras_Avline);
                            }
                        }
                        
                        $transfer_list_item = (Object)[
                            'booking_From'              => '3rd Party API',
                            'destination_id'            => $transfer_res->BookingID,
                            'customer_id'               => $userData->id,
                            'search_passenger'          => $request_data->passenger,
                            'no_of_vehicles'            => $request_data->no_of_vehicles,
                            'country'                   => $request_data->pick_up_location_country,
                            'pickup_date'               => $request_data->pick_up_date,
                            'pickup_City'               => $details->PlaceFrom,
                            'dropof_City'               => $details->PlaceTo,
                            'return_pickup_City'        => $transfer_res->return_pickup_City ?? '',
                            'return_dropof_City'        => $transfer_res->return_dropof_City ?? '',
                            'pickup_api_City'           => $request_data->name_pickup_location_plc ?? '',
                            'dropof_api_City'           => $request_data->name_drop_off_location_plc ?? '',
                            'more_destination_details'  => $transfer_res->more_destination_details ?? '',
                            'ziyarat_City_details'      => $transfer_res->ziyarat_City_details ?? '',
                            'transfer_type'             => $request_data->trip_type,
                            'currency_conversion'       => $details->Currency,
                            'conversion_type_Id'        => $transfer_res->conversion_type_Id ?? '1',
                            'transfer_supplier_Id'      => $transfer_res->SupplierID,
                            'transfer_supplier'         => $supplier_res->transfer_supplier ?? '',
                            'vehicle_Name'              => $transfer_res->Vehicle,
                            'vehicle_image'             => $transfer_res->VehicleImage,
                            'vehicle_Fare'              => $transfer_res->Price,
                            'fare_markup_type'          => $supplier_res->fare_markup_type ?? '',
                            'fare_markup'               => $transfer_res->fare_markup ?? '',
                            'exchange_Rate'             => $supplier_res->exchange_Rate ?? '',
                            'total_fare_markup'         => $transfer_res->Price,
                            'currency_symbol'           => $supplier_res->currency_symbol ?? $details->Currency ?? '',
                            'sale_currency'             => $conversoin_data->sale_currency ?? $details->Currency ?? '',
                            'OccupancyFrom'             => $transfer_res->OccupancyFrom ?? '0' ,
                            'OccupancyTo'               => $transfer_res->OccupancyTo ?? '0',
                            'SmallBagAllowance'         => $transfer_res->SmallBagAllowance ?? '0',
                            'BigBagAllowance'           => $transfer_res->BigBagAllowance ?? '0',
                            'TransferType'              => $transfer_res->TransferType ?? '',
                            'VehicleClass'              => $VehicleClass,
                            'VehicleMake'               => $VehicleMake,
                            'duration'                  => $total_duration_message ?? '',
                            'request_Extras'            => json_encode($request_Extras) ?? '',
                            'response_Extras'           => json_encode($response_Extras) ?? '',
                            'extras_Avline'             => json_encode($extras_Avline) ?? '',
                            'departure_Latitude'        => $departure_Latitude ?? '',
                            'return_Latitude'           => $return_Latitude ?? '',
                            'deppoint'                  => $request->deppoint ?? '',
                            'RetPoint'                  => $request->RetPoint ?? ''
                        ];
                        $all_transfer_list[] = $transfer_list_item;
                    }
                }
                
                if(isset($trasnfer_Details_Api['sessionID']) && $trasnfer_Details_Api['sessionID'] != ''){
                    $sessionID = $trasnfer_Details_Api['sessionID'];
                }else{
                    $sessionID = '';
                }
                // 3rd Party Api's
            }
            
            return response()->json(['message'=>'Success','transfers_list'=>$all_transfer_list,'sessionID'=>$sessionID]);    
        }
        return response()->json(['message'=>'error','transfers'=>'']);    
    }
    
    public static function MailSend($request,$invoiceId){
        $mail_Send_Status   = false;
        
        // Umrah Shop
        if($request->token == config('token_UmrahShop')){
            $from_Address       = config('mail_From_Address_UmrahShop');
            $website_Title      = config('mail_Title_UmrahShop');
            $mail_Template_Key  = config('mail_Template_Key_UmrahShop');
            $website_Url        = config('website_Url_UmrahShop').'transfer_invoice';
            $mail_Send_Status   = true;
        }
        
        // Hashim Travel
        if($request->token == config('token_HashimTravel')){
            $from_Address       = config('mail_From_Address_HashimTravel');
            $website_Title      = config('mail_Title_HashimTravel');
            $mail_Template_Key  = config('mail_Template_Key_HashimTravel');
            $website_Url        = config('website_Url_HashimTravel').'transfer_invoice';
            $mail_Send_Status   = true;
        }
        
        if($mail_Send_Status != false){
            $booking_Date               = Carbon::now();
            $formatted_Booking_Date     = $booking_Date->format('d-m-Y H:i:s');
            
            $transfer_data              = json_decode($request->transfer_data);
            // return $transfer_data;
            
            // Lead
            $lead_passenger_details     = $transfer_data->lead_passenger_details;
            $lead_title                 = $lead_passenger_details->lead_title;
            $lead_first_name            = $lead_passenger_details->lead_first_name;
            $lead_last_name             = $lead_passenger_details->lead_last_name;
            $lead_email                 = $lead_passenger_details->lead_email;
            $lead_phone                 = $lead_passenger_details->lead_phone;
            
            // Price
            $transfer_price_details     = $transfer_data->transfer_price_details;
            $currency                   = $transfer_price_details->exchange_curreny_transfer ?? $transfer_price_details->original_curreny_transfer ?? '';
            $total_Price                = $transfer_price_details->exchange_price_total_transfer ?? $transfer_price_details->exchange_price_transfer ?? '' ;
            
            
            $transfer_destination_data  = json_decode($request->transfer_destination_data);
            // return $transfer_destination_data;
            $pickup_City                = $transfer_destination_data->pickup_City;
            $dropof_City                = $transfer_destination_data->dropof_City;
            // $pickup_date                = date('d-m-Y', $transfer_destination_data->pickup_date);
            $pickup_date                = date('Y-m-d',strtotime($transfer_destination_data->pickup_date));
            $no_of_vehicles             = $transfer_destination_data->no_of_vehicles ?? '0';
            
            $website_Invoice            = $website_Url.'/'.$invoiceId;
            
            $details                    = [
                'invoice_no'            => $invoiceId,
                'lead_title'            => $lead_title,
                'lead_Name'             => $lead_first_name,
                'email'                 => $lead_email,
                'contact'               => $lead_phone,
                'booking_Date'          => $formatted_Booking_Date,
                'pickup_City'           => $pickup_City,
                'dropof_City'           => $dropof_City,
                'pickup_date'           => $pickup_date,
                'no_of_vehicles'        => $no_of_vehicles,
                'price'                 => $currency.' '.$total_Price,
            ];
            // return $details;
            
            $email_Message      = '<div> <h3> Dear '.$details['lead_title'].' '.$details['lead_Name'].', </h3> <h4> Your booking has been Confirmed! Thank you for choosing our service.Below are the details of your booking:</h4> <ul><li>Invoice No: '.$details['invoice_no'].' </li> <li>Booking Date: '.$details['booking_Date'].'</li> <li>Pickup City: '.$details['pickup_City'].' </li><li>Dropoff City: '.$details['dropof_City'].' </li> <li>Pickup Date: '.$details['pickup_date'].' </li> <li>Number of Vehicle: '.$details['no_of_vehicles'].' </li></ul> <h3>Customer Details:</h3><ul><li>Name: '.$details['lead_title'].' '.$details['lead_Name'].' </li><li>Email: '.$details['email'].' </li><li>Phone Number: '.$details['contact'].' </li></ul> <h4>We look forward to providing you with a comfortable and enjoyable stay. Should you have any questions or require further assistance, please do not hesitate to contact us. <br>Thank you for choosing '.$website_Title.' </h4> <br> Invoice Link : '.$website_Invoice.' </div>';
            // return $email_Message;
            $to_Address         = $lead_email;
            $reciever_Name      = $lead_first_name;
            
            $mail_Check         = Mail3rdPartyController::mail_Check_All($from_Address,$to_Address,$reciever_Name,$email_Message,$mail_Template_Key);
            // return $mail_Check;
            
            if($mail_Check == 'Success'){
                return 'Success';
            }else{
                return 'Error';
            }
        }else{
            return 'Error';
        }
    }
    
    public function transfer_checkout_submit(Request $request){
        // return $request;
        
        // return 'STOP';
        
        $transfer_data          = json_decode($request->transfer_data);
        $lead_passenger         = $transfer_data->lead_passenger_details;
        $transfer_destination   = json_decode($request->transfer_destination_data);
        $transfer_price_data    = $transfer_data->transfer_price_details;
        $hotel_booked           = false;
        if(isset($request->hotel_booked)){
            $hotel_booked       = true;
        }
        // dd($lead_passenger);
        DB::beginTransaction();
        try {   
                if(isset($request->booking_From) && $request->booking_From != ''){
                    $booking_From           = '3rd Party Apis';
                }else{
                    $booking_From           = NULL;
                }
                
                $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status','hotel_Booking_Tag')->first();
                $booking_customer_id = "";
                $customer_exist = DB::table('booking_customers')->where('customer_id',$userData->id)->where('email',$lead_passenger->lead_email)->first();
                if(isset($customer_exist) && $customer_exist != null && $customer_exist != ''){
                    $booking_customer_id = $customer_exist->id;
                }else{
                   
                    if($lead_passenger->lead_title == "Mr"){
                       $gender = 'male';
                    }else{
                        $gender = 'female';
                    }
                    
                    $password = Hash::make('admin123');
                    
                    $customer_detail                    = new booking_customers();
                    $customer_detail->name              = $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name;
                    $customer_detail->opening_balance   = 0;
                    $customer_detail->balance           = 0;
                    $customer_detail->email             = $lead_passenger->lead_email;
                    $customer_detail->password          = $password;
                    $customer_detail->phone             = $lead_passenger->lead_phone;
                    $customer_detail->gender            = $gender;
                    $customer_detail->country           = $lead_passenger->lead_country;
                    $customer_detail->customer_id       = $userData->id;
                    $result                             = $customer_detail->save();
                    $booking_customer_id = $customer_detail->id;
                }
                
                $randomNumber   = random_int(1000000, 9999999);
                // $invoiceId      = "HH".$randomNumber;
                if(isset($userData->hotel_Booking_Tag) && $userData->hotel_Booking_Tag != null && $userData->hotel_Booking_Tag != ''){
                    $invoiceId  = $userData->hotel_Booking_Tag.$randomNumber;
                }else{
                    $invoiceId  = $randomNumber;
                }
                
                if(isset($transfer_destination->vehicle_Id) && $transfer_destination->vehicle_Id > 0){
                    
                    if($transfer_destination->pax_Remaining > 0){
                        $pax_Remaining  = $transfer_destination->pax_Remaining - $transfer_destination->pax_To_Book;
                    }else{
                        $pax_Remaining  = $transfer_destination->pax_Total - $transfer_destination->pax_To_Book;
                    }
                    $pax_To_Book        = $transfer_destination->pax_Total - $pax_Remaining;
                    
                    DB::table('tranfer_vehicle')->where('id',$transfer_destination->vehicle_Id)->update([
                        'pax_Booked'    => $pax_To_Book,
                        'pax_Remaining' => $pax_Remaining,
                    ]);
                }
                
                DB::table('transfers_new_booking')->insert([
                    'invoice_no'                    => $invoiceId,
                    'booking_status'                => 'Confirmed',
                    'payment_method'                => $request->slc_pyment_method,
                    'departure_date'                => $transfer_destination->pickup_date,
                    'no_of_paxs'                    => $transfer_price_data->no_of_paxs_transfer,
                    'hotel_booked'                  => $hotel_booked,
                    'lead_passenger_data'           => json_encode($lead_passenger),
                    'other_passenger_data'          => json_encode($transfer_data->other_passenger_details),
                    'transfer_destination_id'       => $transfer_price_data->destination_avail_id,
                    'transfer_data'                 => $request->transfer_destination_data,
                    'transfer_price_exchange'       => $transfer_price_data->exchange_price_transfer,
                    'transfer_total_price_exchange' => $transfer_price_data->exchange_price_total_transfer,
                    'exchange_currency'             => $transfer_price_data->exchange_curreny_transfer ?? '',
                    'transfer_price'                => $transfer_destination->total_fare_markup,
                    'transfer_total_price'          => $transfer_price_data->original_price_total_transfer,
                    'currency'                      => $transfer_price_data->original_curreny_transfer,
                    'booking_customer_id'           => $booking_customer_id,
                    'lead_passenger'                => $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name,
                    'customer_id'                   => $userData->id,
                    'booking_From'                  => $booking_From,
                    'response_confirm_booking'      => $request->response_confirm_booking ?? '',
                ]);
                
                if($request->token == config('token_UmrahShop') || $request->token == config('token_HashimTravel')){
                    // return $request;
                    // $invoiceId          = 'AL111111';
                    // $status_RB          = 'Confirmed';
                    $check_Mail         = self::MailSend($request,$invoiceId);
                    // return $check_Mail;
                }
                
                DB::commit();
                return response()->json(['status'=>'success','Invoice_no'=>$invoiceId]);
        } catch (Throwable $e) {
             DB::rollback();
            echo $e;
            return response()->json(['message'=>'error','booking_id'=> '']);
        }
    }
    
    public function transfer_invoice(Request $request){
        $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            $transfer_booking_data = DB::table('transfers_new_booking')->where('invoice_no',$request->invoice_no)->first();
            if($transfer_booking_data){
                return response()->json([
                    'status' => 'success',
                    'transfer_booking_data' => $transfer_booking_data
                ]);
            }else{
                return response()->json([
                    'status' => 'error',
                    'message' => "Wrong Invoice Number",
                ]);
            }
        }else{
            return response()->json([
                'status' => 'error',
                'message' => "Validation error",
            ]);
        }
    }
}