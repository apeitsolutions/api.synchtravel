<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use Carbon\Carbon;
use DB;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\booking_customers;
use Hash;

class TransfersReactController extends Controller
{
    public function transfers_search_new(Request $request)
    {
        // return $request;
        
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            //print_r($request);die();
             $transfer_data = DB::table('tranfer_destination')
                              ->where('pickup_api_City','LIKE','%'.$request->name_pickup_location_plc.'%')
                              ->where('dropof_api_City','LIKE','%'.$request->name_drop_off_location_plc.'%')
                              ->where('transfer_type','=',$request->trip_type)
                              ->where('customer_id',$userData->id)
                              ->where('available_from','<=',$request->pick_up_date)
                              ->Where('available_to','>=',$request->pick_up_date)
                               ->get();
                               
                // return $transfer_data;
                
                 //print_r($transfer_data);die();       
            $all_transfer_list = [];
            if(isset($transfer_data)){
                foreach($transfer_data as $transfer_res){
                    $supplier_details = json_decode($transfer_res->vehicle_details);
                    //print_r($supplier_details);die();   
                    if(isset($supplier_details)){
                        foreach($supplier_details as $supplier_res){
                            if($supplier_res->display_on_website == 'true'){
                                $vehicle_data = DB::table('tranfer_vehicle')->where('id',$supplier_res->vehicle_id)->first();
                                if(isset($vehicle_data->vehicle_Passenger)){
                                    if($vehicle_data->vehicle_Passenger >= $request->passenger){
                                        
                                        $conversoin_data = DB::table('mange_currencies')->where('id',$transfer_res->conversion_type_Id)->first();
                                        
                                        
                                        $transfer_list_item = (Object)[
                                                'destination_id' => $transfer_res->id,
                                                'customer_id' => $transfer_res->customer_id,
                                                'search_passenger' => $request->passenger,
                                                'no_of_vehicles' => $request->no_of_vehicles,
                                                'country' => $request->pick_up_location_country,
                                                'pickup_date' => $request->pick_up_date,
                                                'pickup_City' => $transfer_res->pickup_City,
                                                'dropof_City' => $transfer_res->dropof_City,
                                                'return_pickup_City' => $transfer_res->return_pickup_City,
                                                'return_dropof_City' => $transfer_res->return_dropof_City,
                                                'pickup_api_City' => $transfer_res->pickup_api_City,
                                                'dropof_api_City' => $transfer_res->dropof_api_City,
                                                'more_destination_details' => $transfer_res->more_destination_details,
                                                'ziyarat_City_details' => $transfer_res->ziyarat_City_details,
                                                'transfer_type' => $transfer_res->transfer_type,
                                                'currency_conversion' => $transfer_res->currency_conversion,
                                                'conversion_type_Id' => $transfer_res->conversion_type_Id,
                                                'transfer_supplier_Id' => $supplier_res->transfer_supplier_Id,
                                                'transfer_supplier' => $supplier_res->transfer_supplier,
                                                'vehicle_Name' => $supplier_res->vehicle_Name,
                                                'vehicle_image' => $vehicle_data->vehicle_image,
                                                'vehicle_Fare' => $supplier_res->vehicle_Fare,
                                                'fare_markup_type' => $supplier_res->fare_markup_type,
                                                'fare_markup' => $supplier_res->fare_markup,
                                                'exchange_Rate' => $supplier_res->exchange_Rate,
                                                'total_fare_markup' => $supplier_res->total_fare_markup,
                                                'currency_symbol' => $supplier_res->currency_symbol,
                                                'sale_currency' => $conversoin_data->sale_currency ?? '',
                                            ];
                                            
                                        $all_transfer_list[] = $transfer_list_item;
                                    }
                                }
                                // print_r($vehicle_data);
                            }
                            
                            // 
                        }
                    }
                    // print_r($supplier_details);
                }
            }
            // dd($all_transfer_list);
            
            return response()->json(['message'=>'Success','transfers_list'=>$all_transfer_list]);    
        }
        // dd($request->all());
            return response()->json(['message'=>'error','transfers'=>'']);    
    }
    
    public function transfer_checkout_submit(Request $request){
        
        $transfer_data = json_decode($request->transfer_data);
        $lead_passenger = $transfer_data->lead_passenger_details;
        $transfer_destination = json_decode($request->transfer_destination_data);
        $transfer_price_data = $transfer_data->transfer_price_details;
        $hotel_booked = false;
        if(isset($request->hotel_booked)){
            $hotel_booked = true;
        }
        // dd($lead_passenger);$transfer_price_data
         DB::beginTransaction();
        
            try {   
                    $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
                    $booking_customer_id = "";
                    $customer_exist = DB::table('booking_customers')->where('customer_id',$userData->id)->where('email',$lead_passenger->lead_email)->first();
                    if(isset($customer_exist) && $customer_exist != null && $customer_exist != ''){
                            $booking_customer_id = $customer_exist->id;
                    }else{
                       
                       if($lead_passenger->lead_title == "Mr"){
                           $gender = 'male';
                       }else{
                            $gender = 'female';
                       }
                        
                        $password = Hash::make('admin123');
                        
                        $customer_detail                    = new booking_customers();
                        $customer_detail->name              = $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name;
                        $customer_detail->opening_balance   = 0;
                        $customer_detail->balance           = 0;
                        $customer_detail->email             = $lead_passenger->lead_email;
                        $customer_detail->password             = $password;
                        $customer_detail->phone             = $lead_passenger->lead_phone;
                        $customer_detail->gender            = $gender;
                        $customer_detail->country           = $lead_passenger->lead_country;
        
                        $customer_detail->customer_id       = $userData->id;
                        $result = $customer_detail->save();
                        
                        $booking_customer_id = $customer_detail->id;
        
                        
                    }
                    
                    $randomNumber = random_int(1000000, 9999999);
                    $invoiceId =  "HH".$randomNumber;
                    

                    DB::table('transfers_new_booking')->insert([
                            'invoice_no' => $invoiceId,
                            'booking_status' => 'Confirmed',
                            'payment_method' => $request->slc_pyment_method,
                            'departure_date' => $transfer_destination->pickup_date,
                            'no_of_paxs' => $transfer_price_data->no_of_paxs_transfer,
                            'hotel_booked' => $hotel_booked,
                            'lead_passenger_data' => json_encode($lead_passenger),
                            'other_passenger_data' => json_encode($transfer_data->other_passenger_details),
                            'transfer_destination_id' => $transfer_price_data->destination_avail_id,
                            'transfer_data' => $request->transfer_destination_data,
                            'transfer_price_exchange' => $transfer_price_data->exchange_price_transfer,
                            'transfer_total_price_exchange' => $transfer_price_data->exchange_price_total_transfer,
                            'exchange_currency' => $transfer_price_data->exchange_curreny_transfer ?? '',
                            'transfer_price' => $transfer_destination->total_fare_markup,
                            'transfer_total_price' => $transfer_price_data->original_price_total_transfer,
                            'currency' => $transfer_price_data->original_curreny_transfer,
                            'booking_customer_id' => $booking_customer_id,
                            'lead_passenger' => $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name,
                            'customer_id' => $userData->id,
                            
                        ]);

                DB::commit();
                return response()->json(['status'=>'success',
                                         'Invoice_no'=>$invoiceId
                                            ]);
                
            } catch (Throwable $e) {
                 DB::rollback();
                echo $e;
                return response()->json(['message'=>'error','booking_id'=> '']);
            }
    }
    
    function transfer_invoice(Request $request){
        
        $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
            $transfer_booking_data = DB::table('transfers_new_booking')->where('invoice_no',$request->invoice_no)->first();
          
            
            if($transfer_booking_data){
                return response()->json([
                    'status' => 'success',
                    'transfer_booking_data' => $transfer_booking_data
                ]);
            }else{
                return response()->json([
                    'status' => 'error',
                    'message' => "Wrong Invoice Number",
                ]);
            }
        }else{
                return response()->json([
                    'status' => 'error',
                    'message' => "Validation error",
                ]);
            }
        
    }
}