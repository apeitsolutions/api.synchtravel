<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Redirect;
use DB;
use App\Models\travellanda_get_hotel_detail;
use App\Models\travellanda_get_hotel;

class TBOHotel_3rdPartyBooking_Controller extends Controller
{
    // 3rd Party Api
    public function tboholidays_Country_List(){
        $data = '';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/CountryList',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_POSTFIELDS =>$data,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
            ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $CountryList        = '';
        $decode_Response    = json_decode($response);
        if($decode_Response->Status){
            if($decode_Response->Status->Description == 'Success'){
                $CountryList = $decode_Response->CountryList;
            }
        }
        return $CountryList;
    }
    
    public function tboholidays_City_List_OLD(){
        $country_Codes  = DB::table('tboHoliday_Country_List')->get();
        $decode_CC      = json_decode($country_Codes);
        if(count($decode_CC) > 0){
            for($c=0; $c<=$decode_CC; $c++){
                $country_Code   = $decode_CC[$c]->Code;
                $data           = '{"CountryCode":"'.$country_Code.'"}';
                $curl           = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/CityList',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>$data,
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
                    ),
                ));
                $response = curl_exec($curl);
                // echo $response;die();
                curl_close($curl);
                $decode_Response    = json_decode($response);
                $CityList           = '';
                if($decode_Response->Status){
                    if($decode_Response->Status->Description == 'Success'){
                        $CityList   = $decode_Response->CityList;
                        $total_List = count($CityList);
                        for($x=0; $x<$total_List; $x++){
                            $code_Exist = DB::table('tboHoliday_City_List')->where('Code',$CityList[$x]->Code)->first();
                            if($code_Exist == null){
                                DB::table('tboHoliday_City_List')->insert([
                                    'Code'          => $CityList[$x]->Code,
                                    'Name'          => $CityList[$x]->Name,
                                    'CountryCode'   => $country_Code,
                                ]);
                            }
                        }
                    }
                }
            }
        }
        return 'STOP';
    }
    
    public function tboholidays_City_List($country_Code){
        $data = '{"CountryCode":"'.$country_Code.'"}';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/CityList',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>$data,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
            ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $decode_Response = json_decode($response);
        $CityList        = '';
        $decode_Response    = json_decode($response);
        if($decode_Response->Status){
            if($decode_Response->Status->Description == 'Success'){
                $CityList = $decode_Response->CityList;
            }
        }
        return $CityList;
    }
    
    public function tboholidays_Hotel_Codes(){
        $data = '';
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/hotelcodelist',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
          ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $decode_Response    = json_decode($response);
        $HotelCodes         = $decode_Response->HotelCodes;
        // return $HotelCodes;
        $total_codes        = count($HotelCodes);
        return $total_codes;
        $all_Codes          = DB::table('tboHoliday_Hotel_Codes')->get();
        if(count($all_Codes) > 0){
            $x_new = count($all_Codes);
            $x_new++;
        }else{
            $x_new = 0;
        }
        
        // 321142
        // 307640
        // 321311
        
        // dd($total_codes,$x_new,$HotelCodes);
        for($x=$x_new; $x<=$total_codes; $x++){
            $code_Exist = DB::table('tboHoliday_Hotel_Codes')->where('HotelCodes',$HotelCodes[$x])->first();
            if($code_Exist == null){
                DB::table('tboHoliday_Hotel_Codes')->insert([
                    'HotelCodes' => $HotelCodes[$x],
                ]);
            }
        }
        $all_Codes = DB::table('tboHoliday_Hotel_Codes')->get();
        return $all_Codes;
    }
    
    public function tboholidays_Hotel_Codes_OLD(){
        $data = '';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/hotelcodelist',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_POSTFIELDS =>$data,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
            ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $decode_Response    = json_decode($response);
        return $decode_Response->HotelCodes;
    }
    
    public function tboholidays_Hotel_Details($hotel_Code){
        $data = '{"Hotelcodes": '.$hotel_Code.',"Language": "EN"}';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/HotelDetails',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>$data,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
            ),
        ));
        
        $response = curl_exec($curl);
        // echo $response;die();
        curl_close($curl);
        $HotelDetails        = '';
        $decode_Response    = json_decode($response);
        if($decode_Response->Status){
            if($decode_Response->Status->Description == 'Successful'){
                $HotelDetails = $decode_Response->HotelDetails;
            }
        }
        return $HotelDetails;
    }
    
    public function tboholidays_Search_Hotels(Request $req){
        $GuestNationality   = DB::table('tboHoliday_Country_List')->where('Name',$req->Country_Name)->first();
        $city_list          = DB::table('tboHoliday_City_List')->where('Name',$req->City_Name)->get();
        // $encoded_hotel_Code = DB::table('tboHoliday_Hotel_Codes')->select('HotelCodes')->groupBy('HotelCodes')->get();
        // $hotel_Codes        = json_decode($encoded_hotel_Code);
        $hotel_Codes = $this->tboholidays_Hotel_Codes_OLD();
        // return $encoded_hotel_Code;
        // London Hotel Code 1001425
        $count_HC           = count($hotel_Codes);
        // return $count_HC;
        // 307639
        if($count_HC > 0){
            for($x=0; $x<$count_HC; $x++){
                $hotel_Details = $this->tboholidays_Hotel_Details($hotel_Codes[$x]);
                if(isset($hotel_Details[0]->CityId) && $city_list[0]->Code == $hotel_Details[0]->CityId){
                    $data='{
                        "CheckIn": "2024-02-16",
                        "CheckOut": "2024-02-17",
                        "HotelCodes": "'.$hotel_Details[0]->HotelCode.'",
                        "GuestNationality": "'.$GuestNationality->Code.'",
                        "PaxRooms": [
                            {
                                "Adults": 1,
                                "Children": 1,
                                "ChildrenAges": [ 1 ]
                            }
                        ],
                        "ResponseTime": 23.0,
                        "IsDetailedResponse": false,
                        "Filters": {
                            "Refundable": false,
                            "NoOfRooms": 0,
                            "MealType": "All"
                        }
                    }';
                    // return $data;
                    $curl       = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => 'https://api.tbotechnology.in/TBOHolidays_HotelAPI/Search',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'POST',
                        CURLOPT_POSTFIELDS =>$data,
                        CURLOPT_HTTPHEADER => array(
                            'Content-Type: application/json',
                            'Authorization: Basic VGVzdEFQRUlUU29sdXRpb246QXBlQDU3NjM0NjYz'
                        ),
                    ));
                    $response   = curl_exec($curl);
                    // echo $response;die();
                    curl_close($curl);
                    $decode_Response = json_decode($response);
                    if(isset($decode_Response->Status)){
                        if($decode_Response->Status->Description == 'Successful'){
                            return $decode_Response->HotelResult;
                        }else{
                            return 'Something Went Wrong';
                        }
                    }else{
                        return 'Something Went Wrong';
                    }
                }
            }
        }
    }
    // 3rd Party Api
}
