<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hotels;
use App\Models\country;
use App\Models\city;
use DB;
class CountryController extends Controller
{
    //
    public function allcountriesfetch()
    {
        $country = country::all();
        return response()->json(['countries'=>$country]);
    }
    public function allcountriesfetch_new()
    {
        $country = country::all();
       
        return response()->json(['countries'=>$country]);
    }
    
    function allCountries(){
        DB::beginTransaction();
        try {
            $country = country::select('id','name','phonecode')->get();
            return response()->json(['message'=>'success','country'=>$country]);
        } catch (Throwable $e) {
            DB::rollback();
            return response()->json(['message'=>'error','country'=> '']);
        }
    }
    
    
    function countryCites(Request $request){
        $country = country::find($request->id);
        $cites = $country->cites;
        $options = '';
        foreach($cites as $city_res){
            $options .="<option value='".$city_res['id']."'>".$city_res['name']."</option>";
        }
        return response()->json($options);
    }
    function countryCites_api(Request $request){
        $id=$request->id;
        // print_r($id);die();
        $country = city::where('country_id',$id)->get();
        return response()->json(['country'=>$country]);
       
    }
    
    function country_cites_laln(Request $request){
        $id         = $request->id;
        $city_D     = city::where('id',$id)->first();
        return response()->json(['city_D'=>$city_D]);
    }
    
    function country_cites_ID(Request $request){
        $id         = $request->id;
        $city_D     = DB::table('cities')->where('name',$id)->where('country_code',$request->country_id)->first();
        return response()->json(['city_D'=>$city_D]);
    }

    function getCountryName($id){
        $country = country::find($id);
        return $country->country_name;
    }
    
     function country_code(Request $request){
         
        $country = DB::table('countries')->where('name','=',$request->country)->first();
        print_r($country->phonecode);
        // return $country;
    }
}
