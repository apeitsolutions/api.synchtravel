<?php

namespace App\Http\Controllers\frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use App\Models\User;

use DB;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\booking_customer;


class LoginController_Api extends Controller
{


	public function login(){



		return view('template/frontend/userdashboard/pages/login/login');

	}
	
	function customer_login(Request $request){
       //print_r($request->all());
       
            $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
             
            if($userData){
              if($userData->status == 1){
                 // print_r($userData->id);
                  //print_r($request->email);
                  //die();
            //   echo "Customer id is $request->email ";
                    $customer_data = DB::table('booking_customers')->where('email',$request->email)->where('customer_id',$userData->id)->first();
                   
                     if($customer_data){
                         
                        $OTP = rand(100000, 999999);
                        $OTP_Hased = Hash::make($OTP);
                        
                        $result = DB::table('booking_customers')->where('id',$customer_data->id)->update([
                                'password'=>$OTP_Hased
                            ]);
                        
                        if($result){
                            return response()->json(['message'=>'success','otp'=>$OTP,'customer_data'=>$customer_data]);
                        }else{
                        return response()->json(['message'=>'failed','otp'=>'','customer_data'=>'']);
                            
                        }
                        
                    }else{
                        return response()->json(['message'=>'Email Not Found','otp'=>'','customer_data'=>'']);
                    }
                    // print_r($inv_details);
              }else{
                        return response()->json(['message'=>'failed','otp'=>'','customer_data'=>'']);
                    }
            }else{
                        return response()->json(['message'=>'failed','otp'=>'','customer_data'=>'']);
                    }
    }
    
    function customer_otp_verify(Request $request){
      //print_r($request->all());
       
            $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
             
            if($userData){
              if($userData->status == 1){
                 // print_r($userData->id);
                  //print_r($request->email);
                  //die();
            //   echo "Customer id is $request->email ";
                    $customer_data = DB::table('booking_customers')->where('id',$request->booking_customer_id)->first();
                   
                     if($customer_data){
                        if(Hash::check($request->password, $customer_data->password)){
                            $customer_data = booking_customer::find($request->booking_customer_id);
                            $token = $customer_data->createToken('MyApp')->plainTextToken;
                             
                            return response()->json(['message'=>'success','data'=>$customer_data,'token'=>$token]);
                        }else{
                        return response()->json(['message'=>'failed3','data'=>'']);
                            
                        }
                        
                    }else{
                        return response()->json(['message'=>'failed2','data'=>'']);
                    }
                    // print_r($inv_details);
              }else{
                        return response()->json(['message'=>'failed1','data'=>'']);
                    }
            }else{
                        return response()->json(['message'=>'token not matched','data'=>'']);
                    }
      }
      
    //   function customer_otp_verify(Request $request){
    //   //print_r($request->all());
       
    //         $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
             
    //         if($userData){
    //           if($userData->status == 1){
    //              // print_r($userData->id);
    //               //print_r($request->email);
    //               //die();
    //         //   echo "Customer id is $request->email ";
    //                 // $customer_data = DB::table('booking_customers')->where('id',$request->booking_customer_id)->first();
                   
    //                 //  if($customer_data){
    //                     if(Hash::check($request->password, $customer_data->password)){
    //                         $customer_data = booking_customer::find($request->booking_customer_id);
    //                         $token = $customer_data->createToken('MyApp')->accessToken;
                             
    //                         return response()->json(['message'=>'success','data'=>$customer_data,'token'=>$token]);
    //                     }else{
    //                     return response()->json(['message'=>'failed3','data'=>'']);
                            
    //                     }
                        
    //                 // }else{
    //                 //     return response()->json(['message'=>'failed2','data'=>'']);
    //                 // }
    //                 // print_r($inv_details);
    //           }else{
    //                     return response()->json(['message'=>'failed1','data'=>'']);
    //                 }
    //         }else{
    //                     return response()->json(['message'=>'token not matched','data'=>'']);
    //                 }
    //   }
      
      function customer_hotel_booking(Request $request){
          
        //   $login_agent=auth()->guard('booking_customers')->user()->email;
          
          print_r($login_agent);
          die;
        $userData = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        if($userData){
          if($userData->status == 1){
      
                                $booking_customer_id = (int)$request->booking_customer_id;
                              
                              
                              $inv_hotels = DB::table('hotel_provider_bookings')
                                                ->where('booking_customer_id',$booking_customer_id)
                                                ->where('auth_token',$request->token)->get();
                if($inv_hotels){
                    
                    return response()->json(['message'=>'success','hotels_inv'=>$inv_hotels]);
                }else{
                    return response()->json(['message'=>'failed','hotels_inv'=>'']);
                }
                // print_r($inv_details);
          }
        }
       
    }
    
    

	public function signin(Request $request)
	{
    	//print_r($request->email);
		$this->validate($request,
			[
				'email'=>'required',
				'password'=>'required',

			]);

        $credentials = $request->only('email', 'password');


        $login=Auth::guard('web')->attempt($credentials);

		if($login)
		{

            return redirect()->intended('super_admin');

		}

		else
		{
			return redirect()->back()->with('message','Email or password is not correct!!');
		}

	}

	public function change_password(Request $request)
	{
	    
	     $customer_login=$request->id;
	    $customer_login1=DB::table('customer_subcriptions')->where('id',$customer_login)->first();
	    if (Hash::check($request->input('current_password'), $customer_login1->password) == false)
	   
			{
			
				return response()->json(['message'=>'invalid current password']);
			}
	    
	    if($request->input('new_password') != $request->input('cnew_password'))
		{
			return response()->json(['message'=>'confirm password password does not match!!']);
		}
		else
		{
		    $customer = CustomerSubcription::find($customer_login);
			$customer->password = Hash::make($request->input('new_password'));
 			$customer->update();
	            return response()->json(['message'=>'password updated successfully']);
		}
		
		
		
		




	}
	public function agent_change_password(Request $request){
        $agent_login    = $request->id;
        $agent_login1   = DB::table('b2b_agents')->where('id',$agent_login)->first();
        
        if (Hash::check($request->input('current_password'), $agent_login1->password) == false){
            return response()->json(['status'=>'error','message'=>'invalid current password']);
        }
        else if($request->input('new_password') != $request->input('cnew_password')){
            return response()->json(['status'=>'error','message'=>'confirm password password does not match!!']);
        }
        else{
            DB::table('b2b_agents')->where('id',$agent_login)->update(['password'=>Hash::make($request->input('new_password'))]);
            return response()->json(['status'=>'success','message'=>'password updated successfully']);
        }
	}


	public function logout()
	{
		Auth::guard('web')->logout();
		return redirect('login1');


	}
	public function signup(){
		return view('template/frontend/pages/signup');

	}


}
