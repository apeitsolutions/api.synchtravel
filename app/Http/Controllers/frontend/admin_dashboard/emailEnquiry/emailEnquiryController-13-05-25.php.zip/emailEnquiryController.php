<?php

namespace App\Http\Controllers\frontend\admin_dashboard\emailEnquiry;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\admin\RoomsType;
use App\Models\hotel_manager\Hotels;
use App\Models\hotel_manager\Rooms;
use App\Models\hotel_manager\RoomGallery;
use App\Models\allowed_Hotels_Rooms;
use Session;
use Auth;
use DB;

class emailEnquiryController extends Controller
{
    public function getAllEmailEnquies(Request $request){
        DB::beginTransaction();          
        try {
            $emailEnquiry       = DB::table('emailEnquiry')->where('token',$request->token)->get();
            if($emailEnquiry){
                return response()->json([
                    'status'    => 'success',
                    'data'      => $emailEnquiry,
                ]);
            }
        } catch (Throwable $e) {
            DB::rollback();    
            echo $e;
            return response()->json(['message'=>'error']);
        }
    }
    
    public function addEmailEnquies(Request $request){
        DB::beginTransaction();          
        try {
            $userData           = DB::table('customer_subcriptions')->where('Auth_key',$request->token)->first();
            if($userData == null){
                DB::commit();
                return response()->json(['status'=>'error','message'=>'Invalid Token']);
            }
            
            $package            = DB::table('tours')->where('id',$request->packageid)->first();
            if($package == null){
                DB::commit();
                return response()->json(['status'=>'error','message'=>'Package not exist']);
            }
            
            // $emailEnquiry       = DB::table('emailEnquiry')->where('token',$request->token)->whereRaw('LOWER(email) = ?', [strtolower($request->email)])->first();
            // if($emailEnquiry != null){
            //     DB::commit();
            //     return response()->json(['status'=>'error','message'=>'Email already exist']);
            // }
            
            // if($request->token == config('token_AlhijazTours')){
            //     $from_Address       = config('mail_From_Address_AlhijazTours');
            //     $mail_Template_Key  = config('mail_Template_Key_AlhijazTours');
            //     $website_Title      = config('mail_Title_AlhijazTours');
            //     $website_Url        = config('website_Url_AlhijazTours');
            // }
            // $to_Address             = $request->email;
            // $mail_Check             = Mail3rdPartyController::mail_Check_All($from_Address,$to_Address,$reciever_Name,$email_Message,$mail_Template_Key);
            // return $mail_Check;
            
            $result             = DB::table('emailEnquiry')->insert([
                'token'         => $request->token,
                'customer_id'   => $userData->id,
                'packageid'     => $request->packageid,
                'firstname'     => $request->firstname,
                'lastname'      => $request->lastname,
                'email'         => $request->email,
                'contact'       => $request->contact,
                'adults'        => $request->adults,
                'childs'        => $request->childs,
                'infants'       => $request->infants,
            ]);
            if($result){
                DB::commit();
                return response()->json(['status'=>'success','message'=>'Your enquiry is submitted, our team will contact you soon!']);
            }else{
                DB::commit();
                return response()->json(['status'=>'error','message'=>'Something went wrong']);
            }
        } catch (Throwable $e) {
            DB::rollback();    
            echo $e;
            return response()->json(['message'=>'error','message'=>'Something went wrong']);
        }
    }
}