<?php
namespace App\Http\Controllers\frontend\admin_dashboard\HasanatCoin;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Session;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
Use Illuminate\Support\Facades\Input as input;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\country;
use App\Models\b2b_Agents_detail;

class HasanatCoinController extends Controller
{
    public function create_Hasanat_Coin_Limit(Request $request){
        DB::beginTransaction(); 
        try {
            // $request->token         = '';
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins'=>$hasanat_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function add_Hasanat_Coin_Limit(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            if(!empty($hasanat_Coins) && $hasanat_Coins != null){
                DB::table('hasanat_Coins')->where('token',$request->token)->where('id',$request->id)->update([
                    'coins_Limit'   => $request->coins_Limit,
                ]);
            }else{
                DB::table('hasanat_Coins')->insert([
                    'token'         => $request->token,
                    'customer_id'   => $request->customer_id,
                    'coins_Limit'   => $request->coins_Limit,
                ]);
            }
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Hasanat Coins Limit Added Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function utilize_Hasanat_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            $subscriptions_Packages = DB::table('subscriptions_Packages')->where('token',$request->token)->get();
            $utilize_Hasanat_Coins  = DB::table('utilize_Hasanat_Coins')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins'=>$hasanat_Coins,'subscriptions_Packages'=>$subscriptions_Packages,'utilize_Hasanat_Coins'=>$utilize_Hasanat_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function hasanat_Coins_Statament(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins_Statament = DB::table('hasanat_Coins_Statament')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins_Statament'=>$hasanat_Coins_Statament]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
}
