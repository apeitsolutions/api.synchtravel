<?php
namespace App\Http\Controllers\frontend\admin_dashboard\HasanatCoin;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Session;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
Use Illuminate\Support\Facades\Input as input;
use App\Models\CustomerSubcription\CustomerSubcription;
use App\Models\country;
use App\Models\b2b_Agents_detail;

class HasanatCoinController extends Controller
{
    public function create_Hasanat_Coin_Limit(Request $request){
        DB::beginTransaction(); 
        try {
            // $request->token         = '';
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins'=>$hasanat_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function add_Hasanat_Coin_Limit(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            if(!empty($hasanat_Coins) && $hasanat_Coins != null){
                DB::table('hasanat_Coins')->where('token',$request->token)->where('id',$request->id)->update([
                    'coins_Limit'   => $request->coins_Limit,
                ]);
            }else{
                DB::table('hasanat_Coins')->insert([
                    'token'         => $request->token,
                    'customer_id'   => $request->customer_id,
                    'coins_Limit'   => $request->coins_Limit,
                ]);
            }
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Hasanat Coins Limit Added Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function utilize_Hasanat_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins          = DB::table('hasanat_Coins')->where('token',$request->token)->first();
            $subscriptions_Packages = DB::table('subscriptions_Packages')->where('token',$request->token)->get();
            $utilize_Hasanat_Coins  = DB::table('utilize_Hasanat_Coins')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins'=>$hasanat_Coins,'subscriptions_Packages'=>$subscriptions_Packages,'utilize_Hasanat_Coins'=>$utilize_Hasanat_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function hasanat_Coins_Statament(Request $request){
        DB::beginTransaction(); 
        try {
            $hasanat_Coins_Statament = DB::table('hasanat_Coins_Statament')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','hasanat_Coins_Statament'=>$hasanat_Coins_Statament]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function create_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $subscriptions_Packages = DB::table('subscriptions_Packages')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','subscriptions_Packages'=>$subscriptions_Packages]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function add_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            // $discount_Coins          = DB::table('discount_Coins')->where('token',$request->token)->first();
            // if(!empty($discount_Coins) && $discount_Coins != null){
            //     DB::table('discount_Coins')->where('token',$request->token)->where('id',$request->id)->update([
            //         'coins_Limit'   => $request->coins_Limit,
            //     ]);
            // }else{
                DB::table('discount_Coins')->insert([
                    'token'             => $request->token,
                    'customer_id'       => $request->customer_id,
                    'package_Id'        => $request->package_Id,
                    'total_Coins'       => $request->total_Coins,
                    'coins_Percentage'  => $request->coins_Percentage,
                    'number_Of_Coins'   => $request->number_Of_Coins,
                ]);
            // }
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Discount Coins Added Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function view_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $discount_Coins = DB::table('discount_Coins')->where('discount_Coins.token',$request->token)
                                ->join('subscriptions_Packages','discount_Coins.package_Id','subscriptions_Packages.id')
                                ->select('discount_Coins.*','subscriptions_Packages.*','discount_Coins.id as discount_Id')
                                ->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','discount_Coins'=>$discount_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function check_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            if($request->id != null){
                $discount_Coins = DB::table('discount_Coins')
                                    ->where('id','!=',$request->id)
                                    ->where('token',$request->token)
                                    ->where('customer_id',$request->customer_id)
                                    ->where('package_Id',$request->package_Id)
                                    ->where('total_Coins',$request->total_Coins)
                                    ->where('coins_Percentage',$request->coins_Percentage)
                                    ->where('number_Of_Coins',$request->number_Of_Coins)
                                    ->first();
            }else{
                $discount_Coins = DB::table('discount_Coins')
                                    ->where('token',$request->token)
                                    ->where('customer_id',$request->customer_id)
                                    ->where('package_Id',$request->package_Id)
                                    ->where('total_Coins',$request->total_Coins)
                                    ->where('coins_Percentage',$request->coins_Percentage)
                                    ->where('number_Of_Coins',$request->number_Of_Coins)
                                    ->first();
            }
            if(!empty($discount_Coins) && $discount_Coins != null){
                return response()->json(['status'=>'error','message'=>'Already Added!','discount_Coins'=>$discount_Coins]);
            }else{
                return response()->json(['status'=>'success','message'=>'Not Added!',]);
            }
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function edit_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $discount_Coins         = DB::table('discount_Coins')->where('token',$request->token)->where('id',$request->id)->first();
            $subscriptions_Packages = DB::table('subscriptions_Packages')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','subscriptions_Packages'=>$subscriptions_Packages,'discount_Coins'=>$discount_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function update_Discount_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            
            DB::table('discount_Coins')->where('token',$request->token)->where('id',$request->id)->update([
                'coins_Percentage'  => $request->coins_Percentage,
                'number_Of_Coins'   => $request->number_Of_Coins,
            ]);
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Discount Coins Updated Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function create_Purchase_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $subscriptions_Packages = DB::table('subscriptions_Packages')->where('token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','subscriptions_Packages'=>$subscriptions_Packages]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function get_Booked_Coins_Details(Request $request){
        DB::beginTransaction(); 
        try {
            $booked_Coins = DB::table('3rd_Party_Booking_Hasanat_Coins')
                                ->where('3rd_Party_Booking_Hasanat_Coins.token',$request->token)
                                ->where('3rd_Party_Booking_Hasanat_Coins.package_Id',$request->id)
                                ->join('subscriptions_Packages','3rd_Party_Booking_Hasanat_Coins.package_Id','subscriptions_Packages.id')
                                ->first();
            if(!empty($booked_Coins) && $booked_Coins != null){
                return response()->json(['status'=>'success','message'=>'Booking Available','booked_Coins'=>$booked_Coins]);
            }else{
                return response()->json(['status'=>'error','message'=>'Booking Not Available']);
            }
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function add_Purchase_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $subscriptions_Packages         = DB::table('subscriptions_Packages')->where('token',$request->token)->where('id',$request->package_Id)->first();
            $number_Of_Hasanat_Coins        = $subscriptions_Packages->number_Of_Hasanat_Coins + $request->purchase_Coins;
            
            DB::table('subscriptions_Packages')->where('token',$request->token)->where('id',$request->package_Id)->update([
                'number_Of_Hasanat_Coins'   => $number_Of_Hasanat_Coins,
            ]);
            
            DB::table('purchase_Coins')->insert([
                'token'                     => $request->token,
                'customer_id'               => $request->customer_id,
                'package_Id'                => $request->package_Id,
                'total_Coins'               => $request->total_Coins,
                'booked_Coins'              => $request->booked_Coins,
                'remaining_Coins'           => $request->remaining_Coins,
                'purchase_Price'            => $request->purchase_Price,
                'purchase_Coins'            => $request->purchase_Coins,
            ]);
            
            DB::commit();
            return response()->json(['status'=>'success','message'=>'Purchase Coins Added Successfully!']);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
    
    public function view_Purchase_Coins(Request $request){
        DB::beginTransaction(); 
        try {
            $purchase_Coins = DB::table('purchase_Coins')
                                ->join('subscriptions_Packages','purchase_Coins.package_Id','subscriptions_Packages.id')
                                ->where('purchase_Coins.token',$request->token)->get();
            return response()->json(['status'=>'success','message'=>'Data Fetch Successfully!','purchase_Coins'=>$purchase_Coins]);
        } catch (Throwable $e) {
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong!']);
        }
    }
}
