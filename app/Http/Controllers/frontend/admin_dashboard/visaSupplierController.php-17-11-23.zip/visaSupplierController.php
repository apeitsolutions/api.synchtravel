<?php

namespace App\Http\Controllers\frontend\admin_dashboard;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UmrahPackage;
use App\Models\Tour;
use App\Models\country;
use App\Models\view_booking_payment_recieve;
use App\Models\view_booking_payment_recieve_Activity;
use App\Models\CustomerSubcription\CustomerSubcription;
use Auth;
use App\Models\booking_customers;
use DB;
use Hash;
use Carbon\Carbon;

class visaSupplierController extends Controller
{
    public function search_visa_list(Request $request){
        // dd($request->all());
        $request_all_data = json_decode($request->request_data);
        $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        $pax = (int)$request_all_data->no_of_paxs;
        $check_visa_availilbilty = DB::table('visa_Availability')->join('visa_types','visa_types.id','=','visa_Availability.visa_type')
                                                                 ->join('countries','countries.id','=','visa_Availability.country')
                                                                 ->where('visa_Availability.country',$request_all_data->visa_country)
                                                                 ->where('visa_Availability.visa_type',$request_all_data->visa_type)
                                                                 ->whereDate('visa_Availability.availability_from','<=',$request_all_data->departure_data)
                                                                 ->whereDate('visa_Availability.availability_to','>=',$request_all_data->departure_data)
                                                                 ->where('visa_Availability.visa_available','>',$pax)
                                                                 ->where('visa_Availability.customer_id',$userData->id)
                                                                 ->select('visa_Availability.*','visa_Availability.id as $avail_id','visa_types.other_visa_type','countries.name')
                                                                 ->get();
        return response()->json(['status'=>'success','data'=>$check_visa_availilbilty]);
    }
    
    public function search_visa_list_combine(Request $request){
        $request_all_data = json_decode($request->request_data);
        
        $pax = (int)$request_all_data->pax;
        $country = DB::table('countries')->where('name',$request_all_data->country)->select('id','name')->first();
        $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        
        $check_visa_availilbilty = DB::table('visa_Availability')->join('visa_types','visa_types.id','=','visa_Availability.visa_type')
                                                                 ->join('countries','countries.id','=','visa_Availability.country')
                                                                 ->where('visa_Availability.country',$country->id)
                                                                 ->whereDate('visa_Availability.availability_from','<=',$request_all_data->checkin)
                                                                 ->whereDate('visa_Availability.availability_to','>=',$request_all_data->checkin)
                                                                 ->where('visa_Availability.visa_available','>',$pax)
                                                                 ->where('visa_Availability.customer_id',$userData->id)
                                                                 ->select('visa_Availability.*','visa_Availability.id as $avail_id','visa_types.other_visa_type','countries.name')
                                                                 ->get();
        return response()->json(['status'=>'success','data'=>$check_visa_availilbilty]);
    }
    
    public function visa_booking_invoice(Request $request){
       $booking_data = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->first();
       
       $visa_avail_data = json_decode($booking_data->visa_avail_data);
       $visa_type = DB::table('visa_types')->where('id',$visa_avail_data->visa_type)->select('other_visa_type')->first();
       $visa_country = DB::table('countries')->where('id',$visa_avail_data->country)->select('name')->first();

        $visa_type = $visa_type->other_visa_type;
        $visa_country = $visa_country->name;
        if($booking_data){
            return response()->json([
                'status' => 'success',
                'booking_data' => $booking_data,
                'visa_type' => $visa_type,
                'visa_country' => $visa_country,
                // 'markups_details' => $markups,
            ]);
        }else{
            return response()->json([
                'status' => 'error',
                'message' => "Wrong Invoice Number",
            ]);
        }
    }
    
    public function visa_checkout_submit(Request $request){
        // print_r($request->all());
        $request_all_data = json_decode($request->request_all_data);
        // dd($request_all_data);
        $lead_passenger = json_decode($request->lead_passenger);
        
        $hotel_booked = false;
        if(isset($request->hotel_booked)){
            $hotel_booked = true;
        }
        // dd($lead_passenger);
         DB::beginTransaction();
        
            try {   
                    $userData   = CustomerSubcription::where('id',$request->customer_id)->select('id','status')->first();
                    $booking_customer_id = "";
                    $customer_exist = DB::table('booking_customers')->where('customer_id',$userData->id)->where('email',$lead_passenger->lead_email)->first();
                    if(isset($customer_exist) && $customer_exist != null && $customer_exist != ''){
                            $booking_customer_id = $customer_exist->id;
                    }else{
                       
                       if($lead_passenger->lead_title == "Mr"){
                           $gender = 'male';
                       }else{
                            $gender = 'female';
                       }
                        
                        $password = Hash::make('admin123');
                        
                        $customer_detail                    = new booking_customers();
                        $customer_detail->name              = $lead_passenger->lead_first_name." ".$lead_passenger->lead_last_name;
                        $customer_detail->opening_balance   = 0;
                        $customer_detail->balance           = 0;
                        $customer_detail->email             = $lead_passenger->lead_email;
                        $customer_detail->password             = $password;
                        $customer_detail->phone             = $lead_passenger->lead_phone;
                        $customer_detail->gender            = $gender;
                        $customer_detail->country           = $lead_passenger->lead_country;
        
                        $customer_detail->customer_id       = $userData->id;
                        $result = $customer_detail->save();
                        
                        $booking_customer_id = $customer_detail->id;
        
                        
                    }
                    
                    $randomNumber = random_int(1000000, 9999999);
                    $invoiceId =  "HH".$randomNumber;
                    
                    $visa_avail_data = DB::table('visa_Availability')->where('id',$request_all_data->visa_avail_id)->first();
                    
                    DB::table('visa_bookings')->insert([
                            'invoice_no' => $invoiceId,
                            'no_of_paxs' => $request_all_data->no_of_paxs,
                            'hotel_booked' => $hotel_booked,
                            'lead_passenger_data' => $request->lead_passenger,
                            'other_passenger_data' => $request->other_adults,
                            'visa_avail_id' => $request_all_data->visa_avail_id,
                            'visa_avail_data' => json_encode($visa_avail_data),
                            'visa_price_exchange' => $request_all_data->exchange_price,
                            'visa_total_price_exchange' => $request_all_data->exchange_price_total,
                            'exchange_currency' => $request_all_data->exchange_curreny,
                            'visa_price' => $request_all_data->original_price,
                            'visa_total_price' => $request_all_data->original_price_total,
                            'currency' => $request_all_data->original_curreny,
                            'booking_customer_id' => $booking_customer_id,
                            'lead_passenger' => $lead_passenger->lead_first_name,
                            'customer_id' => $request->customer_id,
                            
                        ]);

                DB::commit();
                return response()->json(['status'=>'success',
                                         'Invoice_no'=>$invoiceId
                                            ]);
                
            } catch (Throwable $e) {
                 DB::rollback();
                echo $e;
                return response()->json(['message'=>'error','booking_id'=> '']);
            }
    }
    
    public function visa_confirmed_checkout_submit(Request $request){
        $result = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->update([
                        'booking_status' => 'Confirmed',
                        'payment_method' => $request->slc_pyment_method,
                    ]);
            
        if($result){
              return response()->json([
                'status' => 'success',
                'Invoice_no' => $request->invoice_no
            ]);
        }else{
             return response()->json([
                'status' => 'error',
                'Invoice_no' => $request->invoice_no
            ]);
        }
    }
    
    public function reject_visa_booking(Request $request){
        $result = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->update([
                        'booking_status' => 'Rejected',
                    ]);
            
        $visa_data = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->first();
        
        $lead_passenger_data = json_decode($visa_data->lead_passenger_data);
            
        if($result){
              return response()->json([
                'status' => 'success',
                'Invoice_no' => $request->invoice_no,
                'lead_email' => $lead_passenger_data->lead_email
            ]);
        }else{
             return response()->json([
                'status' => 'error',
                'Invoice_no' => $request->invoice_no,
                'lead_email' => $lead_passenger_data->lead_email
            ]);
        }
    }
    
    public function visa_booking_list(Request $request){
        $userData   = CustomerSubcription::where('Auth_key',$request->token)->select('id','status')->first();
        
        // $visa_booking_list = DB::table('visa_bookings')->where('customer_id',$userData->id)->orderBy('id','desc')->get();
        $visa_booking_list =   DB::table('visa_bookings')
                                    ->join('countries', function ($join) {
                                        $join->on('countries.id', '=', DB::raw('CAST(JSON_UNQUOTE(JSON_EXTRACT(visa_bookings.visa_avail_data, "$.country")) AS UNSIGNED)'));
                                    })
                                    ->join('visa_types', function ($join) {
                                        $join->on('visa_types.id', '=', DB::raw('CAST(JSON_UNQUOTE(JSON_EXTRACT(visa_bookings.visa_avail_data, "$.visa_type")) AS UNSIGNED)'));
                                    })
                                     ->select('visa_bookings.*', 'countries.name','visa_types.other_visa_type')
                                     ->orderBy('visa_bookings.id','desc')
                                    ->get();
        // dd($visa_booking_list);
        
        return response()->json([
                'status' => 'success',
                'data' => $visa_booking_list
            ]);
    }
    
    public function confrim_visa_booking(Request $request){
        $booking_data = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->first();

        
      
        // dd($reservation_data);
        $currentDateTime = Carbon::now();

        // Add 2 hours to the current time
        $updatedDateTime = $currentDateTime->addHours($request->hours);
        
        // Optionally, you can format the updated time as per your requirement
        $formattedDateTime = $updatedDateTime->format('Y-m-d H:i:s');

        $result = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->update([
            'expire_at' => $formattedDateTime,              
            'booking_status' => 'In Progess',
        ]);
        
         $booking_data = DB::table('visa_bookings')->where('invoice_no',$request->invoice_no)->first();
        
        //  if($result){
            return response()->json([
                'status' => 'success',
                'Invoice_id' => $request->invoice_no,
                'Invoice_data' => $booking_data
            ]);
        // }
        // dd($booking_data);
    }
  
    public function submit_visa_suppliers(Request $request){
        DB::beginTransaction();
        try {
            $customer_id            = $request->customer_id;
            $visa_supplier_name     = $request->visa_supplier_name;
            $email                  = $request->email;
            $phone_no               = $request->phone_no;
            $address                = $request->address;
            $contact_person_name    = $request->contact_person_name;
            $country                = $request->country;
            $city                   = $request->city ?? "";
            
            $three_digit_code   = rand(0,444);
            $visa_Ref_No        = 'VSP'.$three_digit_code;
            
            $data = DB::table('visa_Sup')->insert([  
                'opening_balance'       => $request->opening_balance,
                'balance'               => $request->opening_balance,
                'opening_payable'       => $request->opening_payable,
                'payable'               => $request->opening_payable,
                'customer_id'           => $customer_id,
                'visa_Ref_No'           => $visa_Ref_No,
                'visa_supplier_name'    => $visa_supplier_name,
                'email'                 => $email,
                'phone_no'              => $phone_no,
                'address'               => $address,
                'contact_person_name'   => $contact_person_name,
                'country'               => $country,
                'city'                  => $city ?? "",
            ]);
            
            DB::commit();
            return response()->json(['Status'=>'SuccessFull','data'=>$data]);
            
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;
            return response()->json(['status'=>'error','message'=>'Something Went Wrong Try Again']); 
        }
    }
    
    public function get_visa_suppliers(Request $request){
        $customer_id            = $request->customer_id;
       
       
        
        $data=DB::table('visa_Sup')->get();
       return response()->json(['Status'=>'SuccessFull','data'=>$data]);
    }
    
    public function get_supplier_visas(Request $request){
        // dd($request->all());
       
        $supplier_visas = DB::table('visa_Availability')
                            ->join('countries','countries.id','visa_Availability.country')
                            ->join('visa_types','visa_types.id','visa_Availability.visa_type')
                            ->where('visa_Availability.visa_supplier',$request->visa_supplier)
                            ->select('visa_Availability.*','countries.name','visa_types.other_visa_type')
                            ->get();
                            
            return response()->json(['Status'=>'SuccessFull','data'=>$supplier_visas]);
        
        // print_r($supplier_visas);
        
    }
    
    public function get_visa_suppliers_for_edit(Request $request){
        $visa_sup_id            = $request->visa_sup_id;
       
       
        
        $data=DB::table('visa_Sup')->where('id',$visa_sup_id)->first();
       return response()->json(['Status'=>'SuccessFull','data'=>$data]);
    }
    
    public function submit_visa_suppliers_for_update(Request $request){
        $visa_supllier_id            = $request->visa_sup_id;
       
       
       
        
        $data= DB::table('visa_Sup')->where('id',$visa_supllier_id)->update([  
            'customer_id'           => $request->customer_id,
            'visa_supplier_name'    => $request->visa_supplier_name,
            'email'                 => $request->email,
            'phone_no'              => $request->phone_no,
            'address'               => $request->address,
            'contact_person_name'   => $request->contact_person_name,
            'country'               => $request->country,
            'city'                  => $request->city ?? "",
           
        ]);
       return response()->json(['Status'=>'SuccessFull','data'=>$data]);
    }
    
    public function get_visa_type_for_sup(Request $request){
       
    //   dd($request);
       
       $customer_id =  $request->customer_id;
        
        $data= DB::table('visa_types')->where('customer_id',$customer_id)->get();
        $visa_supplier = DB::table('visa_Sup')->where('customer_id',$customer_id)->get();
       $mange_currencies=DB::table('mange_currencies')->where('customer_id',$customer_id)->get();
       return response()->json(['Status'=>'SuccessFull','data'=>$data,'sup'=>$visa_supplier,'mange_currencies'=>$mange_currencies]);
    }
    
    public function view_visa_type(Request $request){
        $data = DB::table('visa_Availability')
                ->where('visa_Availability.customer_id',$request->customer_id)
                ->join('visa_Sup','visa_Sup.id','visa_Availability.visa_supplier')
                ->join('visa_types','visa_types.id','visa_Availability.visa_type')
                ->join('mange_currencies','mange_currencies.id','visa_Availability.currency_conversion')
                ->select('visa_Availability.id as visa_id','visa_Availability.*','visa_Sup.*','visa_types.*','mange_currencies.purchase_currency','mange_currencies.sale_currency')
                ->get();
        return response()->json(['Status'=>'SuccessFull','data'=>$data,]);
    }
    
    public function submit_visa_avalability_for_sup(Request $request){
        
        // dd($request->currency_conversion);
        
        $currency_conv_data = json_decode($request->currency_conversion);
        
        // dd($currency_conv_data);
      
        $currency_id = 0;
        
        if(isset($currency_conv_data)){
            $currency_id = $currency_conv_data->id;
        }
      
        DB::beginTransaction();
      
        try{
            $visa_id = DB::table('visa_Availability')->insertGetId([  
                'customer_id'                   => $request->customer_id,
                'country'                       => $request->country,
                'visa_supplier'                 => $request->visa_supplier,
                'visa_type'                     => $request->visa_type,
                'currency_conversion'           => $currency_id,
                'conversion_type'               => $request->conversion_type,
                'visa_price_conversion_rate'    => $request->visa_price_conversion_rate,
                'visa_converted_price'          => $request->visa_converted_price,
                'visa_qty'                      => $request->visa_qty,
                'visa_available'                => $request->visa_qty,
                'visa_price'                    => $request->visa_price,
                'availability_from'             => $request->availability_from,
                'availability_to'               => $request->availability_to,
                'total_visa_payable'            => $request->total_visa_payable,
            ]);
            
            $supplier_data      = DB::table('visa_Sup')->where('id',$request->visa_supplier)->first();
            $supplier_balance   = $supplier_data->balance + $request->total_visa_payable;
            DB::table('visa_supplier_ledger')->insert([
                'customer_id'   => $request->customer_id,
                'supplier_id'   => $request->visa_supplier,
                'payment'       => $request->total_visa_payable,
                'balance'       => $supplier_balance,
                'payable'       => $supplier_data->payable,
                'visa_qty'      => $request->visa_qty,
                'visa_type'     => $request->visa_type,
                'visa_price'    => $request->visa_price,
                'visa_avl_id'   => $visa_id,
                'date'          => date('Y-m-d'),
                'remarks'       => 'New Visa Purchased',
            ]);
            $data = DB::table('visa_Sup')->where('id',$request->visa_supplier)->update([  
               'balance' => $supplier_balance,
            ]);
            
            DB::commit();
            return response()->json(['status'=>'success']);
        }catch(Throwable $e){
            DB::rollback();
            return response()->json(['status'=>'error']);
        }
    }
  
    public function get_visa_prices(Request $request){
        $visa_Availability = DB::table('visa_Availability')->where('customer_id',$request->customer_id)->where('visa_supplier',$request->visa_supplier)->sum('visa_converted_price');
        return response()->json(['Status'=>'SuccessFull','visa_Availability'=>$visa_Availability]);
    }
}
