<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;

class Mail3rdPartyController extends Controller
{
    public static function mail_Check($from_Address,$to_Address,$reciever_Name,$email_Message,$details){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.zeptomail.com/v1.1/email/template",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
            "mail_template_key": "2d6f.41936cba9708a01.k1.8532aaf0-5ed5-11ef-ab39-525400cbcb5e.1916f16fb1f",
            "from": { "address": "'.$from_Address.'", "name": "noreply"},
            "to": [{"email_address": {"address": "'.$to_Address.'","name": "Tariq Hussain"}}],
            "merge_info": {"address_name":"'.$email_Message.'"}}',
            CURLOPT_HTTPHEADER => array(
                "accept: application/json",
                "authorization: Zoho-enczapikey wSsVR61w/R6jD6svyT38dLhpmA4GVFinHRl+0Fvzv3OvTfrLp8cznxfIAgGjSKQaEzFvQWMX9egukBpT12Zdht4tzVlUCCiF9mqRe1U4J3x17qnvhDzIXm1fkRKNLIsKxApuk2ZpFMoq+g==",
                "cache-control: no-cache",
                "content-type: application/json",
            ),
        ));
        
        $response   = curl_exec($curl);
        // return $response;
        $err        = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 'Error';
        } else {
            return 'Success';
        }
    }
    
    public static function mail_Check_AR($from_Address,$to_Address,$reciever_Name,$email_Message,$details){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.zeptomail.com/v1.1/email/template",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
            "mail_template_key": "2d6f.41936cba9708a01.k1.e4a42040-6164-11ef-89c4-525400cbcb5e.1917fde0844",
            "from": { "address": "'.$from_Address.'", "name": "noreply"},
            "to": [{"email_address": {"address": "'.$to_Address.'","name": "Tariq Hussain"}}],
            "merge_info": {"address_name":"'.$email_Message.'"}}',
            CURLOPT_HTTPHEADER => array(
                "accept: application/json",
                "authorization: Zoho-enczapikey wSsVR61w/R6jD6svyT38dLhpmA4GVFinHRl+0Fvzv3OvTfrLp8cznxfIAgGjSKQaEzFvQWMX9egukBpT12Zdht4tzVlUCCiF9mqRe1U4J3x17qnvhDzIXm1fkRKNLIsKxApuk2ZpFMoq+g==",
                "cache-control: no-cache",
                "content-type: application/json",
            ),
        ));
        
        $response   = curl_exec($curl);
        // return $response;die;
        $err        = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 'Error';
        } else {
            return 'Success';
        }
    }
    
    public static function mail_Check_All($from_Address,$to_Address,$reciever_Name,$email_Message,$details,$mail_Template_Key){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.zeptomail.com/v1.1/email/template",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
            "mail_template_key": "'.$mail_Template_Key.'",
            "from": { "address": "'.$from_Address.'", "name": "noreply"},
            "to": [{"email_address": {"address": "'.$to_Address.'","name": "Tariq Hussain"}}],
            "merge_info": {"address_name":"'.$email_Message.'"}}',
            CURLOPT_HTTPHEADER => array(
                "accept: application/json",
                "authorization: Zoho-enczapikey wSsVR61w/R6jD6svyT38dLhpmA4GVFinHRl+0Fvzv3OvTfrLp8cznxfIAgGjSKQaEzFvQWMX9egukBpT12Zdht4tzVlUCCiF9mqRe1U4J3x17qnvhDzIXm1fkRKNLIsKxApuk2ZpFMoq+g==",
                "cache-control: no-cache",
                "content-type: application/json",
            ),
        ));
        
        $response   = curl_exec($curl);
        // return $response;die;
        $err        = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return 'Error';
        } else {
            return 'Success';
        }
    }
}
?>