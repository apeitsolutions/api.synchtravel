<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use DB;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        config(['token_AlhijazRooms' => 'rz6tgS0tlmw7aSb4hquHHn7NGQ44y8vA88pJaeEH-MRtaeH0lvcyDnhWkFAbhq9NwXRuW5CXp9aPjel92eOZumKV8Tf8N6AyUMdiu-I1jWxYx8Q9nypyYsJXkyPZ1iE-ClroFTec5rzV5Yiw0WZUKCKsgDjnvGVtwKV4s5vzdLgev7W8wjGMqIGk9YL8JCwiSlQmSSAqGLR-gfVR1uWHS9CFpDexv3T1Jfj2PNHzR6IGtJgbZIO5pJ3si03xR7K5CjKDndEEMgKoenRdWUl5exJyllX6lroeDGz66e2HEgqAJuYH-mkYez2oJkQuBPbsELcdi9SfCOv0UJLYbKGjfHwZVk7ySmrOVDEnBoNW1TRR02wKoBG5J5gUKh3n-iJ8O3BWvJD6uHIImlQAFvIKiv-1Y5uld6N0dLF0GS5NHt4nXZsDPxk92tBSaAQTY5d2ffDeNbROQ-TFiAA0WJQiIux0DHu3CZBAMw8fQvmwjaoMV5E6FebFE1CKvfmp']);
        config(['website_Url_AlhijazRooms' => 'https://alhijazrooms.com/']);
        
        config(['token_HaramynHotel' => 'IoOCQ3ObCcqj3BmtYVUBKTaCIWWoFnQcCorlRUsL-peMCb6m7dlEhXnSJhXXEo7Dh8bG7WQq18wbzMIvAKNk2RtIVKSBc3uUgZASa-0DZ0L5oiwJ9rSktbNb1dM3efA-b7BLH97ryRSj8vglisLUecscxtA1OFPF7kYWWaqDSKxovS9yKw4jBhUWwMrYT306oG2UZgmDpxP-zx6hENsrnFrHXtOqO6e5SA6ZdJsbJmOXZxDq5ZOcLdZ6PgzeQVdnivhXQHA8g3gzQoNuhYo4E1UYNOdTYGS16EvMpOUTxfmhmLz1-hw9SPnIiIzOX9K83qEOptngC4ftezuMmw2cFusTrxrKMvbH8SUqKAiywnTuiyV4yunaolsqVwbR-4PyM6FO8usVBMFf49vNBSO0nh-cdb8imZPtqb4xGeGHHIu5mG7uMAKZaJVbXGpC2eZfjab3NGV9Z-fmSmrDdAmO44ew0Xf0ZIXu4UoJx8a7EfGQRwWl51g5ZF93J0HH']);
        config(['website_Url_HaramynHotel' => 'https://haramaynhotels.com/']);
        // config(['img_url' => 'https://client1.synchronousdigital.com']);
        // config(['endpoint_project' => 'https://admin.synchronousdigital.com']);
        // config(['token' => 'tXvl2Fdyhoi2LtTO9CdjkZZqqeFdhW2k8emVjh1z-HHFtkuV58UonLoNvFjT22Ib1gPlckhNrfnqbMlHCFrNUa8sgNa9jqeruCST7-Nt4MJqGDgLMW0ET0vo1ckk8Vx-xM391TcC6vW9NldFCkwX54DIropj3olep9LRNUwxqz8kMQWi4LqrE5JEKqoMFICwQMU6Jnq6xzO-lud2CoszZ6W7bjtl8mvOsFfWiRipk72Pu35193Zid09cmjXgaAn8SLXCOF8IxvImTdfcdc4DypJm2eF3nKyCyyl8FsiCzVPymah0-uDSgh2ErLwsu7c1O2nHbpQMlurSQnJ0iPUo0bLYKCOt07o3pMuYax4sPULNMojJ3IH3rxWONIxi-1h5YXyvJb4uzz5wflBwyylp1P-TolaFXpNDTvFtzKgcPlx2hBUiq7kPyzL8nnaEnmfwrn6zy28cB-vaJ59Cl0FZOIfbZnmfwhUHOvpJkje9wLyq95nTnFZpxMuNeT1i']);
        
              $data = DB::table('admin_markups')->get();
      //print_r($data);die();
    
if(isset($data))
{
 foreach($data as $data_markup)
 {
     if($data_markup->added_markup == 'synchtravel')
     {
       
     
       if($data_markup->provider == 'CustomHotel')
  {
       
        config(['CustomHotel' => $data_markup->markup_value]);
  }
  if($data_markup->provider == 'Ratehawk')
  {
      config(['Ratehawk' => $data_markup->markup_value]);  
  }
  if($data_markup->provider == 'TBO')
  {
      config(['TBO' => $data_markup->markup_value]);   
  }
  if($data_markup->provider == 'Travellanda')
  {
      config(['Travellanda' => $data_markup->markup_value]);  
  }
  if($data_markup->provider == 'Hotelbeds')
  {
      //print_r($data_markup->markup_value);die();
  config(['synchtravel_markup_hotelbeds' => $data_markup->markup_value]);
 
  }
   if($data_markup->provider == 'All')
   {
    config(['synchtravel_markup_all' => $data_markup->markup_value]);   
   }
       
       
       
       
       
       
         
     }
     
   ///ended  
     
     if($data_markup->added_markup == 'alhijaz_tours')
     {
       
       
  if($data_markup->provider == 'CustomHotel')
  {
       
        config(['CustomHotel' => $data_markup->markup_value]);
  }
  if($data_markup->provider == 'Ratehawk')
  {
      config(['Ratehawk' => $data_markup->markup_value]);  
  }
  if($data_markup->provider == 'TBO')
  {
      config(['TBO' => $data_markup->markup_value]);   
  }
  if($data_markup->provider == 'Travellanda')
  {
      config(['Travellanda' => $data_markup->markup_value]);  
  }
  if($data_markup->provider == 'Hotelbeds')
  {
  config(['alhijaz_markup_hotelbeds' => $data_markup->markup_value]);
  }
  if($data_markup->provider == 'All')
  {
    config(['alhijaz_markup_all' => $data_markup->markup_value]);   
  } 
       
       
         
     }

 }
}
    }
}
