<?php

	//check employee image exist in server or not
	if (!function_exists('employee_image_exists')) {
		function employee_image_exists($image){
			if($image!=''){
				if(file_exists('public/uploads/employee_imgs/'.$image)){
					return true;	
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
	}

	if(!function_exists('convert_object_to_array')){
        function convert_object_to_array($object){
            foreach($object as $value){
                $converted_array[] =  (array) $value;
            }
            return $converted_array;
        }
	}
    
    function base_currency_by_alhijaz($currency,$base_price){
	    $req_url        = 'https://v6.exchangerate-api.com/v6/c95f4029fa1cee82f47ab40e/latest/'. $currency;
        $response_json  = file_get_contents($req_url);
        if(false !== $response_json) {
            try {
                $response = json_decode($response_json);
                if('success' === $response->result) {
                    $base_price = $base_price;
                    $GBP_price  = round(($base_price * $response->conversion_rates->GBP), 2);
                    $data[] = (object)[
                        'exchange_rate'     => $response->conversion_rates->GBP,
                        'exchange_price'    => $GBP_price,
                    ];
                    return $data;
                }
            }
            catch(Exception $e) {
                // Handle JSON parse error...
            }
        }
	}

?>