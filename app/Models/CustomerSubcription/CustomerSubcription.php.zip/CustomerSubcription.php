<?php

namespace App\Models\CustomerSubcription;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class CustomerSubcription extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        
        'email',
        'password',
        
    ];

}
