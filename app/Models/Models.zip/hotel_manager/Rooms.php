<?php

namespace App\Models\hotel_manager;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rooms extends Model
{
    use HasFactory;
    protected $fillables = [
            'room_view',
            'room_img',
            'price_type',
            'adult_price',
            'child_price',
            'quantity',
            'min_stay',
            'max_child',
            'max_adults',
            'extra_beds',
            'extra_beds_charges',
            'availible_from',
            'availible_to',
            'price_week_type',
            'price_all_days',
            'weekdays',
            'weekdays_price',
            'weekends',
            'weekends_price',
            'room_description',
            'amenitites',
            'status',
            'hotel_id',
            'room_type_id'
    ];
}
