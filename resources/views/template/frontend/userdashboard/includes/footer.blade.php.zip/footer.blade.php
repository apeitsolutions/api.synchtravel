<!-- Footer Start -->
<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © Synchronous Digital
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- Right Sidebar -->
        <div class="end-bar">

            <div class="rightbar-title">
                <a href="javascript:void(0);" class="end-bar-toggle float-end">
                    <i class="dripicons-cross noti-icon"></i>
                </a>
                <h5 class="m-0">Settings</h5>
            </div>

            <div class="rightbar-content h-100" data-simplebar>

                <div class="p-3">
                    <div class="alert alert-warning" role="alert">
                        <strong>Customize </strong> the overall color scheme, sidebar menu, etc.
                    </div>

                    <!-- Settings -->
                    <h5 class="mt-3">Color Scheme</h5>
                    <hr class="mt-1" />

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="color-scheme-mode" value="light" id="light-mode-check" checked>
                        <label class="form-check-label" for="light-mode-check">Light Mode</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="color-scheme-mode" value="dark" id="dark-mode-check">
                        <label class="form-check-label" for="dark-mode-check">Dark Mode</label>
                    </div>
       

                    <!-- Width -->
                    <h5 class="mt-4">Width</h5>
                    <hr class="mt-1" />
                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="width" value="fluid" id="fluid-check" checked>
                        <label class="form-check-label" for="fluid-check">Fluid</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="width" value="boxed" id="boxed-check">
                        <label class="form-check-label" for="boxed-check">Boxed</label>
                    </div>
        

                    <!-- Left Sidebar-->
                    <h5 class="mt-4">Left Sidebar</h5>
                    <hr class="mt-1" />
                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="theme" value="default" id="default-check">
                        <label class="form-check-label" for="default-check">Default</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="theme" value="light" id="light-check" checked>
                        <label class="form-check-label" for="light-check">Light</label>
                    </div>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="theme" value="dark" id="dark-check">
                        <label class="form-check-label" for="dark-check">Dark</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="compact" value="fixed" id="fixed-check" checked>
                        <label class="form-check-label" for="fixed-check">Fixed</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="compact" value="condensed" id="condensed-check">
                        <label class="form-check-label" for="condensed-check">Condensed</label>
                    </div>

                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="compact" value="scrollable" id="scrollable-check">
                        <label class="form-check-label" for="scrollable-check">Scrollable</label>
                    </div>

                    <div class="d-grid mt-4">
                        <button class="btn btn-primary" id="resetBtn">Reset to Default</button>
            
                        <a href="https://themes.getbootstrap.com/product/hyper-responsive-admin-dashboard-template/"
                            class="btn btn-danger mt-3" target="_blank"><i class="mdi mdi-basket me-1"></i> Purchase Now</a>
                    </div>
                </div> <!-- end padding-->

            </div>
        </div>

        <div class="rightbar-overlay"></div>
        <!-- /End-bar -->
     


        <!-- bundle -->
        <script src="{{asset('public/admin_package/assets/js/vendor.min.js')}}"></script>
        <script src="{{asset('public/admin_package/assets/js/app.min.js')}}"></script>

        <!-- third party js -->
        <script src="{{asset('public/admin_package/assets/js/vendor/apexcharts.min.js')}}"></script>
        <script src="{{asset('public/admin_package/assets/js/vendor/jquery-jvectormap-1.2.2.min.js')}}"></script>
        <script src="{{asset('public/admin_package/assets/js/vendor/jquery-jvectormap-world-mill-en.js')}}"></script>
        <!-- third party js ends -->

        <!-- demo app -->
        <script src="{{asset('public/admin_package/assets/js/pages/demo.dashboard.js')}}"></script>
        <!-- end demo js-->
        

        
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/jquery.dataTables.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/dataTables.bootstrap5.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/dataTables.responsive.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/responsive.bootstrap5.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/dataTables.buttons.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/buttons.bootstrap5.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/buttons.html5.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/buttons.flash.min.js')}}"></script>-->
        <!--<script src="{{asset('public/admin_package/assets/js/vendor/buttons.print.min.js')}}"></script>-->

     

        <!-- demo app -->
        <!--<script src="{{asset('public/admin_package/assets/js/pages/demo.datatable-init.js')}}"></script>-->
        <!-- quill js -->
<script src="{{asset('public/admin_package/assets/js/vendor/quill.min.js')}}"></script>
<!-- quill Init js-->
<script src="{{asset('public/admin_package/assets/js/pages/demo.quilljs.js')}}"></script>
<script src="{{asset('public/admin_package/assets/js/pages/demo.form-wizard.js')}}"></script>

<script src="{{asset('public/admin_package/assets/js/vendor/dropzone.min.js')}}"></script>
<!-- init js -->
<script src="{{asset('public/admin_package/assets/js/ui/component.fileupload.js')}}"></script>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>








<script>
   $(document).ready(function () {
    $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example1').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example2').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example3').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example4').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
}); 
</script>






<script>


$(document).ready(function () {
    $("#makkah_check_out").on('change',function(){

       
        var dateInmakkah = $('#makkah_check_in').val();
        var dateOutmakkah = $('#makkah_check_out').val();
        // alert(dateInmakkah);
        // var datearray = dateInmakkah.split("/");
        
        // var newdate1 = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        
        // var datearray1 = dateOutmakkah.split("/");
        
        // var newdate2 = datearray1[1] + '/' + datearray1[0] + '/' + datearray1[2];
            
            const date1 = new Date(dateInmakkah);
        const date2 = new Date(dateOutmakkah);
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        var diff=(diffDays);
      
        // alert('differnece is '+diffDays+' date1 '+dateInmakkah+' '+dateOutmakkah);
        $("#makkah_no_of_nights").val(diff);
  

});

});








 

$("#enter_makkah_sharing_1_price").keyup(function(){

    var price = $("#makkah_no_of_nights").val();
      var pa =$("#enter_makkah_sharing_1_price").val();
      var t_price= price * pa;
      
      $("#makkah_sharing_1_total_price").val(t_price);
  


});

$("#enter_makkah_sharing_2_price").keyup(function(){

var price = $("#makkah_no_of_nights").val();
  var pa =$("#enter_makkah_sharing_2_price").val();
  var t_price= price * pa;
  
  $("#makkah_sharing_2_total_price").val(t_price);



});
$("#enter_makkah_sharing_3_price").keyup(function(){

var price = $("#makkah_no_of_nights").val();
  var pa =$("#enter_makkah_sharing_3_price").val();
  var t_price= price * pa;
  
  $("#makkah_sharing_3_total_price").val(t_price);



});
$("#enter_makkah_sharing_4_price").keyup(function(){

var price = $("#makkah_no_of_nights").val();
  var pa =$("#enter_makkah_sharing_4_price").val();
  var t_price= price * pa;
  
  $("#makkah_sharing_4_total_price").val(t_price);



});

    $("#Sharing_1").on('click',function(){

      $("#Sharing_1_slide_down").slideToggle();
      


      


     
  $("#Sharing_1_slide_down").val(t_price);

});
$("#Sharing_2").on('click',function(){

$("#Sharing_2_slide_down").slideToggle();


});
$("#Sharing_3").on('click',function(){

$("#Sharing_3_slide_down").slideToggle();


});
$("#Sharing_4").on('click',function(){

$("#Sharing_4_slide_down").slideToggle();


});


                
$(document).ready(function () {
    $("#madina_check_out").on('change',function(){

       
        var dateInmakkah = $('#madina_check_in').val();
        var dateOutmakkah = $('#madina_check_out').val();
        // alert(dateInmakkah);
            
            const date1 = new Date(dateInmakkah);
        const date2 = new Date(dateOutmakkah);
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        var diff=(diffDays);
    //   alert(diff);
        
        $("#madina_no_of_nights").val(diff);
  

});

});








 

$("#enter_madina_sharing_1_price").keyup(function(){

    var price = $("#madina_no_of_nights").val();
      var pa =$("#enter_madina_sharing_1_price").val();
      var t_price= price * pa;
      
      $("#madina_sharing_1_total_price").val(t_price);
  


});

$("#enter_madina_sharing_2_price").keyup(function(){

var price = $("#madina_no_of_nights").val();
  var pa =$("#enter_madina_sharing_2_price").val();
  var t_price= price * pa;
  
  $("#madina_sharing_2_total_price").val(t_price);



});
$("#enter_madina_sharing_3_price").keyup(function(){

var price = $("#madina_no_of_nights").val();
  var pa =$("#enter_madina_sharing_3_price").val();
  var t_price= price * pa;
  
  $("#madina_sharing_3_total_price").val(t_price);



});
$("#enter_madina_sharing_4_price").keyup(function(){

var price = $("#madina_no_of_nights").val();
  var pa =$("#enter_madina_sharing_4_price").val();
  var t_price= price * pa;
  
  $("#madina_sharing_4_total_price").val(t_price);



});

    $("#Sharing_1_madina").on('click',function(){

      $("#Sharing_1_slide_down_madina").slideToggle();
        
  $("#Sharing_1_slide_down_madina").val(t_price);

});
$("#Sharing_2_madina").on('click',function(){

    $("#Sharing_2_slide_down_madina").slideToggle();


});
$("#Sharing_3_madina").on('click',function(){

$("#Sharing_3_slide_down_madina").slideToggle();


});
$("#Sharing_4_madina").on('click',function(){

$("#Sharing_4_slide_down_madina").slideToggle();


});
</script>

<script>
    $("#Itinerary").on('click',function(){

$("#Itinerary_select").slideToggle();


});
$("#extra_price").on('click',function(){

$("#extraprice_select").slideToggle();


});
$("#faq").on('click',function(){

$("#faq_select").slideToggle();


});
</script>

<script>
    var divId = 1
    $("#click_more_Itinerary").click(function(){
        var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                        <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Title</label>
                                    <input type="text" id="simpleinput" name="more_Itinerary_title[]" class="form-control">
                                </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Desc: TP. HCM City</label>
                                <input type="text" id="simpleinput" name="more_Itinerary_city[]" class="form-control">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Content</label>
                                <textarea name="more_Itinerary_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">image</label>
                                <input type="file" id="simpleinput" name="more_Itinerary_image[]" class="form-control">
                            </div>
                            <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow(${divId})"  id="${divId}">Delete</button>
                        </div>
                    </div>`
                    ;
  $("#append_data").append(data);
  divId++;
});
</script>

<script>
 function deleteRow(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>

<script>
    var divId = 1
    $("#click_more_extra_price").click(function(){
        var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                        <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Name</label>
                                    <input type="text" id="simpleinput" name="more_extra_price_title[]" class="form-control">
                                </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Price</label>
                                <input type="text" id="simpleinput" name="more_extra_price_price[]" class="form-control">
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Type</label>
                                <select name="more_extra_price_type[]" id="" class="form-control">
                                <option value="">Select Type</option>
                                    <option value="0">One-Time</option>
                                    <option value="1">Per-Hour</option>
                                    <option value="2">Per-Day</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xl-6">
                        <div class="mb-3 mt-4">
<div class="form-check form-check-inline">
  <input type="checkbox" class="form-check-input" id="Price_per_person" name="more_extra_price_person[]">
 <label class="form-check-label" for="Price_per_person">Price per person</label>
 </div>
</div>
                            <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_extra(${divId})"  id="${divId}">Delete</button>
                        </div>
                    </div>`
                    ;
  $("#append_data_extra_price").append(data);
  divId++;
});
</script>

<script>
 function deleteRow_extra(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>

<script>
    var divId = 1
    $("#click_more_faq").click(function(){
        var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                        <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Title</label>
                                    <input type="text" id="simpleinput" name="more_faq_title[]" class="form-control">
                                </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Content</label>
                                <textarea name="more_faq_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                            </div>
                        </div>
             
                        <div class="col-xl-6">
                        
                            <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_faq(${divId})"  id="${divId}">Delete</button>
                        </div>
                    </div>`
                    ;
  $("#append_data_faq").append(data);
  divId++;
});
</script>

<script>
 function deleteRow_faq(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>
<script>
    $(document).ready(function () {
    $("#enddate").on('change',function(){

       
        var start_date = $('#start_date').val();
        var enddate = $('#enddate').val();
        // alert(dateInmakkah);
            
            const date1 = new Date(start_date);
        const date2 = new Date(enddate);
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        var diff=(diffDays);
    //   alert(diff);
        
        $("#duration").val(diff);
  

});

});
</script>

@yield('scripts')
    </body>


</html>