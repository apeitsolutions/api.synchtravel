@extends('template/frontend/userdashboard/layout/default')
 @section('content')

 <div class="row mt-5">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">View Tours</h4>
                                        <p class="text-muted font-14">
                                            
                                        </p>

                                        
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="buttons-table-preview">
                                                <table id="example1" class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Name</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                            <th>Location</th>
                                                            <th>Author</th>
                                                            <th>Status</th>
                                                            <th>Edit</th>
                                                            <th>Delete</th>
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        @foreach($tours as $tours)
                                                        <tr>
                                                            <td>{{$tours->id}}</td>
                                                            <td>{{$tours->title}}</td>
                                                            <td>{{$tours->start_date}}</td>
                                                            <td>{{$tours->end_date}}</td>
                                                            <td>{{$tours->tour_location}}</td>
                                                            <td>{{$tours->tour_author}}</td>
                                                            <td><?php
                                                            if($tours->tour_publish == 0)
                                                            {
 
                                                                ?>
                                                                <form action="{{URL::to('super_admin/disable_tour',[$tours->id])}}" >
                                                                    <input type="hidden" name="">
                                                                    <button class="btn btn-info">Enable</button>
                                                                </form>



                                                                <?php
                                                            }
                                                            else{
                                                                ?>
                                                                <form action="{{URL::to('super_admin/disable_tour',[$tours->id])}}">
                                                                    <input type="hidden" name="">
                                                                    <a class="btn btn-info" href="{{URL::to('super_admin/enable_tour')}}/{{$tours->id}}">Disable</a>
                                                                </form>
                                                             

                                                                <?php
                                                            }
                                                            ?></td>
                                                            <td><a class="btn btn-info" href="{{URL::to('super_admin/edit_tour')}}/{{$tours->id}}">Edit</a></td>
                                                            <td><a class="btn btn-info" href="{{URL::to('super_admin/delete_tour')}}/{{$tours->id}}">Delete</a></td>
                                                        </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>                                           
                                            </div> <!-- end preview-->
                                        
                                            
                                        </div> <!-- end tab-content-->
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div> <!-- end row-->
                        
                        
                        
                        
                           
 @endsection