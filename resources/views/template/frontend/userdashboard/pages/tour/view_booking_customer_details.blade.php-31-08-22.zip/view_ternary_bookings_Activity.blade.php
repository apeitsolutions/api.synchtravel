
@extends('template/frontend/userdashboard/layout/default')
@section('content')

  <style>
    .nav-link{
      color: #575757;
      font-size: 18px;
    }
  </style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <section class="content" style="padding: 30px 50px 0px 50px;">
      

      <!-- Start Content-->
        <div class="container-fluid">
          <!-- start page title -->
          <div class="row">
              <div class="col-12">
                  <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Tour Bookings</a></li>
                            <li class="breadcrumb-item active">Activity Tentative Bookings</li>
                        </ol>
                    </div>
                    <h4 class="page-title">View Activity Tentative Bookings</h4>
                  </div>
              </div>
          </div>
          <!-- end page title --> 

          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row mb-2">
                    <div class="col-sm-5">
                      <!-- <a href="javascript:void(0);" class="btn btn-danger mb-2"><i class="mdi mdi-plus-circle me-2"></i> View Tentative Bookings</a> -->
                    </div>
                    <div class="col-sm-7">
                      <div class="text-sm-end">
                        <!-- <button type="button" class="btn btn-success mb-2 me-1"><i class="mdi mdi-cog-outline"></i></button>
                        <button type="button" class="btn btn-light mb-2 me-1">Import</button>
                        <butt on type="button" class="btn btn-light mb-2">Export</button>-->
                      </div>
                    </div><!-- end col-->
                  </div>

                  <div class="table-responsive">
                    <!-- <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"> -->
                      <div class="row">
                        <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                          <thead class="table-light">
                            <tr>
                              <th>ID</th>
                                <th>Booking ID</th>
                                <th style="text-align: center;">Image</th>
                                <th class="all">Tour ID</th>
                                <th>Customer Name</th>
                                <th>Package Title</th>
                                <th>Adults</th>
                                <th>Childs</th>
                                <th>Total Amount</th>
                                <th>Payment Status</th>
                                <th>Status</th>
                                <th style="width: 85px;">Action</th>
                            </tr>
                          </thead>
                            <tbody>
                              @foreach ($data as $value)
                                  <?php
                                    $date4days = date('Y-m-d',strtotime($value->created_at. ' + 2 days'));
                                    $currdate = date('Y-m-d');
                                  ?>
                                  <tr>
                                    <td class="P_Id">{{ $value->id }}</td>
                                    <td>{{ $value->booking_id }}</td>
                                    <td>
                                      <p class="m-0 d-inline-block align-middle font-16">
                                      <a href="#" class="text-body">{{ $value->image }}</a>
                                        <br/>
                                      <span class="text-warning mdi mdi-star"></span>
                                      <span class="text-warning mdi mdi-star"></span>
                                      <span class="text-warning mdi mdi-star"></span>
                                      <span class="text-warning mdi mdi-star"></span>
                                      <span class="text-warning mdi mdi-star"></span>
                                      </p>
                                    </td>
                                    <td class="sorting_1 tour_Id" id="tour_Id">{{ $value->tour_id }}</td>
                                    <td>{{ $value->passenger_name }}</td>
                                    <td>{{ $value->tour_name }}</td>
                                    <td>{{ $value->adults }}</td>
                                    <td>{{ $value->childs }}</td>
                                    <td>{{ $value->price }}</td>
                                    <td class="payment_status{{ $value->id }}"></td>
                                    @if($value->confirm == 1)
                                      <td><span class="badge bg-success" style="font-size: 15px">Confirmed</span></td>
                                    @else
                                      <td><span class="badge btn-danger" style="font-size: 15px">Tentative</span></td>
                                    @endif
                                    <td>
                                      <div class="dropdown card-widgets">
                                        <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="dripicons-dots-3"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end" style="">
                                            <!-- item-->
                                            <a href="{{ URL::to('super_admin/view_booking_payment_Activity')}}/{{$value->booking_id}}/{{$value->id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Payment</a>
                                            <!-- item-->
                                            <!--href="https://client1.synchronousdigital.com/invoice_package/{{$value->invoice_no}}"-->
                                            <a href="{{URL::to('invoice_package')}}/{{$value->invoice_no}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Booking Details</a>
                                            <!--<a href="{{ URL::to('super_admin/view_booking_detail_Activity')}}/{{$value->booking_id}}/{{$value->id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Booking Details</a>-->
                                            <!-- item-->
                                            <a href="{{ route('view_booking_customer_details_Activity',$value->booking_id) }}" class="dropdown-item"><i class="mdi mdi-account"></i>Customer Deatils</a>
                                            <!-- item-->
                                            <div class="confirmed_div_dropdown{{ $value->id }}">
                                              <!--<a href="{{ route('confirmed_tour_booking_Activity',$value->id) }}" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Confirm Booking</a>-->
                                            </div>
                                            
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                              @endforeach
                            </tbody>
                        </table>
                      </div>
                    <!-- </div> -->
                  </div>
                </div>
              </div>
            </div>
          </div>           
        </div> 
      <!-- container -->
    </section>

    <!-- /.Dashboard -->
  </div>


  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
 
   
    $(document).ready(function () {
      
        //DataTable
        $('#myTable').DataTable({
          pagingType: 'full_numbers',
        });



          $('#example1 .P_Id').each(function() {
            var P_Id = $(this).html();
            // var pID = 0;
            var div_ID = 1;
            var div_ID_conf = 1;
            $.ajax({
                url: 'view_ternary_bookings_tourId_Activity/'+P_Id,
                type: 'GET',
                data: {
                    "P_Id": P_Id
                },
                success:function(data) {
                    var a = data['a'];
                    var recieved = parseInt(data['recieved']);
                    var price = parseInt(data['price']);
                    
                    if(price == recieved){
                        $.each(a, function(key, value) {
                            $(".confirmed_div_dropdown"+P_Id+'').empty();
                            var url = 'confirmed_tour_booking_Activity/'+value.package_id;
                            var data = `<a href="${url}" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Confirm Booking</a>`
                            $(".confirmed_div_dropdown"+P_Id+'').html(data);
                        });
                        $(".payment_status"+P_Id+'').empty();
                        $(".payment_status"+P_Id+'').html('<td style="color: Green;">Paid</td>');
                    }
                    else if(recieved > 0 && recieved < price){
                        $(".payment_status"+P_Id+'').empty();
                        $(".payment_status"+P_Id+'').html('<td style="color: rebeccapurple;">Partially Paid</td>');
                    }
                    else{
                        $(".payment_status"+P_Id+'').empty();
                        $(".payment_status"+P_Id+'').html('<td style="color: orange;">Un Paid</td>');
                        $(".confirmed_div_dropdown"+P_Id+'').empty();
                    }
                }
            });
            div_ID = div_ID + 1;
            div_ID_conf = div_ID_conf + 1;
          });
    
        });
  </script>

@endsection
