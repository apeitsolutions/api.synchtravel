<?php

//print_r($data);die();
?>

@extends('template/frontend/userdashboard/layout/default')
@section('content')



                <div class="container-fluid">
                    
                    <div class="table-responsive">
                        <div class="row">
                            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                
                
                
                
                
                
                
                
                
                
                
                            <table class="table table-centered w-100 dt-responsive nowrap mt-5" id="example1">
                                <thead class="table-light">
                                    <tr>
                                        <th style="text-align: center;">Sr No.</th>
                                        <th style="text-align: center;">Company Name</th>
                                        <th style="text-align: center;">Company Email</th>
                                        <!--<th style="text-align: center;">Company Address</th>-->
                                        <th style="text-align: center;">Contact Person Name</th>
                                        <th style="text-align: center;">Contact No.</th>
                                        <th style="width: 85px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @foreach($data as $data_res)
                                    <tr>
                                    <td>{{$data_res->id ?? ""}}</td>
                                    <td>{{$data_res->room_supplier_name ?? ""}}</td>
                                    <td>{{$data_res->email ?? ""}}</td>
                                    <!--<td>{!! $data_res->address ?? "" !!}</td>-->
                                    <td>{{$data_res->contact_person_name ?? ""}}</td>
                                    <td>{{$data_res->phone_no ?? ""}}</td>
                                    
                                    <td><a href="{{URL::to('edit_hotel_suppliers')}}/{{$data_res->id}}"><span class="badge bg-success" style="font-size: 15px">Edit</span></a> 
                                    <a href="{{URL::to('delete_hotel_suppliers')}}/{{$data_res->id}}"><span class="badge bg-success" style="font-size: 15px">Delete</span></a></td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div> 
                    
                </div>

@endsection

@section('scripts')

   

    <script>
        $(document).ready(function(){
           
        });
    </script>

@stop

@section('slug')

@stop
