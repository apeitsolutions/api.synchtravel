
<div class="copyrights">
<p>2019 <i class="fa fa-copyright" aria-hidden="true"></i> Hotux by <a href="https://www.cyclonethemes.com/" target="_blank">Cyclone Themes</a></p>
</div>