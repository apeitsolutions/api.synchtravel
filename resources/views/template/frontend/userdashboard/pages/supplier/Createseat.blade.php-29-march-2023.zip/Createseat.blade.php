@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

    <div id="add_airline_modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
    <div class="modal-header">
                    <h4 class="modal-title" >Add Flight Airline Name</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body htmldetailofflight">
                         
                    <div class="col-xl-12" style="padding-left: 24px;">
                                        
                              
                                         <div>
                                        <label>Airline Name</label>
                                        <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                                   {{$currency ?? ""}}
                                                </a>
                                            </span>
                                            <input type="text"  name="new_flights_airline_name" class="form-control new_flight_data">
                                        </div>
                                        </div>
                                       
                                         <button type="button" class="btn btn-primary mt-3 add_flight_in_db">Submit</button>
                                       
                                    </div>
                                   
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal --> 

    <div class="dashboard-content">
   
        <h2>ADD SEATS</h2>
        <form action="{{ url('addseat1') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="row">
                    
                <div class="col-md-12" id="select_flights_inc">
                    
                    <div class="row" style="padding: 25px;">
                        
                        <h4>DEPARTURE DETAILS</h4>
                        
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <label for="">Select Supplier</label>
                                <select class="form-control" name="supplier" required id="departure_supplier_id">
                                    <option value="">Select supplier</option>
                                    @if(isset($supplier)) 
                                        @foreach($supplier as $all_supplier)
                                            <option value="{{$all_supplier->multi_rute_suplier->id}}" attr-name="{{$all_supplier->multi_rute_suplier->companyname}}">{{$all_supplier->multi_rute_suplier->companyname}}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                        
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <label for="">Flight Type</label>
                            <select name="flight_type" required id="flights_type" class="form-control">
                                <option attr="select" selected>Select Flight Type</option>
                                <option attr="Direct" value="Direct">Direct</option>
                                <option attr="Indirect" value="Indirect">Indirect</option>
                            </select>
                        </div>
                        
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <div>
                                <label for="">Airline</label>
                                <div class="input-group">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1 add_airline">
                                           +
                                        </a>
                                    </span>
                                    <select name="selected_flight_airline" required id="airline_data" class="form-control airline_data" onchange="changeairlineFunction()" >
                                    <option attr="select" selected>Select Airline</option>
                                        @if(isset($airline))
                                            @foreach($airline as $all_airline)
                                                <option value="{{$all_airline->other_Airline_Name}}">{{$all_airline->other_Airline_Name}}</option>
                                            @endforeach
                                        @endif
                                </select>
                                </div>
                            </div>
                        </div>
                      
                        <div class="col-sm-12 col-md-3" style="padding: 10px;" id="flights_type_connected"></div>
                        
                    </div>
                    
                    <div class="container Flight_section" style="display:none">
                        
                        <div class="row" style="padding: 12px">
                            
                            <div class="col-xl-4">
                                <label for="">Departure Airport</label>
                                <input name="departure_airport_code[]" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                            </div>
                            
                            <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                <label for=""></label>
                                <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                            </div>
                            
                            <div class="col-xl-4">
                                <label for="">Arrival Airport</label>
                                <input name="arrival_airport_code[]" id="arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                
                            </div>
                            
                            <div class="col-xl-3">
                                <label for="">Airline Name</label>
                                <input type="text" id="other_Airline_Name2" name="other_Airline_Name2[]" class="form-control other_airline_Name1 other_Airline_Name2">
                              
                            </div>
                            
                            <div class="col-xl-3" style="margin-top: 15px;">
                                <label for="">Class Type</label>
                                <select  name="departure_Flight_Type[]" id="departure_Flight_Type" class="form-control">
                                    <option value="">Select Flight Type</option>
                                    <option value="Bussiness">Bussiness</option>
                                    <option value="Economy">Economy</option>
                                    <option value="Standard">Standard</option>
                                </select>
                            </div>
                            
                            <div class="col-xl-3" style="margin-top: 15px;">
                                <label for="">Flight Number</label>
                                <input type="text" id="departure_flight_number" name="departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                            </div>
                            
                            <div class="col-xl-3" style="margin-top: 15px;">
                                <label for="">Departure Date and Time</label>
                                <input type="datetime-local" id="departure_time" name="departure_time[]" class="form-control departure_time1" value="" >
                            </div>
                            
                            <div class="col-xl-3" style="margin-top: 15px;">
                                <label for="">Arrival Date and Time</label>
                                <input type="datetime-local" id="arrival_time" name="arrival_time[]" class="form-control arrival_time1" value="" >
                            </div>
                            
                        </div>
                        
                        <div class="row" style="margin-left: 320px" id="total_Time_Div">
                            <div class="col-sm-3">
                                <h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>
                            </div>
                            <div class="col-sm-3">
                                 <label for="">Flight Duration</label>
                                <input type="text" id="total_Time" name="total_Time[]" class="form-control total_Time1" readonly style="width: 170px;" value="">
                            </div>
                        </div>
                        
                    </div>
                    
                    <div class="container Flight_section_append"></div>
                
                    <hr>
                    
                    <div class="row"  id="select_flights_inc" style="padding: 25px;">
                        
                        <h4>RETURN DETAILS</h4>
                            
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <label for="">Select Supplier</label>
                                <select class="form-control" name="return_supplier" required id="return_supplier_id"></select>
                            </div>
                            
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <label for="">Flight Type</label>
                            <select name="return_flight_type" required id="flights_type2" class="form-control">
                                <option attr="select" selected>Select Flight Type</option>
                                <option attr="Direct" value="Direct">Direct</option>
                                <option attr="Indirect" value="Indirect">Indirect</option>
                            </select>
                        </div>
                        
                        <div class="col-sm-12 col-md-3" style="padding: 10px;">
                            <label for="">Return Airline</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1 add_airline">
                                       +
                                    </a>
                                </span>
                                <select name="return_selected_flight_airline" id="return_airline_data" required class="form-control airline_data" onchange="return_changeairlineFunction()" >
                                    <option attr="select" selected>Select Airline</option>
                                    @if(isset($airline))
                                        @foreach($airline as $all_airline)
                                            <option value="{{$all_airline->other_Airline_Name}}">{{$all_airline->other_Airline_Name}}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                      
                        <div class="col-sm-12 col-md-3" style="padding: 10px;" id="flights_type_connected2"></div>
                        
                        <div class="container Flight_section_append2"></div>
                        
                        <div class="container return_Flight_section2" style="display:none">
                            
                            <div class="row" style="padding: 12px">
                                <div class="col-xl-4">
                                    <label for="">Departure Airport</label>
                                    <input name="return_departure_airport_code[]" id="return_departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                </div>
                                <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                    <label for=""></label>
                                    <span id="return_Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                </div>
                                <div class="col-xl-4">
                                    <label for="">Arrival Airport</label>
                                    <input name="return_arrival_airport_code[]" id="return_arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                    
                                </div>
                                <div class="col-xl-3">
                                    <label for="">Airline Name</label>
                                    <input type="text" id="return_other_Airline_Name2" name="return_other_Airline_Name2[]" class="form-control other_airline_Name1 return_other_Airline_Name2">
                                </div>
                                <div class="col-xl-3" style="margin-top: 15px;">
                                    <label for="">Class Type</label>
                                    <select  name="return_departure_Flight_Type[]" id="return_departure_Flight_Type" class="form-control">
                                        <option value="">Select Flight Type</option>
                                        <option value="Bussiness">Bussiness</option>
                                        <option value="Economy">Economy</option>
                                        <option value="Standard">Standard</option>
                                    </select>
                                </div>
                                <div class="col-xl-3" style="margin-top: 15px;">
                                    <label for="">Flight Number</label>
                                    <input type="text" id="return_departure_flight_number" name="return_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                </div>
                                <div class="col-xl-3" style="margin-top: 15px;">
                                    <label for="">Departure Date and Time</label>
                                    <input type="datetime-local" id="return_departure_time" name="return_departure_time[]" class="form-control return_departure_time1" value="" >
                                </div>
                                <div class="col-xl-3" style="margin-top: 15px;">
                                    <label for="">Arrival Date and Time</label>
                                    <input type="datetime-local" id="return_arrival_time" name="return_arrival_time[]" class="form-control return_arrival_time1" value="" >
                                </div>
                            </div>
                            
                            <div class="row" style="margin-left: 320px" id="return_total_Time_Div2">
                                <div class="col-sm-3">
                                    <h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No2">Return Direct :</h3>
                                </div>
                                <div class="col-sm-3">
                                     <label for="">Flight Duration</label>
                                    <input type="text" id="return_total_Time2" name="return_total_Time[]" class="form-control return_total_Time1" readonly style="width: 170px;" value="">
                                </div>
                            </div>
                            
                        </div>
                        
                        <div class="container return_Flight_section_append2"></div>
                        
                    </div>
                    
                    <hr>
                    
                    <div class="row" style="padding: 25px;">
                        
                        <h4>SEATS DETAILS</h4>
                        
                        <div class="col-sm-6 col-md-4" style="padding: 10px;">
                        <label>Number of Seats</label>
                        <div class="input-group">
                            <span class="input-group-btn input-group-append">
                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                   {{$currency ?? ""}}
                                </a>
                            </span>
                            <input type="text" onchange="total_price_cal_fun()" id="flights_number_of_seat" name="flights_number_of_seat" class="form-control">
                        </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4" style="padding: 10px;">
                        <label for="">Price Per Adult</label>
                        <div class="input-group">
                            <span class="input-group-btn input-group-append">
                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                  {{$currency ?? ""}} 
                                </a>
                            </span>
                            <input type="text" onchange="total_price_cal_fun()" id="flights_per_adult_price" name="flights_per_person_price" class="form-control">
                        </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4" style="padding: 10px;">
                        <label for="">Child Price</label>
                        <div class="input-group">
                            <span class="input-group-btn input-group-append">
                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                   {{$currency ?? ""}}
                                </a>
                            </span>
                            <input type="text" id="flights_per_child_price" name="flights_per_child_price" class="form-control">
                        </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4" style="padding: 10px;">
                        <label for="">Infant Price</label>
                        <div class="input-group">
                            <span class="input-group-btn input-group-append">
                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                   {{$currency ?? ""}}
                                </a>
                            </span>
                            <input type="text" id="flights_per_infant_price" name="flights_per_infant_price" class="form-control">
                        </div>
                        </div> 
                        
                        <div class="col-sm-6 col-md-4" style="padding: 10px;">
                        <label for="">Total Price</label>
                        <div class="input-group">
                            <span class="input-group-btn input-group-append">
                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                   {{$currency ?? ""}}
                                </a>
                            </span>
                            <input type="text" readonly id="flights_per_person_total_price"  name="flights_total_price" class="form-control">
                        </div>
                        </div>
                        
                    </div>
                        
                    <div class="col-xl-12 d-none" style="padding: 25px;" id="text_editer">
                        <label for="">Indirect Flight Duration and Details</label>
                        <textarea name="connected_flights_duration_details" class="form-control" cols="10" rows="10"></textarea>
                    </div>
                    
                    <div class="col-xl-12 d-none" style="padding: 25px;">
                        <label for="">Additional Flight Details</label>
                        <textarea name="terms_and_conditions" class="form-control" cols="5" rows="5"></textarea>
                    </div>
                    
                    <div class="col-xl-12 d-none" style="padding: 25px;">
                        <label for="">image</label>
                        <input type="file" id="" name="flights_image" class="form-control">
                    </div>
                
                </div>
                    
            </div>
            
            <div class="row">
                <div class="col-md-12 text-right mt-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
    
</div>

@endsection
@section('scripts')
@include('template/frontend/userdashboard/includes/newfooter1')

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js" integrity="sha512-6F1RVfnxCprKJmfulcxxym1Dar5FsT/V2jiEUvABiaEiFWoQ8yHvqRM/Slf0qJKiwin6IDQucjXuolCfCKnaJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>

    function changeairlineFunction(){
        var airline_name =  $('#airline_data').val();
        $('.other_Airline_Name2').val(airline_name);
    }
    
    function return_changeairlineFunction(){
        var airline_name =  $('#return_airline_data').val();
        $('.return_other_Airline_Name2').val(airline_name);
    }

    function total_price_cal_fun(){
        var adult_price = $('#flights_per_adult_price').val();
        var seats       = $('#flights_number_of_seat').val();
        if(adult_price){
            var adult_price = adult_price; 
        }else{
            var adult_price = 0; 
        }
        if(seats){
            var seats = seats; 
        }else{
            var seats = 0; 
        } 
        var price_addition  = parseFloat(adult_price);
        var multiple        = seats * price_addition;
        $('#flights_per_person_total_price').val(multiple);
    }

    $(".add_airline").click(function () {
       $('#add_airline_modal').modal("show");
    });
   
    $(".add_flight_in_db").click(function () {
        var airline = $('.new_flight_data').val();
        $.ajax({    
            type: "POST",
            url: "{{URL::to('')}}/addnewflight",
            data:{
                "_token"                : "{{ csrf_token() }}",
                'title'                 : airline,     
            },
            success: function(data){
                console.log(data);
            }
        });
   });
   
    function addGoogleApi(id){
        var places = new google.maps.places.Autocomplete(
            document.getElementById(id)
        );
        
        google.maps.event.addListener(places, "place_changed", function () {
            var place = places.getPlace();
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                        $('#pickup_CountryCode').val(country_code)
                    }
                }
            });
        });
    }
   
</script>

<script>
    // Flights
    
    
    $("#departure_supplier_id").change(function () {
        $("#return_supplier_id").empty();
        var id      = $(this).find('option:selected').attr('value');
        var name    = $(this).find('option:selected').attr('attr-name');
        var data    = `<option value="${id}" selected>${name}</option>`;
        $("#return_supplier_id").append(data);
    });
    
    $("#flights_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        $('#flights_departure_code').val(id);
        if(id == 'Indirect'){
            $('#departure_airport_code').val('');
        	$('#arrival_airport_code').val('');
        	$('#other_Airline_Name2').val('');
        	$('#departure_flight_number').val('');
        	$('#departure_time').val('');
        	$('#arrival_time').val('');
            
            $("#text_editer").css("padding", "20");
            $('#flights_type_connected').fadeIn();
            $('#flights_type_connected').empty();
            var no_of_stays_Append = `<label for="no_of_stays">No Of Stops</label>
                                        <select  name="no_of_stays" id="no_of_stays" class="form-control select2" data-toggle="select2">
                                            <option value="">Choose...</option>
                                            <option value="2">1</option>
                                            <option value="3">2</option>
                                            <option value="4">3</option>
                                        </select>`;
            $('#flights_type_connected').append(no_of_stays_Append);
            $('#text_editer').fadeOut();
            $('#text_editer').fadeIn();
            $('#stop_No').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Stop No 1 :</h3>'));
            $('#return_stop_No').replaceWith($('<h3 style="width: 182;margin-top: 25px;float:right" id="return_stop_No">Return Stop No 1 :</h3>'));

            $('.Flight_section').fadeOut();
            $('.return_Flight_section').fadeOut();
            $('#total_Time_Div').fadeOut();
            $('#return_total_Time_Div').fadeOut();
        }
        else{
            $('#no_of_stays').empty('');
            addGoogleApi('departure_airport_code');
            addGoogleApi('arrival_airport_code');
            $('.Flight_section').fadeIn();
            $('.return_Flight_section').fadeIn();
            $('#total_Time_Div').fadeIn();
            $('#return_total_Time_Div').fadeIn();
            $('#flights_type_connected').fadeOut();
            $('.Flight_section_append').empty();
            $('.return_Flight_section_append').empty();
        	$('#text_editer').fadeOut();
        	$('#stop_No').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>'));
        	$('#return_stop_No').replaceWith($('<h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No">Return Direct :</h3>'));
        }
    });
   
    $('#flights_type_connected').change(function () {
        var no_of_stays = $('#no_of_stays').val();
        if(no_of_stays == 'NON_STOP'){
            $('.Flight_section_append').empty();
        }
        else{
            $('.Flight_section_append').empty();
            var no_of_stay_ID = 1;
            $flight_name = $('.airline_data').val();
            for (let i = 1; i <= no_of_stays; i++) {
                var flight_Data =   `<h3 style="padding: 12px">Departure Details : </h3>
                                     <div class="row" style="padding: 12px">
                                        <div class="col-xl-4">
                                            <label for="">Departure Airport</label>
                                            <input name="departure_airport_code[]" id="departure_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                        </div>
                                        <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                            <label for=""></label>
                                            <span id="Change_Location_${i}" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                        </div>
                                        <div class="col-xl-4">
                                            <label for="">Arrival Airport</label>
                                            <input name="arrival_airport_code[]" id="arrival_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Airline Name</label>
                                            <input type="text" id="other_Airline_Name2_${i}" value="${$flight_name}" name="other_Airline_Name2[]" class="form-control other_airline_Name1_${i} other_Airline_Name2">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Class Type</label>
                                            <select  name="departure_Flight_Type[]" id="departure_Flight_Type_${i}" class="form-control">
                                                <option value="">Select Flight Type</option>
                                                <option value="Bussiness">Bussiness</option>
                                                <option value="Economy">Economy</option>
                                                <option value="Standard">Standard</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Flight No</label>
                                            <input type="text" id="departure_flight_number_${i}" name="departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Departure Date & Time</label>
                                            <input type="datetime-local" id="departure_time_${i}" name="departure_time[]" class="form-control departure_time1_${i}" >
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Arrival Date and Time</label>
                                            <input type="datetime-local" id="arrival_time_${i}" name="arrival_time[]" class="form-control arrival_time1_${i}" >
                                        </div>
                                    </div>
                                    <div class="container total_Time_Div_data_append_${i}">
                                    </div>`;
                                    
              
                                    
                $('.Flight_section_append').append(flight_Data);
                
                addGoogleApi('departure_airport_code_'+i+'');
                addGoogleApi('arrival_airport_code_'+i+'');
                
                $('#Change_Location_'+i+'').click(function () {
                    var arrival_airport_code   = $('#arrival_airport_code_'+i+'').val();
                    var departure_airport_code = $('#departure_airport_code_'+i+'').val();
                    $('#arrival_airport_code_'+i+'').val(departure_airport_code);
                    $('#departure_airport_code_'+i+'').val(arrival_airport_code);
                });
                
                $('.arrival_time1_'+i+'').change(function () {
                    
                    var h = "hours";
                    var m = "minutes";
                    
                    var arrival_time1 = $(this).val();
                    var departure_time1 = $('.departure_time1_'+i+'').val();
                    var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
                    var date1 = new Date(departure_time1);
                    var date2 = new Date(arrival_time1);
                    var timediff = date2 - date1;
                    var minutes_Total = Math.floor(timediff / minute);
                    var total_hours   = Math.floor(timediff / hour)
                    var total_hours_minutes = parseFloat(total_hours) * 60;
                    var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
                    
                    var total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 140px;margin-top: 25px;float:right" id="no_of_stop_par${i}">Stop No ${i}</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label for="">Flight Duration</label>
                                                        <input type="text" id="total_Time" name="total_Time[]" class="form-control total_Time1_${i}" readonly style="width: 167px;">
                                                    </div>
                                                </div>`;
                    $('.total_Time_Div_data_append_'+i+'').empty()
                    $('.total_Time_Div_data_append_'+i+'').append(total_Time_Div_data);
                    $('.total_Time1_'+i+'').val(total_hours+h+ ' : ' +minutes+m);
                    
                    var no_of_stays = $('#no_of_stays').val();
                    $('#no_of_stop_par'+no_of_stays+'').html('Destination :');
            
                });
                
                $.ajax({    
                    type: "GET",
                    url: "get_other_Airline_Name",             
                    dataType: "html",                  
                    success: function(data){ 
                        var data1 = JSON.parse(data);
                        var data2 = JSON.parse(data1['airline_Name']);
                        // console.log(data2);
                    	$('#other_Airline_Name2_'+i+'').empty();
                    	$('#return_other_Airline_Name2_'+i+'').empty();
                        $.each(data2['airline_Name'], function(key, value) {
                            // console.log(value);
                            $('#other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                            $('#return_other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        });  
                    }
                });
                
                $('#departure_airport_code_'+i+'').on('change',function () {
                    setTimeout(function() {
                        console.log("Working");
                        var address = $('#departure_airport_code_'+i+'').val();
                        $('#flights_arrival_code').val(address);
                        console.log(address);
                    }, 2000);
                });
            }
        }
    });
    
    $('.arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var arrival_time1 = $(this).val();
        var departure_time1 = $('.departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1 = new Date(departure_time1);
        var date2 = new Date(arrival_time1);
        var timediff = date2 - date1;
        
        var minutes_Total = Math.floor(timediff / minute);
        
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#total_Time_Div').css('display','');
        $('.total_Time1').val(total_hours+h+ ' : ' +minutes+m);

    });
    
    $('.return_arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_arrival_time1 = $(this).val();
        var return_departure_time1 = $('.return_departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var return_date1 = new Date(return_departure_time1);
        var return_date2 = new Date(return_arrival_time1);
        var return_timediff = return_date2 - return_date1;
        
        var return_minutes_Total = Math.floor(return_timediff / minute);
        
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('#return_total_Time_Div').css('display','');
        $('.return_total_Time1').val(return_total_hours+h+ ' : ' +return_minutes+m);
        
        
    });
    
    $('#Change_Location').click(function () {
        var arrival_airport_code   = $('#arrival_airport_code').val();
        var departure_airport_code = $('#departure_airport_code').val();
        $('#arrival_airport_code').val(departure_airport_code);
        $('#departure_airport_code').val(arrival_airport_code);
    });
    // End Flights
</script>

<script>
    $("#flights_type2").on('change',function () {
        var id = $(this).val();
        $('#flights_departure_code').val(id);
    });
    
    $("#flights_type2").change(function () {
        var id = $(this).find('option:selected').attr('value');
        if(id == 'Indirect'){
            $('#return_departure_airport_code').val('');
        	$('#return_arrival_airport_code').val('');
        	$('#return_other_Airline_Name2').val('');
        	$('#return_departure_flight_number').val('');
        	$('#return_departure_time').val('');
        	$('#return_arrival_time').val('');
            
            $("#text_editer2").css("padding", "20");
            $('#flights_type_connected2').fadeIn();
            $('#flights_type_connected2').empty();
            var no_of_stays_Append = `<label for="no_of_stays">No Of Stops</label>
                                        <select  name="return_no_of_stays" id="no_of_stays2" class="form-control select2" data-toggle="select2">
                                            <option value="">Choose...</option>
                                            <option value="2">1</option>
                                            <option value="3">2</option>
                                            <option value="4">3</option>
                                        </select>`;
            $('#flights_type_connected2').append(no_of_stays_Append);
            $('#text_editer2').fadeOut();
            $('#text_editer2').fadeIn();
            $('#stop_No2').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No2">Stop No 1 :</h3>'));
            $('#return_stop_No2').replaceWith($('<h3 style="width: 182;margin-top: 25px;float:right" id="return_stop_No2">Return Stop No 1 :</h3>'));

            $('.Flight_section2').fadeOut();
            $('.return_Flight_section2').fadeOut();
            $('#total_Time_Div2').fadeOut();
            $('#return_total_Time_Div2').fadeOut();
        }
        else{
            $('#no_of_stays2').empty('');
            addGoogleApi('return_departure_airport_code');
            addGoogleApi('return_arrival_airport_code');
            
            $('.Flight_section2').fadeIn();
            $('.return_Flight_section2').fadeIn();
            $('#total_Time_Div2').fadeIn();
            $('#return_total_Time_Div2').fadeIn();
            
            $('#flights_type_connected2').fadeOut();
            $('.Flight_section_append2').empty();
            $('.return_Flight_section_append2').empty();
        	$('#text_editer2').fadeOut();
        	$('#stop_No2').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No2">Direct :</h3>'));
        	$('#return_stop_No2').replaceWith($('<h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No2">Return Direct :</h3>'));
        }
    });
    
    $('#flights_type_connected2').change(function () {
        var no_of_stays = $('#no_of_stays2').val();
        if(no_of_stays == 'NON_STOP'){
            $('.Flight_section_append').empty();
            $('.return_Flight_section_append').empty();
        }
        else{
            $('.Flight_section_append2').empty();
            $('.return_Flight_section_append2').empty();
            var no_of_stay_ID = 1;
            var flight_name = $('#return_airline_data').val();
            
            for (let i = 1; i <= no_of_stays; i++) {
                var flight_Data =   `<h3 style="padding: 12px">Return Details : </h3>
                                     <div class="row" style="padding: 12px">
                                        <div class="col-xl-4">
                                            <label for="">Departure Airport</label>
                                            <input name="return_departure_airport_code[]" id="2departure_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                        </div>
                                        <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                            <label></label>
                                            <span id="2Change_Location_${i}" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                        </div>
                                        <div class="col-xl-4">
                                            <label for="">Arrival Airport</label>
                                            <input name="return_arrival_airport_code[]" id="2arrival_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Airline Name</label>
                                            <input type="text" id="2other_Airline_Name2_${i}" value="${flight_name}" name="return_other_Airline_Name2[]" class="form-control other_airline_Name1_${i} return_other_Airline_Name2">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Class Type</label>
                                            <select  name="return_departure_Flight_Type[]" id="2departure_Flight_Type_${i}" class="form-control">
                                                <option value="">Select Flight Type</option>
                                                <option value="Bussiness">Bussiness</option>
                                                <option value="Economy">Economy</option>
                                                <option value="Standard">Standard</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Flight No</label>
                                            <input type="text" id="return_departure_flight_number_${i}" name="return_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Departure Date & Time</label>
                                            <input type="datetime-local" id="return_departure_time_${i}" name="return_departure_time[]" class="form-control 2departure_time1_${i}" >
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Arrival Date and Time</label>
                                            <input type="datetime-local" id="return_arrival_time_${i}" name="return_arrival_time[]" class="form-control 2arrival_time1_${i}" >
                                        </div>
                                    </div>
                                    <div class="container 2total_Time_Div_data_append_${i}">
                                    </div>`;
                                    
               
                                    
                $('.Flight_section_append2').append(flight_Data);
                
                addGoogleApi('2departure_airport_code_'+i+'');
                addGoogleApi('2arrival_airport_code_'+i+'');
                
                $('#2Change_Location_'+i+'').click(function () {
                    var arrival_airport_code   = $('#2arrival_airport_code_'+i+'').val();
                    var departure_airport_code = $('#2departure_airport_code_'+i+'').val();
                    $('#2arrival_airport_code_'+i+'').val(departure_airport_code);
                    $('#2departure_airport_code_'+i+'').val(arrival_airport_code);
                });
                
                $('.2arrival_time1_'+i+'').change(function () {
                    
                    var h = "hours";
                    var m = "minutes";
                    
                    var arrival_time1 = $(this).val();
                    var departure_time1 = $('.2departure_time1_'+i+'').val();
                    var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
                    var date1 = new Date(departure_time1);
                    var date2 = new Date(arrival_time1);
                    var timediff = date2 - date1;
                    var minutes_Total = Math.floor(timediff / minute);
                    var total_hours   = Math.floor(timediff / hour)
                    var total_hours_minutes = parseFloat(total_hours) * 60;
                    var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
                    
                    var total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 140px;margin-top: 25px;float:right" id="no_of_stop_par${i}">Stop No ${i}</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                    <label for="">Flight Duration</label>
                                                        <input type="text" id="2total_Time" name="return_total_Time[]" class="form-control 2total_Time1_${i}" readonly style="width: 167px;">
                                                    </div>
                                                </div>`;
                    $('.2total_Time_Div_data_append_'+i+'').empty()
                    $('.2total_Time_Div_data_append_'+i+'').append(total_Time_Div_data);
                    $('.2total_Time1_'+i+'').val(total_hours+h+ ' : ' +minutes+m);
                    
                    var no_of_stays = $('#no_of_stays').val();
                    $('#no_of_stop_par'+no_of_stays+'').html('Destination :');
            
                });
                
                $.ajax({    
                    type: "GET",
                    url: "get_other_Airline_Name",             
                    dataType: "html",                  
                    success: function(data){ 
                        var data1 = JSON.parse(data);
                        var data2 = JSON.parse(data1['airline_Name']);
                        // console.log(data2);
                    	$('#other_Airline_Name2_'+i+'').empty();
                    	$('#return_other_Airline_Name2_'+i+'').empty();
                        $.each(data2['airline_Name'], function(key, value) {
                            // console.log(value);
                            $('#2other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                            $('#2return_other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        });  
                    }
                });
                
                $('#2departure_airport_code_'+i+'').on('change',function () {
                    setTimeout(function() {
                        console.log("Working");
                        var address = $('#departure_airport_code_'+i+'').val();
                        $('#flights_arrival_code').val(address);
                        console.log(address);
                    }, 2000);
                });
                
                $('#return_Change_Location_'+i+'').click(function () {
                    var return_arrival_airport_code   = $('#return_arrival_airport_code_'+i+'').val();
                    var return_departure_airport_code = $('#return_departure_airport_code_'+i+'').val();
                    $('#return_arrival_airport_code_'+i+'').val(return_departure_airport_code);
                    $('#return_departure_airport_code_'+i+'').val(return_arrival_airport_code);
                });
                
                $('.return_arrival_time1_'+i+'').change(function () {
                    
                    var h = "hours";
                    var m = "minutes";
                    
                    var return_arrival_time1 = $(this).val();
                    var return_departure_time1 = $('.return_departure_time1_'+i+'').val();
                    var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
                    var return_date1 = new Date(return_departure_time1);
                    var return_date2 = new Date(return_arrival_time1);
                    var return_timediff = return_date2 - return_date1;
                    var return_minutes_Total = Math.floor(return_timediff / minute);
                    var return_total_hours   = Math.floor(return_timediff / hour)
                    var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
                    var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
                    
                    var return_total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 225px;margin-top: 25px;float:right" id="return_no_of_stop_par${i}">Return Stop No ${i} :</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label for="">Flight Duration</label>
                                                        <input type="text" id="return_total_Time" name="return_more_total_Time" class="form-control return_total_Time1_${i}" readonly style="width: 167px;">
                                                    </div>
                                                </div>`;
                    $('.return_total_Time_Div_data_append_'+i+'').empty()
                    $('.return_total_Time_Div_data_append_'+i+'').append(return_total_Time_Div_data);
                    $('.return_total_Time1_'+i+'').val(return_total_hours+h+ ' : ' +return_minutes+m);
                    
                    var no_of_stays = $('#no_of_stays').val();
                    $('#return_no_of_stop_par'+no_of_stays+'').html('Return Destination :');
                });
        
            }
          
        }
    });
    
    $('.arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var arrival_time1 = $(this).val();
        var departure_time1 = $('.departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1 = new Date(departure_time1);
        var date2 = new Date(arrival_time1);
        var timediff = date2 - date1;
        
        var minutes_Total = Math.floor(timediff / minute);
        
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#total_Time_Div').css('display','');
        $('.total_Time1').val(total_hours+h+ ' : ' +minutes+m);

    });
    
    $('.return_arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_arrival_time1 = $(this).val();
        var return_departure_time1 = $('.return_departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var return_date1 = new Date(return_departure_time1);
        var return_date2 = new Date(return_arrival_time1);
        var return_timediff = return_date2 - return_date1;
        
        var return_minutes_Total = Math.floor(return_timediff / minute);
        
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('#return_total_Time_Div').css('display','');
        $('.return_total_Time1').val(return_total_hours+h+ ' : ' +return_minutes+m);
        
    
    });
    // End Flights
</script>

@stop