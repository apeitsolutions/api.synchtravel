<?php

//print_r($tours);die();
// $ch_price_other_c=json_decode($tours->ch_price_other_c);
// $in_price_other_c=json_decode($tours->in_price_other_c);
// $in_markup_other_c=json_decode($tours->in_markup_other_c);
?>
<?php $currency=Session::get('currency_symbol'); ?>

@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol');
// dd($currency);
?>
<div id="flights-Airline-Name" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Flight Airline Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    <div class="mb-3">
                        <label for="username" class="form-label">Flight Airline Name</label>
                        <input class="form-control" type="other_Airline_Name" id="other_Airline_Name" name="other_Airline_Name" placeholder="">
                    </div>

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_Airline_Name" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal --> 
 
<div id="signup-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Visa Type</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Visa </label>
                        <input class="form-control" type="email" id="other_visa_type" name="other_visa_type" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="hotel-name-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Hotel Name</label>
                        <input class="form-control" type="other_Hotel_Name" id="other_Hotel_Name" name="other_Hotel_Name" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_name" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="hotel-type-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Type</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    <div class="mb-3">
                        <label for="username" class="form-label">Hotel Type</label>
                        <input class="form-control" type="other_Hotel_Type" id="other_Hotel_Type" name="other_Hotel_Type" placeholder="">
                    </div>
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_type" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="pickup-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Pickup Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Pickup Location</label>
                        <input class="form-control" type="pickup_location" id="pickup_location" name="pickup_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_PUL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="dropof-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Dropof Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Dropof Location</label>
                        <input class="form-control" type="dropof_location" id="dropof_location" name="dropof_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_DOL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->




 
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Edit Package</h4>
        <!--<div class="tab-content">-->
            <!--<div class="tab-pane show active" id="justified-tabs-preview">-->
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                <form action="{{URL::to('/updateseat',[$flights_details->id])}}" method="post" enctype="multipart/form-data" >
                    @csrf
                    <div id="progressbarwizard">
                        
                        <ul class="nav nav-pills nav-justified form-wizard-header mb-3" style="margin-right: 1px;margin-left: 1px;">
                           
                            <li class="nav-item">
                                <a href="#settings1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                    <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Flights Details</span>
                                </a>
                            </li>
                            
                            
                        </ul>
                        
                        <div class="tab-content">
                            
                          
                            <div class="tab-pane" id="settings1">
                                    @if(isset($flights_details))
                                        <div class="col-xl-12">
                                            <div class="mb-3">
                                                <div class="row">
                                                    <!--<div class="col-xl-1">-->
                                                    <!--        <input type="checkbox" id="flights_inc" data-switch="bool"/>-->
                                                    <!--        <label for="flights_inc" data-on-label="On" data-off-label="Off"></label>-->
                                                    <!--</div>-->
                                                    <div class="col-xl-3">
                                                        <h3>
                                                            Flights Included ?
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add your flights details"></i>
                                                        </h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @else
                                        <div class="col-xl-12">
                                            <div class="mb-3">
                                                <div class="row">
                                                    <div class="col-xl-1">
                                                        <input type="checkbox" id="flights_inc" data-switch="bool"/>
                                                        <label for="flights_inc" data-on-label="On" data-off-label="Off"></label>
                                                    </div>
                                                    <div class="col-xl-3">
                                                        Flights Included ?
                                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add your flights details"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endif 
                                    <!-- flights -->
                                    <div class="row" id="select_flights_inc">
                                        @if(isset($flights_details))
                                            <div class="col-xl-3" style="padding-left: 24px;">
                                                <label for="">Flight Type</label>
                                                <select name="flight_type" id="flights_type" class="form-control">
                                                    <option <?php if($flights_details->flight_type == 'Direct') echo 'selected' ?> attr="Direct" value="Direct">Direct</option>
                                                    <option <?php if($flights_details->flight_type == 'Indirect') echo 'selected' ?> attr="Indirect" value="Indirect">Indirect</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-3">
                                        <label for="">Select Supplier</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="left" title="Add your flights details"></i>-->
                                            <select class="form-control" name="supplier" required >
             <option value="">Select supplier</option>
           
             @if(isset($supplier))
             @foreach($supplier as $all_supplier)
              <option <?php if($flights_details->supplier == $all_supplier->id ) echo 'selected' ?> value="{{$all_supplier->id}}">{{$all_supplier->companyname}}</option>
              @endforeach
              @endif
           
         </select>
                                        </div>
                                        <?php
                                        // dd($flights_details->selected_flight_airline);
                                        ?>
                                            <div class="col-xl-3" style="padding-left: 24px;">
                                                <label for="">Airline</label>
                                            
                                                <select name="selected_flight_airline"  class="form-control">
            @if(isset($airline))                  
             @foreach($airline as $all_airline)
              <option <?php if($flights_details->selected_flight_airline == $all_airline->other_Airline_Name ) echo 'selected' ?> value="{{$all_airline->other_Airline_Name}}">{{$all_airline->other_Airline_Name ?? ""}}</option>
              @endforeach
              @endif
                                                </select>
                                            </div>
                                            
                                        @else
                                            <div class="col-xl-6" style="padding-left: 24px;">
                                                <label for="">Flight Type</label>
                                                <select name="flight_type" id="flights_type" class="form-control">
                                                    <option attr="select" selected>Select Flight Type</option>
                                                     <option attr="Direct" value="Direct">Direct</option>
                                                      <option attr="Indirect" value="Indirect">Indirect</option>
                                                </select>
                                            </div>
                                           
                                        @endif
                                            <div class="col-xl-3" id="flights_type_connected"></div>
                                                
                                            <div class="col-xl-3"></div>
                                        @if(!isset($flights_details))
                                            <div class="container Flight_section">
                                                <h3 style="padding: 12px">Departure Details : </h3>
                                                <div class="row" style="padding: 12px">
                                                    <div class="col-lg-4">
                                                        <label for="">Departure Airport</label>
                                                        <input name="departure_airport_code" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                                    </div>
                                                    <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                        <label for=""></label>
                                                        <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Arrival Airport</label>
                                                        <input name="arrival_airport_code" id="arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                                        
                                                    </div>
                                                    <div class="col-xl-3">
                                                        <label for="">Airline Name</label>
                                                        <input type="text" id="other_Airline_Name2" name="other_Airline_Name2" class="form-control other_airline_Name1">
                                                        <!--<div class="input-group">-->
                                                        <!--    <select type="text" id="other_Airline_Name2" name="other_Airline_Name2" class="form-control other_airline_Name1">-->
                                                            
                                                        <!--    </select>-->
                                                        <!--    <span title="Add Pickup Location" class="input-group-btn input-group-append">-->
                                                        <!--        <button class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>-->
                                                        <!--    </span>-->
                                                        <!--</div>-->
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Class Type</label>
                                                        <select  name="departure_Flight_Type" id="departure_Flight_Type" class="form-control">
                                                            <option value="">Select Flight Type</option>
                                                            <option value="Bussiness">Bussiness</option>
                                                            <option value="Economy">Economy</option>
                                                            <option value="Standard">Standard</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Flight Number</label>
                                                        <input type="text" id="simpleinput" name="departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Departure Date and Time</label>
                                                        <input type="datetime-local" id="simpleinput" name="departure_time" class="form-control departure_time1" value="" >
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Arrival Date and Time</label>
                                                        <input type="datetime-local" id="simpleinput" name="arrival_time" class="form-control arrival_time1" value="" >
                                                    </div>
                                                </div>
                                            </div>
        
                                            <div class="container" style="display:none" id="total_Time_Div">
                                                <div class="row" style="margin-left: 320px">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                         <label for="">Transit Time</label>
                                                        <input type="text" id="total_Time" name="total_Time" class="form-control total_Time1" readonly style="width: 170px;" value="">
                                                    </div>
                                                </div>
                                            </div>
        
                                            <div class="container Flight_section_append"></div>
                                            
                                            <div class="container return_Flight_section">
                                                <h3 style="padding: 12px">Return Details : </h3>
                                                <div class="row" style="padding: 12px">
                                                    <div class="col-lg-4">
                                                        <label for="">Departure Airport</label>
                                                        <input name="return_departure_airport_code" id="return_departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                    </div>
                                                    <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                        <label for=""></label>
                                                        <span id="return_Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Arrival Airport</label>
                                                        <input name="return_arrival_airport_code" id="return_arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                        
                                                    </div>
                                                    <div class="col-xl-3">
                                                        <label for="">Airline Name</label>
                                                        <input type="text" id="return_other_Airline_Name2" name="return_other_Airline_Name2" class="form-control other_airline_Name1">
                                                        <!--<div class="input-group">-->
                                                            <!--<select type="text" id="return_other_Airline_Name2" name="return_other_Airline_Name2" class="form-control other_airline_Name1">-->
                                                            
                                                            <!--</select>-->
                                                        <!--    <span title="Add Pickup Location" class="input-group-btn input-group-append">-->
                                                        <!--        <button class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>-->
                                                        <!--    </span>-->
                                                        <!--</div>-->
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Class Type</label>
                                                        <select  name="return_departure_Flight_Type" id="return_departure_Flight_Type" class="form-control">
                                                            <option value="">Select Flight Type</option>
                                                            <option value="Bussiness">Bussiness</option>
                                                            <option value="Economy">Economy</option>
                                                            <option value="Standard">Standard</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Flight Number</label>
                                                        <input type="text" id="simpleinput" name="return_departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Departure Date and Time</label>
                                                        <input type="datetime-local" id="simpleinput" name="return_departure_time" class="form-control return_departure_time1" value="" >
                                                    </div>
                                                    <div class="col-xl-3" style="margin-top: 15px;">
                                                        <label for="">Arrival Date and Time</label>
                                                        <input type="datetime-local" id="simpleinput" name="return_arrival_time" class="form-control return_arrival_time1" value="" >
                                                    </div>
                                                </div>
                                            </div>
        
                                            <div class="container" style="display:none" id="return_total_Time_Div">
                                                <div class="row" style="margin-left: 320px">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No">Return Direct :</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                         <label for="">Transit Time</label>
                                                        <input type="text" id="return_total_Time" name="return_total_Time" class="form-control return_total_Time1" readonly style="width: 170px;" value="">
                                                    </div>
                                                </div>
                                            </div>
                
                                            <div class="container return_Flight_section_append"></div>
                
                                            <div class="col-xl-6" style="padding-left: 24px;">
                                                <label for="">Price Per Person</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                                           
                                                        </a>
                                                    </span>
                                                    <input type="text" id="flights_per_person_price" name="flights_per_person_price" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-xl-12 mt-3" style="display:none" id="text_editer">
                                                    <label for="">Indirect Flight Duration and Details</label>
                                                    <textarea name="connected_flights_duration_details" class="form-control" cols="10" rows="10"></textarea>
                                                </div>
                                            <div class="col-xl-12 mt-2" style="padding-left: 24px;">
                                                <label for="">Additional Flight Details</label>
                                                <textarea name="terms_and_conditions" class="form-control" cols="5" rows="5"></textarea>
                                            </div>
                                            <div class="col-xl-12 mt-2" style="padding-left: 24px;">
                                                <label for="">image</label>
                                                <input type="file" id="" name="flights_image" class="form-control">
                                            </div>
                                            <div id="append_flights"></div>
                                            
                                        @else
                                            @if($flights_details->flight_type == 'Direct')
                                                <div class="container Flight_section direct_if_Flight_section">
                                                    <h3 style="padding: 25px">Departure Details : </h3>
                                                    <div class="row" style="padding: 25px">
                                                        <div class="col-lg-4">
                                                            <label for="">Departure Airport</label>
                                                            <input value="{{ $flights_details->departure_airport_code ?? '' }}" name="departure_airport_code" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                                        </div>
                                                        <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                            <label for=""></label>
                                                            <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <label for="">Arrival Airport</label>
                                                            <input value="{{ $flights_details->arrival_airport_code ?? '' }}" name="arrival_airport_code" id="arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                                            
                                                        </div>
                                                        <div class="col-xl-3">
                                                            <label for="">Airline Name</label>
                                                            <input type="text" value="{{ $flights_details->other_Airline_Name2 }}" id="other_Airline_Name2" name="other_Airline_Name2" class="form-control other_airline_Name1">
                                                        </div>
                                                        <div class="col-xl-3" style="margin-top: 15px;">
                                                            <label for="">Class Type</label>
                                                            <select  name="departure_Flight_Type" id="departure_Flight_Type" class="form-control">
                                                                <option <?php if($flights_details->departure_Flight_Type == 'Bussiness') echo 'selected' ?> value="Bussiness">Bussiness</option>
                                                                <option <?php if($flights_details->departure_Flight_Type == 'Direct') echo 'Economy' ?> value="Economy">Economy</option>
                                                                <option <?php if($flights_details->departure_Flight_Type == 'Direct') echo 'Standard' ?> value="Standard">Standard</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-3" style="margin-top: 15px;">
                                                            <label for="">Flight Number</label>
                                                            <input  value="{{ $flights_details->departure_flight_number ?? '' }}" type="text" id="simpleinput" name="departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                                        </div>
                                                        <div class="col-xl-3" style="margin-top: 15px;">
                                                            <label for="">Departure Date and Time</label>
                                                            <input  value="{{ $flights_details->departure_time ?? '' }}" type="datetime-local" id="simpleinput" name="departure_time" class="form-control departure_time1" value="" >
                                                        </div>
                                                        <div class="col-xl-3" style="margin-top: 15px;">
                                                            <label for="">Arrival Date and Time</label>
                                                            <input  value="{{ $flights_details->arrival_time ?? '' }}" type="datetime-local" id="simpleinput" name="arrival_time" class="form-control arrival_time1" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                                <div class="container direct_if_Time" id="total_Time_Div">
                                                    <div class="row" style="margin-left: 320px">
                                                        <div class="col-sm-3">
                                                            <h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>
                                                        </div>
                                                        <div class="col-sm-3">
                                                             <label for="">Transit Time</label>
                                                            <input value="{{ $flights_details->total_Time ?? '' }}" type="text" id="total_Time" name="total_Time" class="form-control total_Time1" readonly style="width: 170px;" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            @elseif($flights_details->flight_type == 'Indirect')
                                                <?php $i = 1; 

                                                $departur_airport = json_decode($flights_details->more_departure_airport_code);
                                                $arrival_airport = json_decode($flights_details->more_arrival_airport_code);
                                                $airline = json_decode($flights_details->more_other_Airline_Name2);
                                                $flight_type = json_decode($flights_details->more_departure_Flight_Type);
                                                $flight_number = json_decode($flights_details->more_departure_flight_number);
                                                $flight_time = json_decode($flights_details->more_departure_time);
                                                $arrival_time = json_decode($flights_details->more_arrival_time);
                                                $total_time = json_decode($flights_details->more_total_Time);
                                                $more_departure_Flight_Type = json_decode($flights_details->more_departure_Flight_Type);
                                            
                                                $flights_details_more = [];
                                                
                                                foreach($departur_airport as $key1 => $dep) {
                                            $data_arr = [
                                                    'more_departure_airport_code'=>$dep,
                                                    'more_arrival_airport_code'=>$arrival_airport[$key1],
                                                    'more_other_Airline_Name2'=>$airline[$key1],
                                                    'more_departure_Flight_Type'=>$flight_type[$key1],
                                                    'more_departure_flight_number'=>$flight_number[$key1],
                                                    'more_departure_time'=>$flight_time[$key1],
                                                    'more_arrival_time'=>$arrival_time[$key1],
                                                    'more_total_Time'=>$total_time[$key1],
                                                    'more_departure_Flight_Type'=>$more_departure_Flight_Type[$key1],
                                            ];
                                                    array_push($flights_details_more,$data_arr);
                                                    
                                                   
                                                }
                                                // dd($flights_details_more[0]['more_departure_airport_code']);
                                                
                                                ?>
                                                @foreach($flights_details_more as $value)
                                                    <div class="row indirect_else_Flight_section" style="padding: 25px">
                                                        <h3 style="padding: 25px">Departure Details : </h3>
                                                        <div class="col-lg-4">
                                                            <label for="">Departure Airport</label>
                                                            <input onchange="maps_db({{ $i }})" value="{{ $value['more_departure_airport_code'] ?? '' }}"  name="more_departure_airport_code[]" id="departure_airport_code_{{ $i }}" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                                        </div>
                                                        <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                            <label for=""></label>
                                                            <span id="Change_Location_{{ $i }}" onclick="Change_Location_arraow({{ $i }})" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <label for="">Arrival Airport</label>
                                                            <input value="{{ $value['more_arrival_airport_code'] ?? '' }}" name="more_arrival_airport_code[]" id="arrival_airport_code_{{ $i }}" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                                        </div>
                                                        <div class="col-xl-3">
                                                            <label for="">Airline Name</label>
                                                            <input type="text" value="{{ $value['more_other_Airline_Name2'] ?? '' }}" id="other_Airline_Name2_{{ $i }}" name="more_other_Airline_Name2[]" class="form-control other_airline_Name1_{{ $i }}">
                                                        </div>
                                                     <div class="col-xl-3">
                                            <label for="">Class Type</label>
                                            <select  name="more_departure_Flight_Type[]"  class="form-control">
                                                <option value="">Select Flight Type</option>
                                                @if($value['more_departure_Flight_Type'] == "Bussiness")
                                                <option selected value="Bussiness">Bussiness</option>
                                                @elseif($value['more_departure_Flight_Type'] == "Economy")
                                                <option selected value="Economy">Economy</option>
                                                @elseif($value['more_departure_Flight_Type'] == "Standard")
                                                <option selected value="Standard">Standard</option>
                                                @endif
                                            </select>
                                        </div>
                                                        <div class="col-xl-3">
                                                            <label for="">Flight No</label>
                                                            <input value="{{ $value['more_departure_flight_number'] ?? '' }}" type="text" id="simpleinput_{{ $i }}" name="more_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">Departure Date & Time</label>
                                                            <input value="{{ $value['more_departure_time'] ?? '' }}" type="datetime-local" id="simpleinput_{{ $i }}" name="more_departure_time[]" class="form-control departure_time1_{{ $i }}" >
                                                        </div>
                                                        <div class="col-xl-3">
                                                            <label for="">Arrival Date and Time</label>
                                                            <input value="{{ $value['more_arrival_time'] ?? '' }}" onchange="arrival_time_db({{ $i }})" type="datetime-local" id="simpleinput_{{ $i }}" name="more_arrival_time[]" class="form-control arrival_time1_{{ $i }}" >
                                                        </div>
                                                    </div>
                                                    <div class="container indirect_else_Time total_Time_Div_data_append_{{ $i }}">
                                                        <div class="row" style="margin-left: 303px;">
                                                            <div class="col-sm-3">
                                                                <h3 style="width: 140px;margin-top: 25px;float:right" id="no_of_stop_par{{ $i }}">Stop No {{ $i }}</h3>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <label for="">Transit Time</label>
                                                                <input value="{{ $value['more_total_Time'] ?? '' }}" type="text" id="total_Time" name="more_total_Time[]" class="form-control total_Time1_" readonly style="width: 167px;">
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php $i++; ?>
                                                @endforeach
                                                <input type="text" value="{{ $i }}" id="destination_value" hidden>
                                            @endif
                                        
                                            <div class="container Flight_section_append"></div>
                                        
                                            @if(isset($flights_details))
                                                @if($flights_details->flight_type == 'Direct')
                                                    <div class="container return_Flight_section return_direct_if_Flight_section">
                                                        <h3 style="padding: 25px">Return Details : </h3>
                                                        <div class="row" style="padding: 25px">
                                                            <div class="col-lg-4">
                                                                <label for="">Departure Airport</label>
                                                                <input value="{{ $flights_details->return_departure_airport_code ?? '' }}" name="return_departure_airport_code" id="return_departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                            </div>
                                                            <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                                <label for=""></label>
                                                                <span id="return_Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <label for="">Arrival Airport</label>
                                                                <input value="{{ $flights_details->return_arrival_airport_code ?? '' }}" name="return_arrival_airport_code" id="return_arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                                
                                                            </div>
                                                            <div class="col-xl-3">
                                                                <label for="">Airline Name</label>
                                                                <input type="text" value="{{ $flights_details->return_other_Airline_Name2 }}" id="return_other_Airline_Name2" name="return_other_Airline_Name2" class="form-control other_airline_Name1">
                                                            </div>
                                                            <div class="col-xl-3" style="margin-top: 15px;">
                                                                <label for="">Class Type</label>
                                                                <select  name="return_departure_Flight_Type" id="return_departure_Flight_Type" class="form-control">
                                                                    <option <?php if($flights_details->return_departure_Flight_Type == 'Bussiness') echo 'selected' ?> value="Bussiness">Bussiness</option>
                                                                    <option <?php if($flights_details->return_departure_Flight_Type == 'Direct') echo 'Economy' ?> value="Economy">Economy</option>
                                                                    <option <?php if($flights_details->return_departure_Flight_Type == 'Direct') echo 'Standard' ?> value="Standard">Standard</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-xl-3" style="margin-top: 15px;">
                                                                <label for="">Flight Number</label>
                                                                <input value="{{ $flights_details->return_departure_flight_number ?? '' }}" type="text" id="simpleinput" name="return_departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                                            </div>
                                                            <div class="col-xl-3" style="margin-top: 15px;">
                                                                <label for="">Departure Date and Time</label>
                                                                <input value="{{ $flights_details->return_departure_time ?? '' }}" type="datetime-local" id="simpleinput" name="return_departure_time" class="form-control return_departure_time1" value="" >
                                                            </div>
                                                            <div class="col-xl-3" style="margin-top: 15px;">
                                                                <label for="">Arrival Date and Time</label>
                                                                <input value="{{ $flights_details->return_arrival_time ?? '' }}" type="datetime-local" id="simpleinput" name="return_arrival_time" class="form-control return_arrival_time1" value="" >
                                                            </div>
                                                        </div>
                                                    </div>
                                            
                                                    <div class="container return_direct_if_Time" id="return_total_Time_Div">
                                                        <div class="row" style="margin-left: 320px">
                                                            <div class="col-sm-3">
                                                                <h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No">Return Direct :</h3>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                 <label for="">Transit Time</label>
                                                                <input value="{{ $flights_details->return_total_Time ?? '' }}" type="text" id="return_total_Time" name="return_total_Time" class="form-control return_total_Time1" readonly style="width: 170px;" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                @elseif($flights_details->flight_type == 'Indirect')
                                                    <?php $i = 1;
                                                $departur_airport = json_decode($flights_details->return_more_departure_airport_code);
                                                $arrival_airport = json_decode($flights_details->return_more_arrival_airport_code);
                                                $airline = json_decode($flights_details->return_more_other_Airline_Name2);
                                                $flight_type = json_decode($flights_details->return_more_departure_Flight_Type);
                                                $flight_number = json_decode($flights_details->return_more_departure_flight_number);
                                                $flight_time = json_decode($flights_details->return_more_departure_time);
                                                $arrival_time = json_decode($flights_details->return_more_arrival_time);
                                                $total_time = json_decode($flights_details->return_more_total_Time);
                                            
                                                $flights_details_morez = [];
                                                
                                                foreach($departur_airport as $key1 => $dep) {
                                            $data_arr = [
                                                    'return_more_departure_airport_code'=>$dep,
                                                    'return_more_arrival_airport_code'=>$arrival_airport[$key1],
                                                    'return_more_other_Airline_Name2'=>$airline[$key1],
                                                    'return_more_departure_Flight_Type'=>$flight_type[$key1],
                                                    'return_more_departure_flight_number'=>$flight_number[$key1],
                                                    'return_more_departure_time'=>$flight_time[$key1],
                                                    'return_more_arrival_time'=>$arrival_time[$key1],
                                                    'return_more_total_Time'=>$total_time[$key1],
                                            ];
                                                    array_push($flights_details_morez,$data_arr);
                                                    
                                                   
                                                }
                                                // dd($flights_details_more);
                                                ?>
                                                    @foreach($flights_details_morez as $value)
                                                        <div class="row return_indirect_else_Flight_section" style="padding: 25px">
                                                            <h3 style="padding: 25px">Return Details : </h3>
                                                            <div class="col-lg-4">
                                                                <label for="">Departure Airport</label>
                                                                <input value="{{ $value['return_more_departure_airport_code'] ?? '' }}" name="return_more_departure_airport_code[]" id="return_departure_airport_code_{{ $i }}" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                            </div>
                                                            <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                                <label for=""></label>
                                                                <span id="return_Change_Location_{{ $i }}" onclick="return_Change_Location({{ $i }})" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <label for="">Arrival Airport</label>
                                                                <input value="{{ $value['return_more_arrival_airport_code'] ?? '' }}" name="return_more_arrival_airport_code[]" id="return_arrival_airport_code_{{ $i }}" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                                
                                                            </div>
                                                            <div class="col-xl-3">
                                                                <label for="">Airline Name</label>
                                                                <input type="text" value="{{ $value['return_more_other_Airline_Name2'] ?? '' }}" id="return_other_Airline_Name2_{{ $i }}" name="return_more_other_Airline_Name2[]" class="form-control other_airline_Name1_{{ $i }}">
                                                            </div>
                                                            
                                                            <div class="col-xl-3">
                                                                <label for="">Flight Number</label>
                                                                <input value="{{ $value['return_more_departure_flight_number'] ?? '' }}" type="text" id="simpleinput_{{ $i }}" name="return_more_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                                            </div>
                                                            <div class="col-xl-3">
                                                                <label for="">Departure Date and Time</label>
                                                                <input value="{{ $value['return_more_departure_time'] ?? '' }}" type="datetime-local" id="simpleinput_{{ $i }}" name="return_more_departure_time[]" class="form-control return_departure_time1_{{ $i }}" >
                                                            </div>
                                                            <div class="col-xl-3">
                                                                <label for="">Arrival Date and Time</label>
                                                                <input onchange="return_arreturn_rival_time_db({{ $i }})" value="{{ $value->return_more_arrival_time ?? '' }}" type="datetime-local" id="simpleinput_{{ $i }}" name="return_more_arrival_time[]" class="form-control return_arrival_time1_{{ $i }}" >
                                                            </div>
                                                        </div>
                                                        <div class="container return_indirect_else_Time return_total_Time_Div_data_append_{{ $i }}">
                                                            <div class="row" style="margin-left: 303px;">
                                                                <div class="col-sm-3">
                                                                    <h3 style="width: 225px;margin-top: 25px;float:right" id="return_no_of_stop_par{{ $i }}">Return Stop No {{ $i }} :</h3>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <label for="">Transit Time</label>
                                                                    <input value="{{  $value['return_more_total_Time'] ?? '' }}" type="text" id="return_total_Time" name="return_more_total_Time[]" class="form-control return_total_Time1_" readonly style="width: 167px;">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php $i++; ?>
                                                    @endforeach
                                                @endif
                                            @endif
                                            <div class="container return_Flight_section_append"></div>
                                            
                                               <div class="col-xl-12 d-flex" style="padding-left: 24px;">
                                    <div>
                                    <label for="">Price Per Person</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              {{$currency ?? ""}}
                                            </a>
                                        </span>
                                        <input type="text" id="flights_per_person_price" name="flights_per_person_price" value="{{$flights_details->flights_per_person_price ?? ""}}" class="form-control">
                                    </div>
                                    </div>
                                    
                                     <div>
                                    <label>Number of Seats</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              {{$currency ?? ""}}
                                            </a>
                                        </span>
                                        <input type="text" id="flights_per_person_price" value="{{$flights_details->flights_number_of_seat ?? ""}}" name="flights_number_of_seat" class="form-control">
                                    </div>
                                    </div>
                                    <!-- <div>-->
                                    <!--<label for="">Price Per Seat</label>-->
                                    <!--<div class="input-group">-->
                                    <!--    <span class="input-group-btn input-group-append">-->
                                    <!--        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">-->
                                    <!--          {{$currency ?? ""}}-->
                                    <!--        </a>-->
                                    <!--    </span>-->
                                    <!--    <input type="text" id="flights_per_person_price" value="{{$flights_details->flights_per_seat_price ?? ""}}" name="flights_per_seat_price" class="form-control">-->
                                    <!--</div>-->
                                    <!--</div>-->
                                     <div>
                                    <label for="">Child Price</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              {{$currency ?? ""}}
                                            </a>
                                        </span>
                                        <input type="text" id="flights_per_person_price" value="{{$flights_details->flights_per_child_price ?? ""}}" name="flights_per_child_price" class="form-control">
                                    </div>
                                    </div>
                                     <div>
                                    <label for="">Infant Price</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              {{$currency ?? ""}}
                                            </a>
                                        </span>
                                        <input type="text" id="flights_per_person_price" value="{{$flights_details->flights_per_infant_price ?? ""}}" name="flights_per_infant_price" class="form-control">
                                    </div>
                                    </div>
                                </div>
                                            <!--<div class="col-xl-12 mt-3" style="margin-left: 11px;" id="text_editer">-->
                                            <!--    <label for="">Indirect Flight Duration and Details</label>-->
                                            <!--    <textarea value="{{ $flights_details->connected_flights_duration_details ?? 'NO DATA' }}" name="connected_flights_duration_details" class="form-control" cols="10" rows="10">{{ $flights_details->connected_flights_duration_details ?? 'EMPTY' }}</textarea>-->
                                                 
                                            <!--</div>-->
                                            <div class="col-xl-12 mt-2" style="padding-left: 24px;">
                                                <label for="">Additional Flight Details</label>
                                                <textarea value="{{ $flights_details->terms_and_conditions ?? 'NO DATA' }}" name="terms_and_conditions" class="form-control" cols="5" rows="5">{{ $flights_details->terms_and_conditions ?? 'EMPTY' }}</textarea>
                                                 
                                            </div>
                                            <!--<div class="col-xl-12 mt-2" style="padding-left: 24px;">-->
                                            <!--    <label for="">image</label>-->
                                            <!--    <input type="file" name="flights_image" class="form-control">-->
                                            <!--    <img src="" style="width:433px;height:250px" />-->
                                            <!--    <input type="text" name="flights_image_else" class="form-control" value="" readonly hidden>-->
                                            <!--</div>-->
                                            <div id="append_flights"></div>
                                        @endif
                                    </div>
                                    <!-- END Flifhts -->    
                                    <!--<a id="save_Flights" class="btn btn-primary" name="submit">Save Flights</a>-->
                                </div>
                          
                            
                            <!--<ul class="list-inline mb-0 wizard" style="margin-top:60px;">-->
                            <!--    <li class="previous list-inline-item">-->
                            <!--        <a href="javascript:void(0);" style="width: 100px;margin-left: 5px;" class="btn btn-info">Previous</a>-->
                            <!--    </li>-->
                            <!--    <li class="next list-inline-item float-end">-->
                            <!--        <a href="javascript:void(0);" style="width: 100px;margin-right: 25px;" class="btn btn-info">Next</a>-->
                            <!--    </li>-->
                            <!--</ul>-->
                             <button class="btn btn-primary mt-5" id="submitForm_Airline_Name" type="submit">Submit</button>
                        </div>
                        
                    </div>
                </form>
            <!--</div>-->
        <!--</div>-->
    </div>
</div>

@endsection

@section('scripts')

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js" integrity="sha512-6F1RVfnxCprKJmfulcxxym1Dar5FsT/V2jiEUvABiaEiFWoQ8yHvqRM/Slf0qJKiwin6IDQucjXuolCfCKnaJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('.summernote').summernote({
         
        });
    });
</script>

<script>
    
    function validate1(id) {
    	$('.file_error'+id+'').html("");
    	$('.gallery_imagesP'+id+'').css("border-color","#F0F0F0");
    	var file_size = $('.gallery_imagesP'+id+'')[0].files[0].size;
    	if(file_size > 100000) {
    		$('.file_error'+id+'').html("File size is greater than 100kb");
    		$('.gallery_imagesP'+id+'').css("border-color","#FF0000");
    		return false;
    	} 
    	return true;
    }
    
</script>

<script>
    function remove_gallery_img(imgId){
        $('#galleryImg'+imgId+'').remove();
    }
    
    function remove_acc_img(imgId){
        $('#accImg'+imgId+'').remove();
    }
    
    function remove_acc_div(id){
        
        var city_No1 = $('#city_No').val();
        var city_No = parseFloat(city_No1) - 1;
        $('#city_No').val(city_No);
        
        // $('#city_No1').removeAttr('value');
        
        var starting_acc = $('#starting_acc'+id+'').val();
        console.log(starting_acc);
        var ending_acc   = $('#ending_acc'+id+'').val();
        console.log(ending_acc);
        
        for(var i=starting_acc; i<ending_acc; i++){
            $('#click_delete1_'+i+'').remove();
        }
        
        $('#del_acc'+id+'').remove();
        $('#costing_acc'+id+'').remove();
        
        put_tour_location_else();
        add_numberElse();
    }
    
</script>

<!--Flights-->

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

<script>
    
    let places,places1,return_places,return_places1,places_T,places1_T,return_places_T,return_places1_T ,input, address, city;
    
    google.maps.event.addDomListener(window, "load", function () {
        
        var hotel_map = $("#hotel_map").val();
        for(var i=1; i<hotel_map; i++){
            
            // console.log('hotel_map : '+hotel_map)
            // console.log('i new : '+i);
            
            var placesH = new google.maps.places.Autocomplete(
                    document.getElementById('acc_hotel_name_'+i+'')
                );
            
            google.maps.event.addListener(placesH, "place_changed", function () {
                var place = placesH.getPlace();
                console.log('place : '+place);
                var address = place.formatted_address;
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng();
                var latlng = new google.maps.LatLng(latitude, longitude);
                var geocoder = (geocoder = new google.maps.Geocoder());
                geocoder.geocode({ latLng: latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            var address = results[0].formatted_address;
                            var pin =
                            results[0].address_components[
                        results[0].address_components.length - 1
                      ].long_name;
                            var country =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].long_name;
                            var state =
                              results[0].address_components[
                                results[0].address_components.length - 3
                              ].long_name;
                            var city =
                              results[0].address_components[
                                results[0].address_components.length - 4
                              ].long_name;
                            var country_code =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].short_name;
                            $('#country').val(country);
                            $('#lat').val(latitude);
                            $('#long').val(longitude);
                            $('#pin').val(pin);
                            $('#city').val(city);
                            $('#country_code').val(country_code);
                        }
                    }
                });
            });
            
        }
        
        var placesH = new google.maps.places.Autocomplete(
            document.getElementsByClassName('other_Hotel_Name1')
        );
        google.maps.event.addListener(placesH, "place_changed", function () {
            var place = placesH.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            $('#flights_arrival_code').val(address);
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // Departure_airport_code
        // 1
        var placesDB1 = new google.maps.places.Autocomplete(
            document.getElementById('departure_airport_code_1')
        );
        google.maps.event.addListener(placesDB1, "place_changed", function () {
            var place = placesDB1.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            $('#flights_arrival_code').val(address);
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 2
        var placesDB2 = new google.maps.places.Autocomplete(
            document.getElementById('departure_airport_code_2')
        );
        google.maps.event.addListener(placesDB2, "place_changed", function () {
            var place = placesDB2.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 3
        var placesDB3 = new google.maps.places.Autocomplete(
            document.getElementById('departure_airport_code_3')
        );
        google.maps.event.addListener(placesDB3, "place_changed", function () {
            var place = placesDB3.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 4
        var placesDB4 = new google.maps.places.Autocomplete(
            document.getElementById('departure_airport_code_4')
        );
        google.maps.event.addListener(placesDB4, "place_changed", function () {
            var place = placesDB4.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 5
        var placesDB5 = new google.maps.places.Autocomplete(
            document.getElementById('departure_airport_code_5')
        );
        google.maps.event.addListener(placesDB5, "place_changed", function () {
            var place = placesDB5.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        // END_departure_airport_code
        
        // Arrival_airport_code
        // 1
        var placesADB1 = new google.maps.places.Autocomplete(
            document.getElementById('arrival_airport_code_1')
        );
        google.maps.event.addListener(placesADB1, "place_changed", function () {
            var place = placesADB1.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 2
        var placesADB2 = new google.maps.places.Autocomplete(
            document.getElementById('arrival_airport_code_2')
        );
        google.maps.event.addListener(placesADB2, "place_changed", function () {
            var place = placesADB2.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 3
        var placesADB3 = new google.maps.places.Autocomplete(
            document.getElementById('arrival_airport_code_3')
        );
        google.maps.event.addListener(placesADB3, "place_changed", function () {
            var place = placesADB3.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 4
        var placesADB4 = new google.maps.places.Autocomplete(
            document.getElementById('arrival_airport_code_4')
        );
        google.maps.event.addListener(placesADB4, "place_changed", function () {
            var place = placesADB4.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 5
        var placesADB5 = new google.maps.places.Autocomplete(
            document.getElementById('arrival_airport_code_5')
        );
        google.maps.event.addListener(placesADB5, "place_changed", function () {
            var place = placesADB5.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        // END_arrival_airport_code
        
        // Return_departure_airport_code
        // 1
        var placesRDB1 = new google.maps.places.Autocomplete(
            document.getElementById('return_departure_airport_code_1')
        );
        google.maps.event.addListener(placesRDB1, "place_changed", function () {
            var place = placesRDB1.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 2
        var placesRDB2 = new google.maps.places.Autocomplete(
            document.getElementById('return_departure_airport_code_2')
        );
        google.maps.event.addListener(placesRDB2, "place_changed", function () {
            var place = placesRDB2.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 3
        var placesRDB3 = new google.maps.places.Autocomplete(
            document.getElementById('return_departure_airport_code_3')
        );
        google.maps.event.addListener(placesRDB3, "place_changed", function () {
            var place = placesRDB3.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 4
        var placesRDB4 = new google.maps.places.Autocomplete(
            document.getElementById('return_departure_airport_code_4')
        );
        google.maps.event.addListener(placesRDB4, "place_changed", function () {
            var place = placesRDB4.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 5
        var placesRDB5 = new google.maps.places.Autocomplete(
            document.getElementById('return_departure_airport_code_5')
        );
        google.maps.event.addListener(placesRDB5, "place_changed", function () {
            var place = placesRDB5.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        // END_return_departure_airport_code
        
        // Return_arrival_airport_code
        // 1
        var placesRADB1 = new google.maps.places.Autocomplete(
            document.getElementById('return_arrival_airport_code_1')
        );
        google.maps.event.addListener(placesRADB1, "place_changed", function () {
            var place = placesRADB1.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 2
        var placesRADB2 = new google.maps.places.Autocomplete(
            document.getElementById('return_arrival_airport_code_2')
        );
        google.maps.event.addListener(placesRADB2, "place_changed", function () {
            var place = placesRADB2.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 3
        var placesRADB3 = new google.maps.places.Autocomplete(
            document.getElementById('return_arrival_airport_code_3')
        );
        google.maps.event.addListener(placesRADB3, "place_changed", function () {
            var place = placesRADB3.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 4
        var placesRADB4 = new google.maps.places.Autocomplete(
            document.getElementById('return_arrival_airport_code_4')
        );
        google.maps.event.addListener(placesRADB4, "place_changed", function () {
            var place = placesRADB4.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // 5
        var placesRADB5 = new google.maps.places.Autocomplete(
            document.getElementById('return_arrival_airport_code_5')
        );
        google.maps.event.addListener(placesRADB5, "place_changed", function () {
            var place = placesRADB5.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        // END_return_arrival_airport_code
                
        var places = new google.maps.places.Autocomplete(
            document.getElementById("departure_airport_code")
        );
        
        var places1 = new google.maps.places.Autocomplete(
            document.getElementById("arrival_airport_code")
        );
        
        google.maps.event.addListener(places, "place_changed", function () {
            var place = places.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(places1, "place_changed", function () {
            var place1 = places1.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // Return_Details
        var return_places = new google.maps.places.Autocomplete(
            document.getElementById("return_departure_airport_code")
        );
        
        var return_places1 = new google.maps.places.Autocomplete(
            document.getElementById("return_arrival_airport_code")
        );
        
        google.maps.event.addListener(return_places, "place_changed", function () {
            var return_place = return_places.getPlace();
            // console.log(return_place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(return_places1, "place_changed", function () {
            var return_place1 = return_places1.getPlace();
            // console.log(return_place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // Transporation_Details
        var places_T = new google.maps.places.Autocomplete(
            document.getElementById("transportation_pick_up_location")
        );
        
        var places1_T = new google.maps.places.Autocomplete(
            document.getElementById("transportation_drop_off_location")
        );
        
        google.maps.event.addListener(places_T, "place_changed", function () {
            var place = places_T.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(places1_T, "place_changed", function () {
            var place1 = places1_T.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                        $("#transportation_drop_off_location").on('change',function () {
                            var b = $('#transportation_drop_off_location_select').val(city);
                            console.log(b);
                        });
                    }
                }
            });
        });
        
        // Return_Transportation_Details
        var return_places_T = new google.maps.places.Autocomplete(
            document.getElementById("return_transportation_pick_up_location")
        );
        
        var return_places1_T = new google.maps.places.Autocomplete(
            document.getElementById("return_transportation_drop_off_location")
        );
        
        google.maps.event.addListener(return_places_T, "place_changed", function () {
            var place = return_places_T.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code); 
                    }
                }
            });
        });
        
        google.maps.event.addListener(return_places1_T, "place_changed", function () {
            var place1 = return_places1_T.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
    });
    
</script>

<script>

    $( document ).ready(function() {
        var destination_value = $('#destination_value').val();
        destination_value = destination_value - 1;
        $('#no_of_stop_par'+destination_value+'').html('Destination :');
        $('#return_no_of_stop_par'+destination_value+'').html('Return Destination :');
    });
    
    function Change_Location_arraow(id)
    {
        var arrival_airport_code   = $('#arrival_airport_code_'+id+'').val();
        var departure_airport_code = $('#departure_airport_code_'+id+'').val();
        $('#arrival_airport_code_'+id+'').val(departure_airport_code);
        $('#departure_airport_code_'+id+'').val(arrival_airport_code);
    }
    
    function return_Change_Location(id)
    {
        var return_arrival_airport_code   = $('#return_arrival_airport_code_'+id+'').val();
        var return_departure_airport_code = $('#return_departure_airport_code_'+id+'').val();
        $('#return_arrival_airport_code_'+id+'').val(return_departure_airport_code);
        $('#return_departure_airport_code_'+id+'').val(return_arrival_airport_code);
    }
    
    function arrival_time_db(id)
    {
        var h = "hours";
        var m = "minutes";
        
        var arrival_time1 = $('.arrival_time1_'+id+'').val();
        var departure_time1 = $('.departure_time1_'+id+'').val();
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var date1 = new Date(departure_time1);
        var date2 = new Date(arrival_time1);
        var timediff = date2 - date1;
        var minutes_Total = Math.floor(timediff / minute);
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('.total_Time_Div_data_append_'+id+'').empty();
        var total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                        <div class="col-sm-3">
                                            <h3 style="width: 140px;margin-top: 25px;float:right" id="no_of_stop_par${i}">Stop No ${i}</h3>
                                        </div>
                                        <div class="col-sm-3">
                                            <label for="">Transit Time</label>
                                            <input type="text" id="total_Time" name="more_total_Time[]" class="form-control total_Time1_${i}" readonly style="width: 167px;">
                                        </div>
                                    </div>`;
        
        $('.total_Time_Div_data_append_'+id+'').append(total_Time_Div_data);
        $('.total_Time1_'+id+'').val(total_hours+h+ ' : ' +minutes+m);
        
        var destination_value = $('#destination_value').val();
        destination_value = destination_value - 1;
        $('#no_of_stop_par'+destination_value+'').html('Destination :');

    }
    
    function return_arrival_time_db(id)
    {
        var h = "hours";
        var m = "minutes";
        
        var return_arrival_time1 = $('.return_arrival_time1_'+id+'').val();
        var return_departure_time1 = $('.return_departure_time1_'+id+'').val();
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var return_date1 = new Date(return_departure_time1);
        var return_date2 = new Date(return_arrival_time1);
        var return_timediff = return_date2 - return_date1;
        var return_minutes_Total = Math.floor(return_timediff / minute);
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('.return_total_Time_Div_data_append_'+id+'').empty();
        var return_total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                        <div class="col-sm-3">
                                            <h3 style="width: 225px;margin-top: 25px;float:right" id="return_no_of_stop_par${i}">Return Stop No ${i} :</h3>
                                        </div>
                                        <div class="col-sm-3">
                                            <label for="">Transit Time</label>
                                            <input type="text" id="return_total_Time" name="return_more_total_Time[]" class="form-control return_total_Time1_${i}" readonly style="width: 167px;">
                                        </div>
                                    </div>`;
        
        $('.return_total_Time_Div_data_append_'+id+'').append(return_total_Time_Div_data);
        $('.return_total_Time1_'+id+'').val(return_total_hours+h+ ' : ' +return_minutes+m);
        
        var destination_value = $('#destination_value').val();
        destination_value = destination_value - 1;
        $('#return_no_of_stop_par'+destination_value+'').html('Return Destination :');
    }
    
</script>

<!--End Flights-->

<script type="text/javascript">

    $("#switch2").click(function () {
        $('#markup_services').slideToggle();
        $('#all_services_markup').slideToggle();
        $('#markup_seprate_services').slideToggle();
        $('#sale_pr').slideToggle();
        
        var switchValue = $('#markupSwitch').val();
        if(switchValue == 'single_markup_switch'){
            $('#markupSwitch').val('all_markup_switch');
            
            var all_markup_add1 = $('#all_markup_add1').val();
            $('#all_markup_add').val(all_markup_add1);
        }
        else{
            $('#markupSwitch').val('single_markup_switch');
            $('#all_markup_add').val(0);
        }
    });
 
    $("#all_markup_type").change(function () {
        
        var id = $(this).find('option:selected').attr('value');
    
        $('#select_mrk').text(id);
        
        if(id == '%'){
            $('#all_markup_add').keyup(function() {
                
                var markup_val        =  $('#all_markup_add').val();
                var quad_cost_price   =  $('#quad_cost_price').val();
                var triple_cost_price =  $('#triple_cost_price').val();
                var double_cost_price =  $('#double_cost_price').val();
           
                if(quad_cost_price != 0){
                    var total_quad_cost_price1 = (quad_cost_price * markup_val/100) + parseFloat(quad_cost_price);
                    var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
                    $('#quad_markup').val(total_quad_cost_price);
                }else{
                   $('#quad_markup').val(0);
                }
       
                if(triple_cost_price != 0){
                    var total_triple_cost_price1 = (triple_cost_price * markup_val/100) + parseFloat(triple_cost_price);
                    var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
                    $('#triple_markup').val(total_triple_cost_price);
                }else{
                    $('#triple_markup').val(0);
                }
                
                if(double_cost_price != 0){
                    var total_double_cost_price1 = (double_cost_price * markup_val/100) + parseFloat(double_cost_price);
                    var total_double_cost_price = total_double_cost_price1.toFixed(2);
                    $('#double_markup').val(total_double_cost_price);
                }else{
                    $('#double_markup').val(0);
                }
            });
        }
        else
        {
            $('#all_markup_add').keyup(function() {
                var markup_val        =  $('#all_markup_add').val();
                var quad_cost_price   =  $('#quad_cost_price').val();
                var triple_cost_price =  $('#triple_cost_price').val();
                var double_cost_price =  $('#double_cost_price').val();
            
                if(quad_cost_price != 0){
                    var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
                    var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
                    $('#quad_markup').val(total_quad_cost_price);  
                }else{
                   $('#quad_markup').val(0);
                }
           
                if(triple_cost_price != 0){
                    var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
                    var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
                    $('#triple_markup').val(total_triple_cost_price);    
                }else{
                    $('#triple_markup').val(0);
                }
                
                if(double_cost_price != 0){
                    var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
                    var total_double_cost_price = total_double_cost_price1.toFixed(2);
                    $('#double_markup').val(total_double_cost_price);
                }else{
                    $('#double_markup').val(0);
                }
            });
        }

    });
    
    $('#all_markup_add').keyup(function() {
        
        var id = $("#all_markup_type").find('option:selected').attr('value');
        $('#select_mrk').text(id);
        
        if(id == '%'){
            var markup_val        =  $('#all_markup_add').val();
            var quad_cost_price   =  $('#quad_cost_price').val();
            var triple_cost_price =  $('#triple_cost_price').val();
            var double_cost_price =  $('#double_cost_price').val();
       
            if(quad_cost_price != 0){
                var total_quad_cost_price1 = (quad_cost_price * markup_val/100) + parseFloat(quad_cost_price);
                var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
                $('#quad_markup').val(total_quad_cost_price);   
            }else{
               $('#quad_markup').val(0);
            }
   
            if(triple_cost_price != 0){
                var total_triple_cost_price1 = (triple_cost_price * markup_val/100) + parseFloat(triple_cost_price);
                var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
                $('#triple_markup').val(total_triple_cost_price);    
            }else{
                $('#triple_markup').val(0);
            }
            
            if(double_cost_price != 0){
                var total_double_cost_price1 = (double_cost_price * markup_val/100) + parseFloat(double_cost_price);
                var total_double_cost_price = total_double_cost_price1.toFixed(2);
                $('#double_markup').val(total_double_cost_price);
            }else{
                $('#double_markup').val(0);
            }
        }
        else{
            var markup_val        =  $('#all_markup_add').val();
            var quad_cost_price   =  $('#quad_cost_price').val();
            var triple_cost_price =  $('#triple_cost_price').val();
            var double_cost_price =  $('#double_cost_price').val();
        
            if(quad_cost_price != 0){
                var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
                var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
                $('#quad_markup').val(total_quad_cost_price);  
            }else{
               $('#quad_markup').val(0);
            }
       
            if(triple_cost_price != 0){
                var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
                var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
                $('#triple_markup').val(total_triple_cost_price);    
            }else{
                $('#triple_markup').val(0);
            }
            
            if(double_cost_price != 0){
                var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
                var total_double_cost_price = total_double_cost_price1.toFixed(2);
                $('#double_markup').val(total_double_cost_price);
            }else{
                $('#double_markup').val(0);
            }
        }
    });

    $(document).on('click','#visa_inc',function(){
        $.ajax({    
            type: "GET",
            url: "get_other_visa_type",             
            dataType: "html",                  
            success: function(data){  
            
                var data1 = JSON.parse(data);
                var data2= JSON.parse(data1['visa_type']);
                //   console.log(data2['visa_type']);
                // jQuery.each(data2, function(key, value){  
                //     $(".other_type").append('<option value=' +value.id+ '>' + value.other_visa_type+ '</option>');
                //   });
            	$("#visa_type").empty();
           
                $.each(data2['visa_type'], function(key, value) {
                    var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.id}"> ${value.other_visa_type}</option>`;
                    $("#visa_type").append(visa_type_Data);
                });  
            }
        });
    });
    
    // $(document).on('click','#transportation',function(){
    //     $.ajax({    
    //         type: "GET",
    //         url: "get_pickup_dropof_location",             
    //         dataType: "html",                  
    //         success: function(data){
    //             var data1 = JSON.parse(data);
    //             var data2 = data1['pickup_location_get'];
    //             var data3 = data1['dropof_location_get'];
    //         	$(".pickup_location").empty();
    //             $(".dropof_location").empty();
    //             $.each(data2, function(key, value) {
    //                 var pickup_location_Data = `<option attr="${value.pickup_location}" value="${value.pickup_location}"> ${value.pickup_location}</option>`;
    //                 $(".pickup_location").append(pickup_location_Data);
    //             });
    //             $.each(data3, function(key, value) {
    //                 var dropof_location_Data = `<option attr="${value.dropof_location}" value="${value.dropof_location}"> ${value.dropof_location}</option>`;
    //                 $(".dropof_location").append(dropof_location_Data);
    //             });
    //         }
    //     });
    // });

    $('#submitForm_PUL').on('click',function(e){
        e.preventDefault();
        let pickup_location = $('#pickup_location').val();
        $.ajax({
            url: "submit_pickup_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                pickup_location:pickup_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['pickup_location_get'];
                    $(".pickup_location").empty();
                    $.each(data, function(key, value) {
                        var pickup_location_Data = `<option attr="${value.pickup_location}" value="${value.pickup_location}"> ${value.pickup_location}</option>`;
                        $(".pickup_location").append(pickup_location_Data);
                    });
                    alert('Pickup Location Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm_DOL').on('click',function(e){
        e.preventDefault();
        let dropof_location = $('#dropof_location').val();
        $.ajax({
            url: "submit_dropof_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                dropof_location:dropof_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['dropof_location_get'];
                    $(".dropof_location").empty();
                    $.each(data, function(key, value) {
                        var dropof_location_Data = `<option attr="${value.dropof_location}" value="${value.dropof_location}"> ${value.dropof_location}</option>`;
                        $(".dropof_location").append(dropof_location_Data);
                    });
                    alert('DropOf Location Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm').on('click',function(e){
        e.preventDefault();
        let other_visa_type = $('#other_visa_type').val();
        $.ajax({
            url: "submit_other_visa_type",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_visa_type:other_visa_type,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['visa_type_get'];
                    console.log(data);
                    $("#visa_type").empty();
                    $.each(data, function(key, value) {
                        var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.id}"> ${value.other_visa_type}</option>`;
                        $("#visa_type").append(visa_type_Data);
                    });
                    alert('Visa Other Type Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm_Airline_Name').on('click',function(e){
        e.preventDefault();
        let other_Airline_Name = $('#other_Airline_Name').val();
        $.ajax({
            url: "submitForm_Airline_Name",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_Airline_Name:other_Airline_Name,
            },
            success:function(response){
                // console.log(response);
                if(response){
                    var data1 = response;
                    var data = data1['other_Airline_Name_get'];
                    // console.log(data);
                    $("#other_Airline_Name2").empty();
                    $("#return_other_Airline_Name2").empty();
                    $.each(data, function(key, value) {
                        // console.log(value.other_Airline_Name);
                        $("#other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        $("#return_other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                    });
                    alert('Other Airline Name Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
  </script>

<script>

</script>

<script>

function selectCities_on(id){
      var country = $('#destination_'+id+'').val();
      console.log(country);
      $.ajaxSetup({
         headers: {
             'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
         }
      });
      $.ajax({
         url: "{{ url('/country_cites') }}",
         method: 'post',
         data: {
             "_token": "{{ csrf_token() }}",
             "id": country,
         },
         success: function(result){
             console.log('cites is call now');
           console.log(result);
           $('#destination_city_'+id+'').html(result);
         },
         error:function(error){
             console.log(error);
         }
      });
   }


 function deleteRowDes(id){
  
     $('#click_delete_'+id+'').remove();
     

 }
 
 

</script>

<script>
    function selectCountry(id,val,shortcode) {
      var suggesstion=  $("#"+id).attr("data-suggestion");
      var shrtcode   =  $("#"+id).parent(".flight").children(".shrtcode");
      $("#"+id).val(val);
      $("#"+suggesstion).hide();
      $(shrtcode).val(shortcode);
    }
  </script>

<script>
    $(".get_flight_name").keyup(function(){

      console.log('This is call ');
      var searchinput = $(this);
      var suggesstion=  $(searchinput).attr("data-suggestion");
      var id = $(this).attr("id");
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var keyword = $(this).val();
      // console.log('This is call id is '+id+' data suggesstion '+suggesstion);
      $.ajax({
        type: "POST",
        url: '{{URL::to('get_flight_name')}}',
        data: {
          _token    : CSRF_TOKEN,
          'keyword' : keyword,
          "id"      : id,
        },
        success: function(data){
          $("#"+suggesstion).show();
          $("#"+suggesstion).html(data['thml']);
          $(searchinput).css("background","#FFF");
        }
      });
    });

  </script>
  
@stop

@section('slug')

<script>

    $('#transportation_price_per_vehicle').keyup(function() {
            
   var transportation_price_per_vehicle =  $('#transportation_price_per_vehicle').val();
   var transportation_no_of_vehicle =  $('#transportation_no_of_vehicle').val();
    var no_of_pax_days =  $('#no_of_pax_days').val();
    
    
    var t_trans1 = transportation_price_per_vehicle * transportation_no_of_vehicle;
    var t_trans = t_trans1.toFixed(2);
  console.log('t_trans'+t_trans);
  $('#transportation_vehicle_total_price').val(t_trans)
        var total_trans1 = t_trans/no_of_pax_days;
        var total_trans = total_trans1.toFixed(2);
          console.log('total_trans'+total_trans);
        $('#transportation_price_per_person').val(total_trans)
        
  $('#transportation_price_per_person_select').val(total_trans);
  add_numberElse();
});

    $('#return_transportation_price_per_vehicle').keyup(function() {    
        var return_transportation_price_per_vehicle =  $('#return_transportation_price_per_vehicle').val();
        var return_transportation_no_of_vehicle =  $('#return_transportation_no_of_vehicle').val();
        var no_of_pax_days =  $('#no_of_pax_days').val();
        
        var return_t_trans1 = return_transportation_price_per_vehicle * return_transportation_no_of_vehicle;
        var return_t_trans = return_t_trans1.toFixed(2);
        console.log('return_t_trans'+return_t_trans);
        $('#return_transportation_vehicle_total_price').val(return_t_trans)
        var return_total_trans1 = return_t_trans/no_of_pax_days;
        var return_total_trans = return_total_trans1.toFixed(2);
          console.log('return_total_trans'+return_total_trans);
        $('#return_transportation_price_per_person').val(return_total_trans)
        
        // $('#return_transportation_price_per_person_select').val(return_total_trans);
        add_numberElse();
    });

    $("#flights_type").on('change',function () {
        var id = $(this).val();
        $('#flights_departure_code').val(id);
    });
    
    $("#departure_Flight_Type").change(function () {
        var id = $(this).val();
        $('#flights_arrival_code').val(id);
    });
  
    $("#markup_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        
        $('#markup_value_markup_mrk').text(id);
        var markup_val =  $('#markup_value').val();
        
        var flights_prices =  $('#flights_prices').val();
        if(id == '%')
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                var total1 = (flights_prices * markup_val/100) + parseFloat(flights_prices) ;
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1();
            });
        }
        else
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                console.log(markup_val);
                var total1 = parseFloat(flights_prices) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1();
            });
        }
    });
    
    
        
    $('#markup_value').keyup(function() {
        var id = $(this).find('option:selected').attr('value');
        $('#markup_value_markup_mrk').text(id);
        var markup_val      =  $('#markup_value').val();
        var flights_prices  =  $('#flights_prices').val();
        
        if(id == '%'){
            var markup_val =  $('#markup_value').val();
            var total1 = (flights_prices * markup_val/100) + parseFloat(flights_prices) ;
            var total = total1.toFixed(2);
            $('#total_markup').val(total);
            add_numberElse_1();
        }
        else
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                console.log(markup_val);
                var total1 = parseFloat(flights_prices) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1();
            });
        }
    });
      
    $('#property_city').change(function(){
        var arr=[];
        $('#property_city option:selected').each(function(){
            var $value = $(this).attr('type');
            arr.push($value);
        });
        
        var json_data=JSON.stringify(arr);
        $('#tour_location_city').val(json_data);
        $('#packages_get_city').val(json_data);
        
        $('#accomodation_On_Off').css('display','');
        
        $('#click_delete_1').remove();
        
        
        // $('#hotel_city_name_hidden').val(json_data);
    });
    
    $('#property_city_edit').change(function(){
        var arr=[];
        $('#property_city_edit option:selected').each(function(){
            var $value = $(this).attr('type');
            // console.log($value);
            arr.push($value);
        });
        // console.log(arr);
        var json_data=JSON.stringify(arr);
        $('#tour_location_city').val(json_data); 
        $('#packages_get_city').val(json_data);
    });

    $("#visa_type").change(function () {
        var id = $(this).find('option:selected').attr('attr');
        console.log(id);
        $('#visa_type_select').val(id);
    });
    
    $("#visa_markup_type").change(function () {
            var id = $(this).find('option:selected').attr('value');
            $('#visa_mrk').text(id);
            // var markup_val =  $('#visa_markup').val();
            // var visa_price_select =  $('#visa_price_select').val();
            if(id == '%')
            {
                $('#visa_markup').keyup(function() {
                    var markup_val =  $('#visa_markup').val();
                    var visa_price_select =  $('#visa_price_select').val();
                    var total1 = (visa_price_select * markup_val/100) + parseFloat(visa_price_select);
                    var total = total1.toFixed(2);
                    $('#total_visa_markup').val(total);
                    add_numberElse_1();
                });
            }
            else
            {
                $('#visa_markup').keyup(function() {
                    var markup_val =  $('#visa_markup').val();
                    var visa_price_select =  $('#visa_price_select').val();
                    var total1 =  parseFloat(visa_price_select) +  parseFloat(markup_val);
                    var total = total1.toFixed(2);
                    $('#total_visa_markup').val(total);
                    add_numberElse_1();
                });
            }
        });
        
    $('#visa_fee').keyup(function() {
        
        var visa_fee = this.value;
        $('#visa_price_select').val(visa_fee);
        add_numberElse();
    });
        
    $("#transportation_pick_up_location").on('keyup',function () {
            setTimeout(function() { 
                var id = $('#transportation_pick_up_location').val();
                console.log('transportation_pick_up_location :'+id+'');
                $('#transportation_pick_up_location_select').val(id);
            }, 10000);
        });
        
    $("#transportation_drop_off_location").change(function () {
            setTimeout(function() { 
                var id = $('#transportation_drop_off_location').val();
                console.log('transportation_drop_off_location :'+id+'');
                $('#transportation_drop_off_location_select').val(id);
            }, 10000);
        });
        
    $("#return_transportation_pick_up_location").change(function () {
        var id = this.value;
        
        $('#return_transportation_pick_up_location_select').val(id);
        
        
        });
        
    $("#return_transportation_drop_off_location").change(function () {
        var id = this.value;
        
        $('#return_transportation_drop_off_location_select').val(id);
        
        
        });
        
    $("#transportation_price_per_person").change(function () {
        var id = this.value;
        
        $('#transportation_price_per_person_select').val(id);
        
        
        
        
        });
        
    $("#transportation_markup_type").change(function () {
            var id = $(this).find('option:selected').attr('value');
            $('#transportation_markup_mrk').text(id);
            if(id == '%')
            {
                $('#transportation_markup').keyup(function() {
                var markup_val =  $('#transportation_markup').val();
                var transportation_price =  $('#transportation_price_per_person_select').val();
                var total1 = (transportation_price * markup_val/100) + parseFloat(transportation_price);
                var total = total1.toFixed(2);
                $('#transportation_markup_total').val(total);
                add_numberElse_1();
                });
            }
            else
            {
                $('#transportation_markup').keyup(function() {
                var markup_val =  $('#transportation_markup').val();
                console.log(markup_val);
                var transportation_price =  $('#transportation_price_per_person_select').val();
                var total1 = parseFloat(transportation_price) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#transportation_markup_total').val(total);
                add_numberElse_1();
                });
            }
        });
  
    $('#flights_per_person_price').keyup(function() {
   
    var flights_per_person_price = this.value;
   $('#flights_prices').val(flights_per_person_price);
    add_numberElse();
 
});

    $("#flights_inc").click(function () {
   $('#flights_cost').toggle();

  });

    $("#transportation").click(function () {
   $('#transportation_cost').toggle();
	
  });

    $("#visa_inc").click(function () {
   $('#visa_cost').toggle();
	
  });

    $("#slect_trip").change(function () {
    var id = $(this).find('option:selected').attr('value');
    // alert(id);
    if(id == 'Return')
    {
    $('#add_more_destination').fadeOut();
    	$('#select_return').fadeIn();
    
    }
    else if(id == 'All_Round')
    {
    	$('#select_return').fadeOut();
    	$('#add_more_destination').fadeIn();
    
    }
    else
    {
      	$('#select_return').fadeOut();
      	$('#add_more_destination').fadeOut();
    }






    });

    // $("#visa_type").change(function () {
    //     var id = $(this).find('option:selected').attr('value');
    //     // alert(id);
    //     if(id == 'Others')
    //     {
    //     	$('#SubmitForm_sec').fadeOut();
    //     	$('#SubmitForm_sec').fadeIn();
        
    //     }
        
    //     else
    //     {
    //     	$('#SubmitForm_sec').fadeOut();
    //     }

    // });

</script>

<script>
    
    // Usama Ali Changes
    
    // Flights
    $("#flights_type").change(function () {
            var id = $(this).find('option:selected').attr('value');
            if(id == 'Indirect')
            {
                $("#text_editer").css("padding", "20");
                $('#flights_type_connected').fadeIn();
                $('#flights_type_connected').empty();
                var no_of_stays_Append = `<label for="no_of_stays">No Of Stays</label>
                                            <select  name="no_of_stays" id="no_of_stays" class="form-control select2" data-toggle="select2">
                                                <option value="">Choose...</option>
                                                <option value="2">1</option>
                                                <option value="3">2</option>
                                                <option value="4">3</option>
                                            </select>`;
                $('#flights_type_connected').append(no_of_stays_Append);
                $('#text_editer').fadeOut();
                $('#text_editer').fadeIn();
                $('#stop_No').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Stop No 1 :</h3>'));
                $('#return_stop_No').replaceWith($('<h3 style="width: 182;margin-top: 25px;float:right" id="return_stop_No">Return Stop No 1 :</h3>'));

                $('.Flight_section').fadeOut();
                $('.return_Flight_section').fadeOut();
                $('#total_Time_Div').fadeOut();
                $('#return_total_Time_Div').fadeOut();
                
                $('.direct_if_Flight_section').fadeOut();
                $('.direct_if_Time').fadeOut();
                $('.return_direct_if_Flight_section').fadeOut();
                $('.return_direct_if_Time').fadeOut();
                
                $('.indirect_else_Flight_section').fadeIn();
                $('.indirect_else_Time').fadeIn();
                $('.return_indirect_else_Flight_section').fadeIn();
                $('.return_indirect_else_Time').fadeIn();
                
            }
            else
            {
                $('.direct_if_Flight_section').fadeIn();
                $('.direct_if_Time').fadeIn();
                $('.return_direct_if_Flight_section').fadeIn();
                $('.return_direct_if_Time').fadeIn();
                
                $('.indirect_else_Flight_section').fadeOut();
                $('.indirect_else_Time').fadeOut();
                $('.return_indirect_else_Flight_section').fadeOut();
                $('.return_indirect_else_Time').fadeOut();
                
                $('.Flight_section').fadeIn();
                $('.return_Flight_section').fadeIn();
                $('#total_Time_Div').fadeIn();
                $('#return_total_Time_Div').fadeIn();
                
                $('#flights_type_connected').fadeOut();
                $('.Flight_section_append').empty();
                $('.return_Flight_section_append').empty();
            	$('#text_editer').fadeOut();
            	$('#stop_No').replaceWith($('<h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>'));
            	$('#return_stop_No').replaceWith($('<h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No">Return Direct :</h3>'));
            }
        });
   
    $('#flights_type_connected').change(function () {
        var no_of_stays = $('#no_of_stays').val();
        if(no_of_stays == 'NON_STOP'){
            $('.Flight_section_append').empty();
            $('.return_Flight_section_append').empty();
        }
        else{
            $('.Flight_section_append').empty();
            $('.return_Flight_section_append').empty();
            var no_of_stay_ID = 1;
            for (let i = 1; i <= no_of_stays; i++) {
                var flight_Data =   `<h3 style="padding: 12px">Departure Details : </h3>
                                     <div class="row" style="padding: 12px">
                                        <div class="col-lg-4">
                                            <label for="">Departure Airport</label>
                                            <input name="more_departure_airport_code[]" id="departure_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                        </div>
                                        <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                            <label for=""></label>
                                            <span id="Change_Location_${i}" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                        </div>
                                        <div class="col-lg-4">
                                            <label for="">Arrival Airport</label>
                                            <input name="more_arrival_airport_code[]" id="arrival_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Airline Name</label>
                                            <div class="input-group">
                                                <select type="text" id="other_Airline_Name2_${i}" name="more_other_Airline_Name2[]" class="form-control other_airline_Name1_${i}">
                                                
                                                </select>
                                                <span title="Add Pickup Location" class="input-group-btn input-group-append">
                                                    <button class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Class Type</label>
                                            <select  name="more_departure_Flight_Type[]" id="departure_Flight_Type_${i}" class="form-control">
                                                <option value="">Select Flight Type</option>
                                                <option value="Bussiness">Bussiness</option>
                                                <option value="Economy">Economy</option>
                                                <option value="Standard">Standard</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Flight No</label>
                                            <input type="text" id="simpleinput_${i}" name="more_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Departure Date & Time</label>
                                            <input type="datetime-local" id="simpleinput_${i}" name="more_departure_time[]" class="form-control departure_time1_${i}" >
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Arrival Date and Time</label>
                                            <input type="datetime-local" id="simpleinput_${i}" name="more_arrival_time[]" class="form-control arrival_time1_${i}" >
                                        </div>
                                    </div>
                                    <div class="container total_Time_Div_data_append_${i}">
                                    </div>`;
                                    
                var return_flight_Data = `<h3 style="padding: 12px">Return Details : </h3>
                                          <div class="row" style="padding: 12px">
                                            <div class="col-xl-4">
                                                <label for="">Departure Airport</label>
                                                <input name="return_more_departure_airport_code[]" id="return_departure_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                            </div>
                                            <div class="col-lg-1" style="margin-top: 25px;text-align: center;">
                                                <label for=""></label>
                                                <span id="return_Change_Location_${i}" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                            </div>
                                            <div class="col-xl-4">
                                                <label for="">Arrival Airport</label>
                                                <input name="return_more_arrival_airport_code[]" id="return_arrival_airport_code_${i}" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                                
                                            </div>
                                            <div class="col-xl-3">
                                                <label for="">Airline Name</label>
                                                <div class="input-group">
                                                    <select type="text" id="return_other_Airline_Name2_${i}" name="return_more_other_Airline_Name2[]" class="form-control other_airline_Name1">
                                                    
                                                    </select>
                                                    <span title="Add Pickup Location" class="input-group-btn input-group-append">
                                                        <button class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-xl-3">
                                                <label for="">Class Type</label>
                                                <select  name="return_more_departure_Flight_Type[]" id="return_departure_Flight_Type_${i}" class="form-control">
                                                    <option value="">Select Flight Type</option>
                                                    <option value="Bussiness">Bussiness</option>
                                                    <option value="Economy">Economy</option>
                                                    <option value="Standart">Standart</option>
                                                </select>
                                            </div>
                                            <div class="col-xl-3">
                                                <label for="">Flight Number</label>
                                                <input type="text" id="simpleinput_${i}" name="return_more_departure_flight_number[]" class="form-control" placeholder="Enter Flight Number">
                                            </div>
                                            <div class="col-xl-3">
                                                <label for="">Departure Date and Time</label>
                                                <input type="datetime-local" id="simpleinput_${i}" name="return_more_departure_time[]" class="form-control return_departure_time1_${i}" >
                                            </div>
                                            <div class="col-xl-3">
                                                <label for="">Arrival Date and Time</label>
                                                <input type="datetime-local" id="simpleinput_${i}" name="return_more_arrival_time[]" value="{{ $value->return_more_arrival_time ?? '' }}"  class="form-control return_arrival_time1_${i}" >
                                            </div>
                                        </div>
                                        <div class="container return_total_Time_Div_data_append_${i}">
                                        </div>`;
                                    
                $('.Flight_section_append').append(flight_Data);
                
                $('#Change_Location_'+i+'').click(function () {
                    var arrival_airport_code   = $('#arrival_airport_code_'+i+'').val();
                    var departure_airport_code = $('#departure_airport_code_'+i+'').val();
                    $('#arrival_airport_code_'+i+'').val(departure_airport_code);
                    $('#departure_airport_code_'+i+'').val(arrival_airport_code);
                });
                
                $('.arrival_time1_'+i+'').change(function () {
                    
                    var h = "hours";
                    var m = "minutes";
                    
                    var arrival_time1 = $(this).val();
                    var departure_time1 = $('.departure_time1_'+i+'').val();
                    var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
                    var date1 = new Date(departure_time1);
                    var date2 = new Date(arrival_time1);
                    var timediff = date2 - date1;
                    var minutes_Total = Math.floor(timediff / minute);
                    var total_hours   = Math.floor(timediff / hour)
                    var total_hours_minutes = parseFloat(total_hours) * 60;
                    var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
                    
                    var total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 140px;margin-top: 25px;float:right" id="no_of_stop_par${i}">Stop No ${i}</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label for="">Transit Time</label>
                                                        <input type="text" id="total_Time" name="more_total_Time[]" class="form-control total_Time1_${i}" readonly style="width: 167px;">
                                                    </div>
                                                </div>`;
                    $('.total_Time_Div_data_append_'+i+'').empty()
                    $('.total_Time_Div_data_append_'+i+'').append(total_Time_Div_data);
                    $('.total_Time1_'+i+'').val(total_hours+h+ ' : ' +minutes+m);
                    
                    var no_of_stays = $('#no_of_stays').val();
                    $('#no_of_stop_par'+no_of_stays+'').html('Destination :');
            
                });
                
                $.ajax({    
                    type: "GET",
                    url: "get_other_Airline_Name",             
                    dataType: "html",                  
                    success: function(data){ 
                        var data1 = JSON.parse(data);
                        var data2 = JSON.parse(data1['airline_Name']);
                        // console.log(data2);
                    	$('#other_Airline_Name2_'+i+'').empty();
                    	$('#return_other_Airline_Name2_'+i+'').empty();
                        $.each(data2['airline_Name'], function(key, value) {
                            // console.log(value);
                            $('#other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                            $('#return_other_Airline_Name2_'+i+'').append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        });  
                    }
                });
                
                var places_D1 = new google.maps.places.Autocomplete(
                    document.getElementById('departure_airport_code_'+i+'')
                );
                
                var places1_D1 = new google.maps.places.Autocomplete(
                    document.getElementById('arrival_airport_code_'+i+'')
                );
                
                google.maps.event.addListener(places_D1, "place_changed", function () {
                    var places_D1 = places_D1.getPlace();
                    // console.log(places_D1);
                    var address = places_D1.formatted_address;
                    var latitude = places_D1.geometry.location.lat();
                    var longitude = places_D1.geometry.location.lng();
                    var latlng = new google.maps.LatLng(latitude, longitude);
                    var geocoder = (geocoder = new google.maps.Geocoder());
                    geocoder.geocode({ latLng: latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                var address = results[0].formatted_address;
                                var pin = results[0].address_components[
                                    results[0].address_components.length - 1
                                ].long_name;
                                var country =  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].long_name;
                                var state = results[0].address_components[
                                        results[0].address_components.length - 3
                                    ].long_name;
                                var city = results[0].address_components[
                                        results[0].address_components.length - 4
                                    ].long_name;
                                var country_code = results[0].address_components[
                                        results[0].address_components.length - 2
                                    ].short_name;
                                $('#country').val(country);
                                $('#lat').val(latitude);
                                $('#long').val(longitude);
                                $('#pin').val(pin);
                                $('#city').val(city);
                                $('#country_code').val(country_code);
                            }
                        }
                    });
                });
                
                google.maps.event.addListener(places1_D1, "place_changed", function () {
                    var places1_D1 = places1_D1.getPlace();
                    // console.log(places1_D1);
                    var address = places1_D1.formatted_address;
                    var latitude = places1_D1.geometry.location.lat();
                    var longitude = places1_D1.geometry.location.lng();
                    var latlng = new google.maps.LatLng(latitude, longitude);
                    var geocoder = (geocoder = new google.maps.Geocoder());
                    geocoder.geocode({ latLng: latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                var address = results[0].formatted_address;
                                var pin =
                                results[0].address_components[
                            results[0].address_components.length - 1
                          ].long_name;
                                var country =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].long_name;
                                var state =
                                  results[0].address_components[
                                    results[0].address_components.length - 3
                                  ].long_name;
                                var city =
                                  results[0].address_components[
                                    results[0].address_components.length - 4
                                  ].long_name;
                                var country_code =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].short_name;
                                $('#country').val(country);
                                $('#lat').val(latitude);
                                $('#long').val(longitude);
                                $('#pin').val(pin);
                                $('#city').val(city);
                                $('#country_code').val(country_code);
                            }
                        }
                    });
                });
                
                // Return_Details
                $('.return_Flight_section_append').append(return_flight_Data);
                
                $('#return_Change_Location_'+i+'').click(function () {
                    var return_arrival_airport_code   = $('#return_arrival_airport_code_'+i+'').val();
                    var return_departure_airport_code = $('#return_departure_airport_code_'+i+'').val();
                    $('#return_arrival_airport_code_'+i+'').val(return_departure_airport_code);
                    $('#return_departure_airport_code_'+i+'').val(return_arrival_airport_code);
                });
                
                $('.return_arrival_time1_'+i+'').change(function () {
                    
                    var h = "hours";
                    var m = "minutes";
                    
                    var return_arrival_time1 = $(this).val();
                    var return_departure_time1 = $('.return_departure_time1_'+i+'').val();
                    var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
                    var return_date1 = new Date(return_departure_time1);
                    var return_date2 = new Date(return_arrival_time1);
                    var return_timediff = return_date2 - return_date1;
                    var return_minutes_Total = Math.floor(return_timediff / minute);
                    var return_total_hours   = Math.floor(return_timediff / hour)
                    var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
                    var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
                    
                    var return_total_Time_Div_data  = `<div class="row" style="margin-left: 303px;">
                                                    <div class="col-sm-3">
                                                        <h3 style="width: 225px;margin-top: 25px;float:right" id="return_no_of_stop_par${i}">Return Stop No ${i} :</h3>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label for="">Transit Time</label>
                                                        <input type="text" id="return_total_Time" name="return_more_total_Time[]" class="form-control return_total_Time1_${i}" readonly style="width: 167px;">
                                                    </div>
                                                </div>`;
                    $('.return_total_Time_Div_data_append_'+i+'').empty()
                    $('.return_total_Time_Div_data_append_'+i+'').append(return_total_Time_Div_data);
                    $('.return_total_Time1_'+i+'').val(return_total_hours+h+ ' : ' +return_minutes+m);
                    
                    var no_of_stays = $('#no_of_stays').val();
                    $('#return_no_of_stop_par'+no_of_stays+'').html('Return Destination :');
                });
                
                var return_places = new google.maps.places.Autocomplete(
                    document.getElementById('return_departure_airport_code_'+i+'')
                );
        
                var return_places1 = new google.maps.places.Autocomplete(
                    document.getElementById('return_arrival_airport_code_'+i+'')
                );
        
                google.maps.event.addListener(return_places, "place_changed", function () {
                    var return_place = return_places.getPlace();
                    console.log(return_place);
                    var address = place.formatted_address;
                    var latitude = place.geometry.location.lat();
                    var longitude = place.geometry.location.lng();
                    var latlng = new google.maps.LatLng(latitude, longitude);
                    var geocoder = (geocoder = new google.maps.Geocoder());
                    geocoder.geocode({ latLng: latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                var address = results[0].formatted_address;
                                var pin =
                                results[0].address_components[
                            results[0].address_components.length - 1
                          ].long_name;
                                var country =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].long_name;
                                var state =
                                  results[0].address_components[
                                    results[0].address_components.length - 3
                                  ].long_name;
                                var city =
                                  results[0].address_components[
                                    results[0].address_components.length - 4
                                  ].long_name;
                                var country_code =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].short_name;
                                $('#country').val(country);
                                $('#lat').val(latitude);
                                $('#long').val(longitude);
                                $('#pin').val(pin);
                                $('#city').val(city);
                                $('#country_code').val(country_code);
                            }
                        }
                    });
                });
        
                google.maps.event.addListener(return_places1, "place_changed", function () {
                    var return_place1 = return_places1.getPlace();
                    console.log(return_place1);
                    var address = place1.formatted_address;
                    var latitude = place1.geometry.location.lat();
                    var longitude = place1.geometry.location.lng();
                    var latlng = new google.maps.LatLng(latitude, longitude);
                    var geocoder = (geocoder = new google.maps.Geocoder());
                    geocoder.geocode({ latLng: latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                var address = results[0].formatted_address;
                                var pin =
                                results[0].address_components[
                            results[0].address_components.length - 1
                          ].long_name;
                                var country =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].long_name;
                                var state =
                                  results[0].address_components[
                                    results[0].address_components.length - 3
                                  ].long_name;
                                var city =
                                  results[0].address_components[
                                    results[0].address_components.length - 4
                                  ].long_name;
                                var country_code =
                                  results[0].address_components[
                                    results[0].address_components.length - 2
                                  ].short_name;
                                $('#country').val(country);
                                $('#lat').val(latitude);
                                $('#long').val(longitude);
                                $('#pin').val(pin);
                                $('#city').val(city);
                                $('#country_code').val(country_code);
                            }
                        }
                    });
                });
            } 
        }
    });
    
    $('.arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var arrival_time1 = $(this).val();
        var departure_time1 = $('.departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1 = new Date(departure_time1);
        var date2 = new Date(arrival_time1);
        var timediff = date2 - date1;
        
        var minutes_Total = Math.floor(timediff / minute);
        
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#total_Time_Div').css('display','');
        $('.total_Time1').val(total_hours+h+ ' : ' +minutes+m);

    });
    
    $('.return_arrival_time1').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_arrival_time1 = $(this).val();
        var return_departure_time1 = $('.return_departure_time1').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var return_date1 = new Date(return_departure_time1);
        var return_date2 = new Date(return_arrival_time1);
        var return_timediff = return_date2 - return_date1;
        
        var return_minutes_Total = Math.floor(return_timediff / minute);
        
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('#return_total_Time_Div').css('display','');
        $('.return_total_Time1').val(return_total_hours+h+ ' : ' +return_minutes+m);
        
        
    });
    
    $('#Change_Location').click(function () {
        var arrival_airport_code   = $('#arrival_airport_code').val();
        var departure_airport_code = $('#departure_airport_code').val();
        $('#arrival_airport_code').val(departure_airport_code);
        $('#departure_airport_code').val(arrival_airport_code);
    });
    
    $('#return_Change_Location').click(function () {
        var return_arrival_airport_code   = $('#return_arrival_airport_code').val();
        var return_departure_airport_code = $('#return_departure_airport_code').val();
        $('#return_arrival_airport_code').val(return_departure_airport_code);
        $('#return_departure_airport_code').val(return_arrival_airport_code);
    });
    // End Flights
    
    // Transportation
    $('#transportation_drop_of_date').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var transportation_drop_of_date = $(this).val();
        var transportation_pick_up_date = $('#transportation_pick_up_date').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1 = new Date(transportation_pick_up_date);
        var date2 = new Date(transportation_drop_of_date);
        var timediff = date2 - date1;
        
        var minutes_Total = Math.floor(timediff / minute);
        
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#transportation_Time_Div').css('display','');
        $('#transportation_total_Time').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
    $('#return_transportation_drop_of_date').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_transportation_drop_of_date = $(this).val();
        var return_transportation_pick_up_date = $('#return_transportation_pick_up_date').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var return_date1 = new Date(return_transportation_pick_up_date);
        var return_date2 = new Date(return_transportation_drop_of_date);
        var return_timediff = return_date2 - return_date1;
        
        var return_minutes_Total = Math.floor(return_timediff / minute);
        
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('#return_transportation_Time_Div').css('display','');
        $('#return_transportation_total_Time').val(return_total_hours+h+ ' : ' +return_minutes+m);
    
    });
    // End Transportation
    
    // End Changes
    $(document).ready(function () {
        
                var value_c= $("#currency_conversion").val();
          
             
             //var attr_conversion_type = $('option:selected', this).attr('attr_conversion_type');
        
                // var v = ( this.code );
                 //alert(code);
                 var status = $('#currency_conversion option:selected').attr('attr_conversion_type');
        
       
         $("#select_exchange_type").val(status);
         console.log('status is '+status);
const usingSplit = value_c.split(' ');
var value_1 = usingSplit['0'];
var value_2 = usingSplit['3'];

// console.log(value_1);
// console.log(value_2);
//   console.log(attr_conversion_type);            
exchange_currency_funs(value_1,value_2);
               
                 
                
        });
</script>

@stop