@extends('template/frontend/userdashboard/layout/default')
@section('content')
<?php

// dd($hotels);
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <div class="container-fluid">
        <div class="dashboard-page">
           
        </div>
        <br>
     
       
                <div class="panel container-fluid pt-5 pb-5">
                    <h1>Search</h1>
                    <div class="row">
                        
 
                                <div class="col">
                                    <lable>Hotel Name:</lable>
                                   <select class="form-control searched_hotel" required name="hotel_name:">
                                       <option value="" readonly>Select Hotel</option>
                                        @foreach($hotels as $hotels)
                                          <option value="{{$hotels->id ?? ""}}">{{$hotels->property_name ?? ""}}</option>
                                        @endforeach
                                        </select>
                                </div>
                                <div class="col">
                                    <lable>From:</lable>
                                    <input type="date" class="form-control from_date" required name="hotel_namem" placeholder="Makkah Hotel Name">
                                </div>
                                <div class="col">
                                    <lable>Upto & Including:</lable>
                                    <input type="date" class="form-control including_date" required name="hotel_namem" placeholder="Makkah Hotel Name">
                                </div>
                                <div class="col">
                                    <button class="btn btn-primary mt-3 search_btn"><i class="fas fa-search"></i></button>
                                </div>
                               
                                
                                
                    </div>
                    
                    <br>
                    <br>
                    
                    <div class="row">
                    
 
                                <div class="col-2">
                                    <div><button class="btn btn-primary  " style="background-color: #2861a7;"></button> Total Rooms</div>
                                </div>
                                <div class="col-2">
                                     <div><button class="btn btn-primary  " style="background-color: #a5a728;"></button> Remaining Rooms</div>
                                </div>
                                <div class="col-2">
                                     <div><button class="btn btn-primary  " style="background-color: #f10000;"></button> Website booked</div>
                                </div>
                                <div class="col-2">
                                     <div> <button class="btn btn-primary  " style="background-color: #4caf50;"></button> Admin booked</div>
                                </div>
                                <div class="col-2">
                                     <div><button class="btn btn-primary  " style="background-color: #c229c5;"></button> Package booked</div>
                                </div>
                                
                                
                                
                    </div>
                        
 
                  
                    <div class="container mt-5">
                        
                        
                         
                    <div class="row mx-0">
                    <div class="col-sm-2 px-0 check_col_hide">
                        <!--<table cellpadding="0" cellspacing="0" class="calendar table table-bordered table-striped">-->
                        <!--    <tbody>-->
                                
                        <!--        <tr class="calendar-row pb-auto">-->
                        <!--            <td class="calendar-day p-3" style="vertical-align: inherit !important;">-->
                        <!--            <div class="day-number">Dates</div></td>-->
                                    
                                    
                        <!--                </tr>-->
                                        
                                        
                                        
                                         
                        <!--                    <tr class="calendar-row append_for_supplier">-->
                                                
                                             
                                           
                        <!--                    </tr>-->
                        <!--                    <tr class="calendar-row append_for_supplier_more">-->
                                                
                                             
                                           
                        <!--                    </tr>-->
                                            
                                          
                                            
                        <!--                    </tbody>-->
                        <!--                    </table>-->
                    </div>
                    
                    <div class="col-sm-12 px-1">
                    <div style="width: 100% !important; overflow: scroll;" class="count_table">
                        <table class="table table-bordered table-striped  nowrap example1 dataTable no-footer" id="example1">
                            <thead>
                                <tr class="dates_append">
                                   
                                </tr>
                            </thead>
                            <tbody>
                               
                                <tr class="calendar-row single_append ">
                                    
                                   
                                </tr>
                                <tr class="calendar-row single_append_more">
                                    
                                   
                                </tr>
                                        
                                        
                                        
                                <tr class="calendar-row double_append">
                                          
                                </tr>
                                
                                
                                <tr class="calendar-row triple_append">
                                          
                                </tr>
                                
                                <tr class="calendar-row quad_append">
                                          
                                </tr>
                                           
                                            </tbody>
                                            </table>
                                            </div>      
                    

           
                       </div>
                              
                              </div>
                              </div>
        </div>
        <br>
       
    </div>
@endsection


<script src="https://code.jquery.com/jquery-3.6.0.slim.min.js" integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" crossorigin="anonymous"></script>

 <script type="text/javascript">
               $(document).ready(function () {
                    // $('.check_col_hide').hide();
                //   $('.count_table').hide();
                    $('.search_btn').on('click',function(){  
                        $('.search_btn').hide();
                       
                        
                    var hotel = $('.searched_hotel').val();
                    
            
                     if(hotel != ""){
                     
                        var startDate = $('.from_date').val();
                        
                        if(startDate !=""){
                           
                             var includingDate = $('.including_date').val();
                           
                             
                             if(includingDate !=''){
                                
                              
                                 var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                                 
                                $.ajax({
                                     url :  '{{URL::to('chart_data')}}',
                                     type: 'POST',
                                    data: {_token: CSRF_TOKEN,
                                  "hotel": hotel,
                                  "startDate": startDate,
                                  "includingDate": includingDate
                                          },
                               
                            success: function(response){  
                                 $('.search_btn').show();
                              
                               
                                var result_single = response['singel_booking'];
                                var result_single_booked_record = response['singel_booked_record'];
                                var admin_result_single_booked_record = response['admin_single_invoice'];
                                var single_package_record = response['package_single'];
                                // console.log(result_single);
                                // console.log(result_single_booked_record);
                                // console.log(admin_result_single_booked_record);
                                // console.log(single_package_record);
                                
                                var result_double = response['double_booking'];
                                var result_double_booked_record = response['double_booked_record'];
                                var admin_result_double_booked_record = response['admin_double_invoice'];
                                var double_package_record = response['package_double'];
                                // console.log(result_double);
                                // console.log(result_double_booked_record);
                            
                                var result_triple = response['triple_booking'];
                                var result_triple_booked_record = response['triple_booked_record'];
                                 var admin_result_triple_booked_record = response['admin_triple_invoice'];
                                var triple_package_record = response['package_triple'];
                                console.log(admin_result_triple_booked_record);
                                console.log(triple_package_record);
                                
                                var result_quad = response['quad_booking'];
                                var result_quad_booked_record = response['quad_booked_record'];
                                // console.log(result_quad);
                                // console.log(result_quad_booked_record);
                            
                                var date = response['dates'];
                                //   console.log(date);
                                  
                                  
                                $('.dates_append').html("");
                                $('.single_append').html("");
                                $('.single_suplier').html("");
                                $('.double_append').html("");
                                $('.double_suplier').html("");
                                $('.single_append_more').html("");
                                $('.triple_append').html("");
                                $('.quad_append').html("");
                                // $('.append_for_supplier_more').html("");
                               
                                //  to make dates
                                var th =`<th style='padding: 37px;'>Dates</th>`;
                                for (var i = 0; i < date.length; i++) {
      
        			    		      th +=`<th>${date[i]}</th>`;
       		    			   
                            	}
                            	$('.dates_append').append(th);
                            	
                            	
                        
            
                    
                            	
                            
                            // 	to make single booking
                            for (var s = 0; s < result_single.length; s++) {
                            // 	 console.log(result_single[s]['more_room']);
                            	 var singel_more_room = result_single[s]['more_room'];
                            	 var room_dates = result_single[s]['data'];
                            	 var room_supplier = result_single[s]['supplier_name'];
                            // 	 var more_supplier_name = result_single[s]['more_supplier_name'];
                            	 
            
                            	
        //                     	 if(result_single[s]['more_room']){
                            	 
        //                     	 console.log(result_single[s]['more_room']);
        //                     	 var more_room =`<td>
    			 //<div class='row' style='background-color: #363b42;border-radius: 6px;height: 3rem;'>
        			    		     
        // 			                 <div class='col-6' style=''>
        // 			    		     <span class='badge supplier_span' title='Supplier Name' style='background-color: #2861a7;'>${result_single[s]['more_supplier_name']}</span>
        			    		    
        // 			    		     </div>
        // 			    <div class='col-6'>
        // 			    		  <div class='row'>
        			    		  
        // 			    		      <div class='col-12' style='padding: 12px;'>
        // 			    		      <span class='badge' title='RoomType' style='background-color: #4caf50;'>${result_single[s]['more_room_type']}</span>
        // 			    		      </div>
        			    		      
        			    		     
        			    		     
        // 			    		  </div>
        // 			    </div>
	    		 //</div>
        // 			    		     </td>`;
        //                     	 for (var sr = 0; sr < singel_more_room.length; sr++) {
        //                     	     console.log(singel_more_room[sr]);
                            	 
        			    		     
        			    		     
        // 			    		      more_room += `<td><div style='background-color: #363b42;padding: 12px 0px;position: relative;width: 100%;border-radius: 6px;'><span class='badge' title='Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>${singel_more_room[sr]['more_quantity']}</span><span class='badge booking_span' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>0</span></div></td>`
        			    		     
        			    		    
                            	  
        //                     	 }
        //                     	 }else{
        //                     	      var more_room = `<td><div style='background-color: #363b42;padding: 12px 0px;position: relative;width: 100%;border-radius: 6px;'><span class='badge' title='Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>0</span><span class='badge booking_span' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>0</span></div></td>` 
        //                     	 }
        //                     	  $('.single_append_more').append(more_room); 
                            	
                            	 
                            	 var room_supllier_td = `<td>
    			 <div class='row' style='background-color: #363b42;border-radius: 6px;height: 3rem;'>
        			    		     
        			    		     <div class='col-6' style=''>
        			    		     <span class='badge supplier_span' title='Supplier Name' style='background-color: #2861a7;'>${room_supplier}</span>
        			    		    
        			    		     </div>
        			    <div class='col-6'>
        			    		  <div class='row'>
        			    		  
        			    		      <div class='col-12' style='padding: 20px;'>
        			    		      <span class='badge' title='RoomType' style='background-color: #4caf50;'>Single</span>
        			    		      </div>
        			    		      
        			    		     
        			    		     
        			    		  </div>
        			    </div>
	    		 </div>
        			    		     </td>`
        			    		    
        			    		     
        			    		   //  $('.single_suplier').append(room_supllier_td);
                            	 
                            	 
                            	 for (var a = 0; a < room_dates.length; a++) {
                            	     var total_romm = room_dates[a]['total_rooms'];
                            	   var booked_qty = result_single_booked_record[a]['booked_rooms_single'];
                            	    if (booked_qty) {
                                        var booked_qtyz = booked_qty;
                                        var total_room = booked_qtyz;
                                    }else{
                                        var booked_qtyz = 0;
                                        var total_room = 0;
                                    } 
                                    if (admin_result_single_booked_record[a]['acc_qty']) {
                                        var admin_inc_room = admin_result_single_booked_record[a]['acc_qty'];
                                        var total_room = parseFloat(room_dates[a]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(total_room);
                                    }else{
                                        var admin_inc_room = 0;
                                         var total_room = room_dates[a]['total_rooms'];
                                    }
                                    if (single_package_record[a]['package_acc_type']) {
                                        var pac_inc_room = single_package_record[a]['package_acc_qty'];
                                         var total_room = parseFloat(room_dates[a]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(pac_inc_room);
                                    }else{
                                        var pac_inc_room = 0;
                                         var total_room = total_room;
                                    }
                                 
                            	     var room_date = date[a];
                            	     var inc = [a];
                            	   //  console.log(room_date);
                              room_supllier_td += `<td><div style='background-color: #363b42;padding: 25px 7px;position: relative;border-radius: 6px;'><span class='badge' title='Total Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>${total_romm}</span> <span class='badge' title='Remaining Room' style='background-color: #a5a728;/* padding: 19px; */position: absolute;top: 0;left: 62;'>${total_room}</span> <span class='badge booking_span${a}' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>${booked_qtyz}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #4caf50;/* padding: 19px; */position: absolute;right: 36'>${admin_inc_room}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #c229c5;/* padding: 19px; */position: absolute;'>${pac_inc_room}</span></div></td>`
                			    		     
                			    		     
      			    		    
                           	     
                            	 }
                            	 $('.single_append').append(room_supllier_td); 
                            	 
                            }
                            
                            
                            
                            
                            //to make double
                            for (var d = 0; d < result_double.length; d++) {
                            // 	 console.log(result_single[d]);
                            
                            	 var room_dates = result_double[d]['data'];
                            	 var room_supplier = result_double[d]['supplier_name'];
                            	 
                            	 var room_supllier_td = `<td>
    			 <div class='row' style='background-color: #363b42;border-radius: 6px;height: 3rem;'>
        			    		     
        			    		     <div class='col-6' style=''>
        			    		     <span class='badge supplier_span' title='Supplier Name' style='background-color: #2861a7;'>${room_supplier}</span>
        			    		    
        			    		     </div>
        			    <div class='col-6'>
        			    		  <div class='row'>
        			    		  
        			    		      <div class='col-12' style='padding: 20px;'>
        			    		      <span class='badge' title='RoomType' style='background-color: #4caf50;'>Double</span>
        			    		      </div>
        			    		      
        			    		     
        			    		     
        			    		  </div>
        			    </div>
	    		 </div>
        			    		     </td>`
        			    		    
        			    		     
        			    		   //  $('.double_suplier').append(room_supllier_td);
                            	
                            	 
                            	 for (var b = 0; b < room_dates.length; b++) {
                            	     var total_romm = room_dates[b]['total_rooms'];
                            	   // var booked_qty = result_double_booked_record[b]['booked_rooms_single'];
                            	    if (result_double_booked_record[b]['booked_rooms_single']) {
                            	        console.log("if");
                                        var booked_qtyz = result_double_booked_record[b]['booked_rooms_single'];
                                        var total_room =  booked_qtyz;
                                    }else{
                                        console.log("else");
                                        var booked_qtyz = 0;
                                         var total_room = 0;
                                    }
                                    if (admin_result_double_booked_record[b]['acc_qty']) {
                                        var admin_inc_room = admin_result_single_booked_record[b]['acc_qty'];
                                        var total_room = parseFloat(room_dates[b]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(booked_qtyz) - parseFloat(total_room);
                                    }else{
                                        var admin_inc_room = 0;
                                         var total_room = room_dates[b]['total_rooms'];
                                    }
                                    if (double_package_record[b]['package_acc_type']) {
                                        var pac_inc_room = single_package_record[b]['package_acc_qty'];
                                          var total_room = parseFloat(room_dates[b]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(booked_qtyz) - parseFloat(pac_inc_room);
                                    }else{
                                        var pac_inc_room = 0;
                                         var total_room = total_room;
                                         
                                    }
                            	     var room_date = date[b];
                            	     var inc = [b];
                            	   //  console.log(room_date);
                              room_supllier_td += `<td><div style='background-color: #363b42;padding: 25px 7px;position: relative;border-radius: 6px;'><span class='badge' title='Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>${total_romm}</span> <span class='badge' title='Remaining Room' style='background-color: #a5a728;/* padding: 19px; */position: absolute;top: 0;left: 62;'>${total_room}</span><span class='badge booking_span${b}' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>${booked_qtyz}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #4caf50;/* padding: 19px; */position: absolute;right: 36'>${admin_inc_room}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #c229c5;/* padding: 19px; */position: absolute;'>${pac_inc_room}</span></div></td>`
                			    		      
                			    		     
                			    		  
                            	     
                            	 }
                            	 $('.double_append').append(room_supllier_td); 
                            	 
                            }
                            
                            
                            
                            // to make triple
                            for (var t = 0; t < result_triple.length; t++) {
                            // 	 console.log(result_single[t]);
                            	 var room_dates = result_double[t]['data'];
                            	 var room_supplier = result_double[t]['supplier_name'];
                            	 
                            	 var room_supllier_td = `<td>
    			 <div class='row' style='background-color: #363b42;border-radius: 6px;height: 3rem;'>
        			    		     
        			    		     <div class='col-6' style=''>
        			    		     <span class='badge supplier_span' title='Supplier Name' style='background-color: #2861a7;'>${room_supplier}</span>
        			    		    
        			    		     </div>
        			    <div class='col-6'>
        			    		  <div class='row'>
        			    		  
        			    		      <div class='col-12' style='padding: 20px;'>
        			    		      <span class='badge' title='RoomType' style='background-color: #4caf50;'>Triple</span>
        			    		      </div>
        			    		      
        			    		     
        			    		     
        			    		  </div>
        			    </div>
	    		 </div>
        			    		     </td>`
        			    		    
        			    		     
        			    		   //  $('.single_suplier').append(room_supllier_td);
                            	 
                            	 
                            	 for (var tr = 0; tr < room_dates.length; tr++) {
                            	   //  console.log(room_dates[tr]['total_rooms']);
                            	   var total_romm = room_dates[tr]['total_rooms'];
                            	   var booked_qty = result_triple_booked_record[tr]['booked_rooms_single'];
                            	     if (result_double_booked_record[tr]['booked_rooms_single']) {
                            	        console.log("if");
                                        var booked_qtyz = result_double_booked_record[tr]['booked_rooms_single'];
                                        var total_room =  booked_qtyz;
                                    }else{
                                        console.log("else");
                                        var booked_qtyz = 0;
                                         var total_room = 0;
                                    }
                                    if (admin_result_double_booked_record[tr]['acc_qty']) {
                                        var admin_inc_room = admin_result_single_booked_record[tr]['acc_qty'];
                                        var total_room = parseFloat(room_dates[tr]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(booked_qtyz) - parseFloat(total_room);
                                    }else{
                                        var admin_inc_room = 0;
                                         var total_room = room_dates[tr]['total_rooms'];
                                    }
                                    if (double_package_record[tr]['package_acc_type']) {
                                        var pac_inc_room = single_package_record[tr]['package_acc_qty'];
                                          var total_room = parseFloat(room_dates[tr]['total_rooms']) - parseFloat(admin_inc_room) - parseFloat(booked_qtyz) - parseFloat(pac_inc_room);
                                    }else{
                                        var pac_inc_room = 0;
                                         var total_room = total_room;
                                        
                                    }
                            	     var room_date = date[tr];
                            	     var inc = [tr];
                            	   //  console.log(room_date);
                              room_supllier_td += `<td><div style='background-color: #363b42;padding: 25px 7px;position: relative;border-radius: 6px;'><span class='badge' title='Remaining Room' style='background-color: #a5a728;/* padding: 19px; */position: absolute;top: 0;left: 62;'>${total_room}</span><span class='badge' title='Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>${total_romm}</span><span class='badge booking_span${tr}' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>${booked_qtyz}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #4caf50;/* padding: 19px; */position: absolute;right: 36'>${admin_inc_room}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #c229c5;/* padding: 19px; */position: absolute;'>${pac_inc_room}</span></div></td>`
                			    		      
                			    		     
                			    		 
                            	    
                            	 }
                            	 $('.triple_append').append(room_supllier_td); 
                            	 
                            }
                            
                            
                            
                            // to make quad
                            for (var q = 0; q < result_triple.length; q++) {
                            // 	 console.log(result_single[t]);
                            	 var room_dates = result_double[q]['data'];
                            	 var room_supplier = result_double[q]['supplier_name'];
                            	 
                            	 var room_supllier_td = `<td>
    			 <div class='row' style='background-color: #363b42;border-radius: 6px;height: 3rem;'>
        			    		     
        			    		     <div class='col-6' style=''>
        			    		     <span class='badge supplier_span' title='Supplier Name' style='background-color: #2861a7;'>${room_supplier}</span>
        			    		    
        			    		     </div>
        			    <div class='col-6'>
        			    		  <div class='row'>
        			    		  
        			    		      <div class='col-12' style='padding: 20px;'>
        			    		      <span class='badge' title='RoomType' style='background-color: #4caf50;'>Quad</span>
        			    		      </div>
        			    		      
        			    		     
        			    		     
        			    		  </div>
        			    </div>
	    		 </div>
        			    		     </td>`
        			    		    
        			    		     
        			    		  
                            	
                            	 
                            	 for (var qr = 0; qr < room_dates.length; qr++) {
                            	  
                            	   var booked_qty = result_triple_booked_record[qr]['booked_rooms_single'];
                            	    if (booked_qty) {
                                        var booked_qtyz = booked_qty;
                                    }else{
                                        var booked_qtyz = 0;
                                    }
                            	     var room_date = date[qr];
                            	     var inc = [qr];
                            	   //  console.log(room_date);
                              room_supllier_td += `<td><div style='background-color: #363b42;padding: 25px 7px;position: relative;border-radius: 6px;'><span class='badge' title='Remaining Room' style='background-color: #a5a728;/* padding: 19px; */position: absolute;top: 0;left: 62;'>r</span><span class='badge' title='Available' style='background-color: #2861a7;/* padding: 19px; */position: absolute;top: 0;left: 5;'>${room_dates[qr]['total_rooms']}</span><span class='badge booking_span' title='Sold Out' style='background-color: #f10000;/* padding: 19px; */position: absolute;right: 5;'>${booked_qtyz}</span> <span class='badge booking_span' title='Sold Out' style='background-color: #4caf50;/* padding: 19px; */position: absolute;right: 36'>a</span> <span class='badge booking_span' title='Sold Out' style='background-color: #c229c5;/* padding: 19px; */position: absolute;'>p</span></div></td>`
                			    		      
                			    		     
                			    		    
                            	    
                            	 }
                            	 $('.quad_append').append(room_supllier_td); 
                            	 
                            }
        
     
                            	
                            	
                    
                            
                            	

                            
                            	
   
                            	 $('.check_col_hide').show();
                            	$('.count_table').show();
                            	
                                    
                              }
                                });
                             }else{
Su
                                 alert("Upto Date Field is Empty.Kindly Fill It");
                             }
                        }else{
                          alert("From Date Field is Empty.Kindly Fill It");  
                        }
                     }else{
                          alert("Hotel Field is Empty.Kindly Fill It");
                     }
      function getsupplierbookingroomdetaildouble(dt,id){
    
            $.ajax({
                                     url :  '{{URL::to('getbookingofroomdouble')}}',
                                     type: 'POST',
                                    data: {_token: CSRF_TOKEN,
                                'date': dt
                                 
                                          },
                                // dataType: 'json',
                            success: function(response){
                                
                                var data =JSON.parse(response);
                            
                               if(data['provider'] == 'hotels'){
                               var inc = id;
                              
                                   var booking = JSON.parse(data['rooms_checkavailability']);
                                   var Quantity = booking[0]['rooms_quantity'];
                                
                                  
                                   $('.booking_span'+inc+'').html("");
                                   $('.booking_span'+inc+'').append(Quantity);
                               }
                               
                      
                              }
                                });
      }
      
  });

  
               });
            </script>










