@extends('template/frontend/userdashboard/layout/default')
@section('content')


@if(session()->has('message'))
<div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>{{session('message')}} </strong>
</div>


        
    @endif
   <div>



<div class="tab-content__pane" id="password">
                        <div class="">
                            <!-- BEGIN: Horizontal Bar Chart -->
                            <div class="">
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h2 class="font-medium text-base mr-auto">
                                            Markup Hotels
                                        </h2>
                                    </div>
                                    <div class="card-body">
<form class="ps-3 pe-3" action="{{URL::to('super_admin/admin_markup')}}"  method="post">
                 @csrf
       
<input class="form-control"  type="hidden" id="added_markup" name="added_markup" value="synchtravel"> 

                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Select Provider</label>
                        <select class="form-control" name="provider">
                            <option>Select Provider</option>
                            <option value="Travellanda">Travellanda</option>
                            <option value="Hotelbeds">Hotelbeds</option>
                            <option value="TBO">TBO</option>
                            <option value="Ratehawk">Ratehawk</option>
                            <option value="CustomHotel">Custom Hotel</option>
                            <option value="All">All</option>
                        </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Select Customer</label>
                        <select class="form-control" name="customer_id">
                            <option>Select Customer</option>
                            <?php
                            foreach($customer as $data)
                            {
                            ?>
                            <option value="{{$data->id}}">{{$data->name ?? ''}} {{$data->lname ?? ''}}</option>
                            <?php
                            }
                            ?>
                        </select>
                            </div>
                            
                            
                           
                        </div>
                       
                    </div>
                    
                   
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Select Markup Type</label>
                        <select class="form-control" name="markup_type">
                            <option>Select Markup Type</option>
                            <option value="Percentage">Percentage</option>
                            <option value="Fixed">Fixed</option>
                           
                        </select>
                            </div>
                            
                            
                            
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Markup</label>
                        <input class="form-control"  type="text" id="markup" name="markup_value" value=""> 
                            </div>
                           
                        </div>
                       
                    </div>
                    
                     
                    
                    
                    

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

                                   </div>
                                </div>
                            </div>
                            <!-- END: Horizontal Bar Chart -->
                        </div>

                    </div>
   
       
    </div>
    <!-- END: Content -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp').val(v);
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage_1').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp_1').val(v);
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage_2').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp_2').val(v);
                });
        });
    </script>

@endsection
