@extends('template/frontend/userdashboard/layout/default')
@section('content')

<div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: black;">
            <h5 class="modal-title" id="exampleModalLongTitle"></h5>
            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
              <div class="col-12">
                <h3 class="text-center">Total Amount</h3>
              </div>
              <table class="js-table-sections table table-hover js-table-sections-enabled">
                <thead>
                  <tr>
                    <th width="15%">Total Amount</th>
                  </tr>
                </thead>
                <tbody class="js-table-sections-header chintu-click">
                  <tr>
                    <td id="total_Amount_1"></td>
                  </tr>
                </tbody>
              </table>

            <div class="modal-footer">
              <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
      </div>
</div>

<div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: black;">
            <h5 class="modal-title" id="exampleModalLongTitle"></h5>
            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
              <div class="col-12">
                <h3 class="text-center">Recieved Amount</h3>
              </div>
              <table class="js-table-sections table table-hover js-table-sections-enabled">
                <thead>
                  <tr>
                    <th width="15%">Recieved Amount</th>
                  </tr>
                </thead>
                <tbody class="js-table-sections-header chintu-click">
                  <tr>
                    <td id="recieve_Amount_1"></td>
                  </tr>
                </tbody>
              </table>

            <div class="modal-footer">
              <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
      </div>
</div>

<div class="modal fade" id="exampleModalCenter3" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: black;">
            <h5 class="modal-title" id="exampleModalLongTitle"></h5>
            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
              <div class="col-12">
                <h3 class="text-center">Outsatnding</h3>
              </div>
              <table class="js-table-sections table table-hover js-table-sections-enabled">
                <thead>
                  <tr>
                    <th width="15%">Outsatnding</th>
                  </tr>
                </thead>
                <tbody class="js-table-sections-header chintu-click">
                  <tr>
                    <td id="outsatnding_1"></td>
                  </tr>
                </tbody>
              </table>

            <div class="modal-footer">
              <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
      </div>
</div>
 
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Expenses</h4>
        <div class="tab-content">
            <div class="tab-pane show active" id="justified-tabs-preview">
                <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                    <li class="nav-item">
                        <a href="#home1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0 active">
                            <i class="mdi mdi-home-variant d-md-none d-block"></i>
                            <span class="d-none d-md-block">Accomodation</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home2" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Flights Details</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home3" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Transportation</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home4" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Visa Details</span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane  show active" id="home1">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example2">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Hotel Name</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Room Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Package Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">No of Pax</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Quantity</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">No of Nights</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Price per Nights</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Price For All Nights</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Total</th>
                                                        <!--<th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Status</th>-->
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $acc_hotel_name = json_decode($value->accomodation_details);
                                                        // print_r($acc_hotel_name);
                                                        ?>
                                                        @if(isset($acc_hotel_name))
                                                            @foreach($acc_hotel_name as $accDetails)
                                                                <tr role="row" class="odd">
                                                                    @if(isset($currency_SymbolU))
                                                                        @foreach($currency_SymbolU as $currency_SymbolUU)
                                                                            <td>{{ $value->tour_id }}</td>
                                                                            <td>{{ $value->title }}</td>
                                                                            <td>{{ $accDetails->acc_hotel_name }}</td>
                                                                            <td>{{ $accDetails->acc_type }}</td>
                                                                            <td>{{ $value->pakage_type }}</td>
                                                                            <td>
                                                                                
                                                                                {{ $accDetails->acc_pax }}
                                                                            </td>
                                                                            <td>
                                                                                
                                                                                {{ $accDetails->acc_qty }}
                                                                            </td>
                                                                            <td>
                                                                                
                                                                                {{ $accDetails->acc_no_of_nightst }}
                                                                            </td>
                                                                            <td>
                                                                                <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                                {{ $accDetails->acc_pax * $accDetails->acc_qty}}
                                                                            </td>
                                                                            <td>
                                                                                <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                                {{ $accDetails->acc_pax * $accDetails->acc_qty * $accDetails->acc_no_of_nightst }}
                                                                            </td>
                                                                            <td>
                                                                                <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                                {{ $accDetails->acc_total_amount }}
                                                                            </td>
                                                                            <!--<td>-->
                                                                            <!--    PAID/UNPAID-->
                                                                            <!--</td>-->
                                                                            <td>
                                                                                <div class="dropdown card-widgets">
                                                                                    <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                                        <i class="dripicons-dots-3"></i>
                                                                                    </a>
                                                                                    <div class="dropdown-menu dropdown-menu-end" style="">
                                                                                        <a data-bs-toggle="modal" data-bs-target="#exampleModalCenter1"  data-id="{{ $value->tour_id }}" class="dropdown-item fetchorderdetails detail-btn1" data-uniqid="b5c7a7ced6fda207e232"><i class="mdi mdi-eye me-1"></i>Total Amount</a>
                                                                                        <a data-bs-toggle="modal" data-bs-target="#exampleModalCenter2"  data-id="{{ $value->tour_id }}" class="dropdown-item fetchorderdetails detail-btn2" data-uniqid="b5c7a7ced6fda207e232"><i class="mdi mdi-eye me-1"></i>Recieved Amount</a>
                                                                                        <a data-bs-toggle="modal" data-bs-target="#exampleModalCenter3"  data-id="{{ $value->tour_id }}" class="dropdown-item fetchorderdetails detail-btn3" data-uniqid="b5c7a7ced6fda207e232"><i class="mdi mdi-eye me-1"></i>Outstandings</a>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        @endforeach
                                                                    @endif  
                                                                </tr>
                                                            @endforeach
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home2">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Flight Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Departure</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Arrival</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Price per person</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $flight_Details = json_decode($value->flights_details); 
                                                        // print_r($value);
                                                        ?>
                                                        
                                                        @if(isset($flight_Details))
                                                            <tr role="row" class="odd">
                                                                <td>{{ $value->tour_id }}</td>
                                                                 <td>{{ $value->title }}</td>
                                                                <td>{{ $flight_Details->flight_type }}</td>
                                                                <td>{{ $flight_Details->departure_airport_code }}</td>
                                                                <td>{{ $flight_Details->arrival_airport_code }}</td>
                                                                <td><?php echo $currency_SymbolUU->currency_symbol; ?> {{ $flight_Details->flights_per_person_price }}</td>
                                                            </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home3">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example3">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Picup Location</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Drop of Location</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">No of Vehicles</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Price per Vehicle</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Price per Person</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $transportation_details = json_decode($value->transportation_details); ?>
                                                        @if(isset($transportation_details))    
                                                            <tr role="row" class="odd">
                                                                <td>{{ $value->tour_id }}</td>
                                                                <td>{{ $value->title }}</td>
                                                                <td>{{ $transportation_details->transportation_pick_up_location }}</td>
                                                                <td>{{ $transportation_details->transportation_drop_off_location }}</td>
                                                                <td>{{ $transportation_details->transportation_no_of_vehicle }}</td>
                                                                <td><?php echo $currency_SymbolUU->currency_symbol; ?> {{ $transportation_details->transportation_price_per_vehicle ?? '' }}</td>
                                                                <td><?php echo $currency_SymbolUU->currency_symbol; ?> {{ $transportation_details->transportation_price_per_person }}</td>
                                                            </tr>
                                                        @endif
                                                    @endforeach 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home4">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example4">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Visa Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Visa Fee</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <tr role="row" class="odd">
                                                            <td>{{ $value->tour_id }}</td>
                                                            <td>{{ $value->title }}</td>
                                                            <td>{{ $value->visa_type }}</td>
                                                            <td><?php echo $currency_SymbolUU->currency_symbol; ?> {{ $value->visa_fee }}</td>
                                                            <td><?php echo $currency_SymbolUU->currency_symbol; ?> {{ $value->double_grand_total_amount }}</td>
                                                        </tr>
                                                    @endforeach 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div> <!-- end preview-->
        </div> <!-- end tab-content-->
    </div> <!-- end card-body -->
</div> <!-- end card-->
 

@endsection

@section('scripts')

<script type="text/javascript">

    $('.detail-btn1').click(function() {
        const id = $(this).attr('data-id');
        $.ajax({
            url: 'view_total_Amount/'+id,
            type: 'GET',
            data: {
                "id": id
            },
            success:function(data) {
                var total_Amount            = data['total_Amount'];
                var total_Amount_Activity   = data['total_Amount_Activity'];
                var tour_activity_check     = data['tour_activity_check'];
                
                $.each(tour_activity_check, function(key, value) {
                    var tour_Type = value.pakage_type;
                    if(tour_Type == 'tour'){
                        $('#total_Amount_1').html(total_Amount);
                        console.log('Its tour');
                    }
                    else if(tour_Type == 'activity'){
                        $('#total_Amount_1').html(total_Amount_Activity);
                        console.log('Its activity');
                    }
                    else{
                        var c = $('#total_Amount_1').html('First Do Some Payment');
                        console.log(c);
                    }
                });
            }
        })
      });
      
    $('.detail-btn2').click(function() {
        const id = $(this).attr('data-id');
        $.ajax({
            url: 'view_recieve_Amount/'+id,
            type: 'GET',
            data: {
                "id": id
            },
            success:function(data) {
                var recieved_Amount             = data['recieved_Amount'];
                var recieved_Amount_Activity    = data['recieved_Amount_Activity'];
                var tour_activity_check         = data['tour_activity_check'];
                
                $.each(tour_activity_check, function(key, value) {
                    var tour_Type = value.pakage_type;
                    if(tour_Type == 'tour'){
                        $('#recieve_Amount_1').html(recieved_Amount);
                    }
                    else if(tour_Type == 'activity'){
                        $('#recieve_Amount_1').html(recieved_Amount_Activity);
                    }
                    else{
                       $('#recieve_Amount_1').html('First Do Some Payment');
                    }
                });
            }
        })
    });
      
    $('.detail-btn3').click(function() {
        const id = $(this).attr('data-id');
        $.ajax({
            url: 'view_Outstandings/'+id,
            type: 'GET',
            data: {
                "id": id
            },
            success:function(data) {
                var total_Amount            = data['total_Amount'];
                var total_Amount_Activity   = data['total_Amount_Activity'];
                var recieved_Amount             = data['recieved_Amount'];
                var recieved_Amount_Activity    = data['recieved_Amount_Activity'];
                var tour_activity_check         = data['tour_activity_check'];
                
                var outstanding_Tour         = parseFloat(total_Amount) - parseFloat(recieved_Amount);
                var outstanding_Activity     = parseFloat(total_Amount_Activity) - parseFloat(recieved_Amount_Activity);
                
                $.each(tour_activity_check, function(key, value) {
                    var tour_Type = value.pakage_type;
                    if(tour_Type == 'tour'){
                        $('#outsatnding_1').html(outstanding_Tour);
                    }
                    else if(tour_Type == 'activity'){
                        $('#outsatnding_1').html(outstanding_Activity);
                    }
                    else{
                        $('#outsatnding_1').html('First Do Some Payment');
                    }
                });
            }
        })
    });
    
</script>

@stop

@section('slug')

@stop