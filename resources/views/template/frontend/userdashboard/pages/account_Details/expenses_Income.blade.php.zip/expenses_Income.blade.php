@extends('template/frontend/userdashboard/layout/default')
@section('content')
 
<div id="signup-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Visa Type</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Visa </label>
                        <input class="form-control" type="email" id="other_visa_type" name="other_visa_type" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="hotel-name-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Hotel Name</label>
                        <input class="form-control" type="other_Hotel_Name" id="other_Hotel_Name" name="other_Hotel_Name" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_name" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="pickup-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Pickup Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Pickup Location</label>
                        <input class="form-control" type="pickup_location" id="pickup_location" name="pickup_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_PUL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="dropof-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Dropof Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Dropof Location</label>
                        <input class="form-control" type="dropof_location" id="dropof_location" name="dropof_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_DOL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="add-Categories-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Categories</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form action="https://client.synchronousdigital.com/super_admin/submit_categories" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3">
                        <label for="label" class="form-label">Title</label>
                        <input class="form-control" type="text" id="title" name="title" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input class="form-control" type="text" id="slug" name="slug" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input class="form-control" type="file" id="" name="image" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="placement" class="form-label">Placement</label>
                        <input class="form-control" type="text" id="placement" name="placement" placeholder="">
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" type="text" id="" name="description" placeholder=""></textarea>
                    </div>
                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="add-facilities-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Facilities</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form action="https://client.synchronousdigital.com/super_admin/submit_attributes" method="post" enctype="multipart/form-data">
                @csrf
                    <div class="mb-3">
                        <label for="username" class="form-label">Facilities Name</label>
                        <input class="form-control" type="title" id="title" name="title" placeholder="">
                    </div>
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Passengee Details</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="not_Select" style="display: none;" class="block-header bg-primary-dark">
                    <h3 class="block-title">Enter Passenger Names &amp; D.O.B</h3>
                </div>
                <div class="block-content row morewrap">
                    <div style="display: none;" class="adults"><h3> Add Recoard Against adults</h3><h3></h3><label id="adultsID">adults 1 Details <label></label></label><div class="col-sm-12 "><div class="row"><div class="form-group col-sm-4"><div class="form-material"><select class="form-control" id="titles0adults" name="titlesAdults[]"><option selected="" disabled=""></option><option value="MR"> Mr.</option><option value="MS"> Ms.</option><option value="MRS"> Mrs.</option><option value="MISS"> Miss</option><option value="MASTER"> Master</option></select><label for="titles0adults">Title</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0adults" name="first_nameAdults[]"><label for="addmore-name0adults">First Name</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0adults" name="last_nameAdults[]"><label for="addmore-name0adults">Last Name</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input type="date" class="form-control" id="addmore-dob0adults" name="dobAdults[]"><label for="addmore-dob0adults">Date Of Birth</label></div></div><div class="form-group col-sm-6"><div class="form-material"><label>Gender</label><span class="radio-inline radio-small"><select class="form-control" name="GenderAdults[]"><option value="M">Male</option><option value="F">Female</option></select></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-country0adults" name="countryAAdults[]"><label for="addmore-country0adults">Citizenship e.g US</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-passport0adults" name="customer_passportAdults[]"><label for="addmore-passport0adults">Passport number</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="date" id="addmore-expiry0adults" name="passport_expiryAdults[]"><label for="addmore-expiry0adults">Expiry date</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-c_country0adults" name="c_countryAdults[]"><label for="addmore-c_country0adults">Country</label></div></div></div></div><
                    </div>
                    <div class="adults_section"></div>
                    <div style="display: none;" class="childs"><h3> Add Recoard Against childs</h3><h3></h3><label id="childsID">childs 1 Details <label></label></label><div class="col-sm-12 "><div class="row"><div class="form-group col-sm-4"><div class="form-material"><select class="form-control" id="titles0childs" name="titlesChilds[]"><option selected="" disabled=""></option><option value="MR"> Mr.</option><option value="MS"> Ms.</option><option value="MRS"> Mrs.</option><option value="MISS"> Miss</option><option value="MASTER"> Master</option></select><label for="titles0childs">Title</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0childs" name="first_nameChilds[]"><label for="addmore-name0childs">First Name</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0childs" name="last_nameChilds[]"><label for="addmore-name0childs">Last Name</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input type="date" class="form-control" id="addmore-dob0childs" name="dobChilds[]"><label for="addmore-dob0childs">Date Of Birth</label></div></div><div class="form-group col-sm-6"><div class="form-material"><label>Gender</label><span class="radio-inline radio-small"><select class="form-control" name="GenderChilds[]"><option value="M">Male</option><option value="F">Female</option></select></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-country0childs" name="countryAChilds[]"><label for="addmore-country0childs">Citizenship e.g US</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-passport0childs" name="customer_passportChilds[]"><label for="addmore-passport0childs">Passport number</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="date" id="addmore-expiry0childs" name="passport_expiryChilds[]"><label for="addmore-expiry0childs">Expiry date</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-c_country0childs" name="c_countryChilds[]"><label for="addmore-c_country0childs">Country</label></div></div></div></div><
                    </div>
                    <div class="childs_section"></div>
                    <div style="display: none;" class="infant"><h3> Add Recoard Against infant</h3><h3></h3><label id="infantID">infant 1 Details <label></label></label><div class="col-sm-12 "><div class="row"><div class="form-group col-sm-4"><div class="form-material"><select class="form-control" id="titles0infant" name="titlesInfant[]"><option selected="" disabled=""></option><option value="MR"> Mr.</option><option value="MS"> Ms.</option><option value="MRS"> Mrs.</option><option value="MISS"> Miss</option><option value="MASTER"> Master</option></select><label for="titles0infant">Title</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0infant" name="first_nameInfant[]"><label for="addmore-name0infant">First Name</label></div></div><div class="form-group col-sm-4"><div class="form-material"><input class="form-control" type="text" id="addmore-name0infant" name="last_nameInfant[]"><label for="addmore-name0infant">Last Name</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input type="date" class="form-control" id="addmore-dob0infant" name="dobInfant[]"><label for="addmore-dob0infant">Date Of Birth</label></div></div><div class="form-group col-sm-6"><div class="form-material"><label>Gender</label><span class="radio-inline radio-small"><select class="form-control" name="GenderInfant[]"><option value="M">Male</option><option value="F">Female</option></select></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-country0infant" name="countryAInfant[]"><label for="addmore-country0infant">Citizenship e.g US</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-passport0infant" name="customer_passportInfant[]"><label for="addmore-passport0infant">Passport number</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="date" id="addmore-expiry0infant" name="passport_expiryInfant[]"><label for="addmore-expiry0infant">Expiry date</label></div></div><div class="form-group col-sm-6"><div class="form-material"><input class="form-control" type="text" id="addmore-c_country0infant" name="c_countryInfant[]"><label for="addmore-c_country0infant">Country</label></div></div></div></div><
                    </div>
                    <div class="infant_section"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>
                <button id="save_Changes" type="button" class="btn btn-alt-success saveclintdetais">
                    <i class="fa fa-check"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
</div>
              <!-- /.Modal -->
 
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Expenses</h4>
        <div class="tab-content">
            <div class="tab-pane show active" id="justified-tabs-preview">
                <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                    <li class="nav-item">
                        <a href="#home1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0 active">
                            <i class="mdi mdi-home-variant d-md-none d-block"></i>
                            <span class="d-none d-md-block">Accomodation</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home2" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Flights Details</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home3" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Visa Details</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#home4" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                            <span class="d-none d-md-block">Transportation</span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane  show active" id="home1">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example2">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Hotel Name</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">No of Pax</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Room Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Quantity</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $acc_hotel_name = json_decode($value->accomodation_details);
                                                        ?>
                                                        @if(isset($acc_hotel_name))
                                                            @foreach($acc_hotel_name as $accDetails)
                                                                <tr role="row" class="odd">
                                                                    <td>{{ $accDetails->acc_hotel_name }}</td>
                                                                    <td>{{ $value->id }}</td>
                                                                    <td>{{ $accDetails->acc_pax }}</td>
                                                                    <td>{{ $accDetails->acc_type }}</td>
                                                                    <td>{{ $accDetails->acc_qty }}</td>
                                                                    <td>{{ $accDetails->acc_total_amount * $accDetails->acc_qty }}</td>
                                                                </tr>
                                                            @endforeach
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home2">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Flight Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Departure</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Arrival</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Price per person</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $flight_Details = json_decode($value->flights_details); ?>
                                                        @if(isset($flight_Details))
                                                            <tr role="row" class="odd">
                                                                <td>{{ $value->id }}</td>
                                                                <td>{{ $flight_Details->flight_type }}</td>
                                                                <td>{{ $flight_Details->departure_airport_code }}</td>
                                                                <td>{{ $flight_Details->arrival_airport_code }}</td>
                                                                <td>{{ $flight_Details->flights_per_person_price }}</td>
                                                            </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home3">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example3">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Picup Location</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Drop of Location</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">No of Vehicles</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Price per Vehicle</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Price per Person</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <?php $transportation_details = json_decode($value->transportation_details); ?>
                                                        @if(isset($transportation_details))    
                                                            <tr role="row" class="odd">
                                                                <td>{{ $value->id }}</td>
                                                                <td>{{ $transportation_details->transportation_pick_up_location }}</td>
                                                                <td>{{ $transportation_details->transportation_drop_off_location }}</td>
                                                                <td>{{ $transportation_details->transportation_no_of_vehicle }}</td>
                                                                <td>{{ $transportation_details->transportation_price_per_vehicle ?? '' }}</td>
                                                                <td>{{ $transportation_details->transportation_price_per_person }}</td>
                                                            </tr>
                                                        @endif
                                                    @endforeach 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="home4">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                        <div class="col-sm-5">
                                        </div>
                                    </div>
                                        <div class="col-sm-7">
                                        <div class="text-sm-end">
                                        </div>
                                    </div>
                                        <div class="table-responsive">
                                        <div class="row">
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="example4">
                                                <thead class="table-light">
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Visa Type</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Visa Fee</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($data1 as $value)
                                                        <tr role="row" class="odd">
                                                            <td>{{ $value->id }}</td>
                                                            <td>{{ $value->visa_type }}</td>
                                                            <td>{{ $value->visa_fee }}</td>
                                                            <td>{{ $value->double_grand_total_amount }}</td>
                                                        </tr>
                                                    @endforeach 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div> <!-- end preview-->
        </div> <!-- end tab-content-->
    </div> <!-- end card-body -->
</div> <!-- end card-->
 

@endsection

@section('scripts')

<script type="text/javascript">
  
    // ON 2nd
        $('#adults').on('change',function(){
            var adults = $(this).val();
            if(adults == 1){
                $('.visa_fees_adult').css('display','');
                $('.adults_section').empty();
                $('#not_Select').css('display','none');
                $('#save_Changes').css('display','');
                // $('#main_div_to_clone').css('display','');
                $('.adults').css('display','');
            }else if(adults == 0){
                $('.visa_fees_adult').css('display','none');
                $('.adults_section').empty();
                $('#not_Select').css('display','');
                $('#save_Changes').css('display','none');
                // $('#main_div_to_clone').css('display','');
                $('.adults').css('display','none');
            }else{
                var adultsID = 1;
                $('.adults_section').empty();
                adults = adults - 1;
                for (let i = 0; i < adults; i++) {
                  $('.adults').first().clone().appendTo(".adults_section").attr('id','adultsID'+(++adultsID)).val();
                  $('.adults').css('display','');
                  $('#save_Changes').css('display','');
                  $('.visa_fees_adult').css('display','');
                }
            }
        });

        $('#childs').on('change',function(){
            var childs = $(this).val();
            if(childs == 1){
                $('.visa_fees_child').css('display','');
                $('.childs_section').empty();
                $('#not_Select').css('display','none');
                $('#save_Changes').css('display','');
                // $('#main_div_to_clone').css('display','');
                $('.childs').css('display','');
            }else if(childs == 0){
                $('.visa_fees_child').css('display','none');
                $('.childs_section').empty();
                $('#not_Select').css('display','');
                $('#save_Changes').css('display','none');
                // $('#main_div_to_clone').css('display','');
                $('.childs').css('display','none');
            }else{
                var childsID = 1;
                $('.childs_section').empty();
                childs = childs - 1;
                for (let i = 0; i < childs; i++) {
                  $('.childs').first().clone().appendTo(".childs_section").attr('id','childsID'+(++childsID)).val();
                  $('.childs').css('display','');
                  $('#save_Changes').css('display','');
                  $('.visa_fees_child').css('display','');
                }
            }
        });

        $('#infant').on('change',function(){
            var infant = $(this).val();
            if(infant == 1){
                $('.infant_section').empty();
                $('#not_Select').css('display','none');
                $('#save_Changes').css('display','');
                // $('#main_div_to_clone').css('display','');
                $('.infant').css('display','');
            }else if(infant == 0){
                $('.infant_section').empty();
                $('#not_Select').css('display','');
                $('#save_Changes').css('display','none');
                // $('#main_div_to_clone').css('display','');
                $('.infant').css('display','none');
            }else{
                var infantID = 1;
                $('.infant_section').empty();
                infant = infant - 1;
                for (let i = 0; i < infant; i++) {
                  $('.infant').first().clone().appendTo(".infant_section").attr('id','infantID'+(++infantID)).val();
                  $('.infant').css('display','');
                  $('#save_Changes').css('display','');
                }
            }
        });
      // End 2nd
  
    $(document).on('click','#accomodation',function(){
        $.ajax({    
            type: "GET",
            url: "super_admin/get_other_Hotel_Name",             
            dataType: "html",                  
            success: function(data){ 
                var data1 = JSON.parse(data);
                var data2 = JSON.parse(data1['hotel_Name']);
            	$(".other_Hotel_Name").empty();
                $.each(data2['hotel_Name'], function(key, value) {
                    $(".other_Hotel_Name").append('<option attr=' +value.other_Hotel_Name+ ' value=' +value.other_Hotel_Name+ '>' +value.other_Hotel_Name+'</option>');
                });  
            }
        });
    });

    $('#submitForm_hotel_name').on('click',function(e){
        e.preventDefault();
        let other_Hotel_Name = $('#other_Hotel_Name').val();
        $.ajax({
            url: "super_admin/submit_other_Hotel_Name",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_Hotel_Name:other_Hotel_Name,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['hotel_Name_get'];
                    $(".other_Hotel_Name").empty();
                    $.each(data, function(key, value) {
                        $(".other_Hotel_Name").append('<option attr=' +value.other_Hotel_Name+ ' value=' +value.other_Hotel_Name+ '>' +value.other_Hotel_Name+'</option>');
                    });
                    alert('Other Hotel Name Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });

    $(document).on('click','#visa_inc',function(){
        $.ajax({    
            type: "GET",
            url: "super_admin/get_other_visa_type",             
            dataType: "html",                  
            success: function(data){  
                
                var data1 = JSON.parse(data);
                console.log(data1);
                var data2= JSON.parse(data1['visa_type']);
                //   console.log(data2['visa_type']);
                // jQuery.each(data2, function(key, value){  
                //     $(".other_type").append('<option value=' +value.id+ '>' + value.other_visa_type+ '</option>');
                //   });
            	$("#visa_type").empty();
           
                $.each(data2['visa_type'], function(key, value) {
                    $("#visa_type").append('<option attr=' +value.other_visa_type+ ' value=' +value.id+ '>' +value.other_visa_type+'</option>');
                });  
            }
        });
    });
    
    $(document).on('click','#transportation',function(){
        $.ajax({    
            type: "GET",
            url: "super_admin/get_pickup_dropof_location",             
            dataType: "html",                  
            success: function(data){
                var data1 = JSON.parse(data);
                var data2 = data1['pickup_location_get'];
                var data3 = data1['dropof_location_get'];
            	$(".pickup_location").empty();
                $(".dropof_location").empty();
                $.each(data2, function(key, value) {
                    $(".pickup_location").append('<option attr=' +value.pickup_location+ ' value=' +value.pickup_location+ '>' +value.pickup_location+'</option>');
                });
                $.each(data3, function(key, value) {
                    $(".dropof_location").append('<option attr=' +value.dropof_location+ ' value=' +value.dropof_location+ '>' +value.dropof_location+'</option>');
                });
            }
        });
    });

    $('#submitForm_PUL').on('click',function(e){
        e.preventDefault();
        let pickup_location = $('#pickup_location').val();
        $.ajax({
            url: "super_admin/submit_pickup_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                pickup_location:pickup_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['pickup_location_get'];
                    $(".pickup_location").empty();
                    $.each(data, function(key, value) {
                        $(".pickup_location").append('<option attr=' +value.pickup_location+ ' value=' +value.pickup_location+ '>' +value.pickup_location+'</option>');
                    });
                    alert('Other Hotel Name Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm_DOL').on('click',function(e){
        e.preventDefault();
        let dropof_location = $('#dropof_location').val();
        $.ajax({
            url: "super_admin/submit_dropof_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                dropof_location:dropof_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['dropof_location_get'];
                    $(".dropof_location").empty();
                    $.each(data, function(key, value) {
                        $(".dropof_location").append('<option attr=' +value.dropof_location+ ' value=' +value.dropof_location+ '>' +value.dropof_location+'</option>');
                    });
                    alert('Other Hotel Name Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    // $('#submitForm_Categories').on('click',function(e){
    //     e.preventDefault();
    //     let dropof_location = $('#dropof_location').val();
    //     $.ajax({
    //         url: "submit_categories",
    //         type:"POST",
    //         data:{
    //             "_token": "{{ csrf_token() }}",
    //             dropof_location:dropof_location,
    //         },
    //         success:function(response){
    //             if(response){
    //                 var data1 = JSON.parse(response)
    //                 var data = data1['dropof_location_get'];
    //                 $(".dropof_location").empty();
    //                 $.each(data, function(key, value) {
    //                     $(".dropof_location").append('<option attr=' +value.dropof_location+ ' value=' +value.dropof_location+ '>' +value.dropof_location+'</option>');
    //                 });
    //                 alert('Other Hotel Name Added SuccessFUl!');
    //             }
    //             $('#success-message').text(response.success);
    //         },
    //     });
    // });
    
    $('#submitForm').on('click',function(e){
        e.preventDefault();
        let other_visa_type = $('#other_visa_type').val();
        $.ajax({
            url: "super_admin/submit_other_visa_type",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_visa_type:other_visa_type,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['visa_type_get'];
                    console.log(data);
                    $("#visa_type").empty();
                    $.each(data, function(key, value) {
                        $("#visa_type").append('<option attr=' +value.other_visa_type+ ' value=' +value.id+ '>' +value.other_visa_type+'</option>');
                    });
                    alert('Visa Other Type Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
</script>

@stop

@section('slug')

@stop