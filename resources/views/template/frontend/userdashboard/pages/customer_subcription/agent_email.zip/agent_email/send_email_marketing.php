<?php
    print_r($data['body']);
?>