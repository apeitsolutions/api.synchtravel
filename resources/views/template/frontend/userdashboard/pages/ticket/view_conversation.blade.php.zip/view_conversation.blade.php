
@extends('template/frontend/userdashboard/layout/default')
@section('content')
@if(session()->has('message'))
        <div x-data="{ show: true }" x-show="show"
             class="flex justify-between items-center bg-yellow-200 relative text-yellow-600 py-3 px-3 rounded-lg">
            <div>
                <span class="font-semibold text-yellow-700"> {{session()->get('message')}}</span>
            </div>
            <div>
                <button type="button" @click="show = false" class=" text-yellow-700">
                    <span class="text-2xl">&times;</span>
                </button>
            </div>
        </div>
    @endif
<div class="row mt-5 mb-5">
                            <!-- start chat users-->
                            <div class="col-xxl-3 col-xl-6 order-xl-1">
                               <div class="card">
                                    <div class="card-body">
                                        

                                        <div class="mt-3 text-center">
                                            <img src="{{asset('public/admin_package/assets/images/users/avatar-5.jpg')}}" alt="shreyu" class="img-thumbnail avatar-lg rounded-circle">
                                            <h4>{{$client->company_name ?? ''}}</h4>
                                            <!--<button class="btn btn-primary btn-sm mt-1"><i class="uil uil-envelope-add me-1"></i>Send Email</button>-->
                                            <p class="text-muted mt-2 font-14">Last Interacted: <strong>Few hours back</strong></p>
                                        </div>

                                       
                                    </div> <!-- end card-body -->
                                </div>
                            </div>
                            <!-- end chat users-->
                            <!-- chat area -->
                            <div class="col-xxl-6 col-xl-12 order-xl-2">
                                <div class="card">
                                    <div class="card-body px-0 pb-0">
                                        <ul class="conversation-list px-3" data-simplebar="init" style="max-height: 538px">
                                            <div class="simplebar-wrapper" style="margin: 0px -24px;">
                                            <div class="simplebar-height-auto-observer-wrapper">
                                            <div class="simplebar-height-auto-observer">
                                                
                                            </div>
                                            </div>
                                            <div class="simplebar-mask">
                                                <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                                <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden scroll;">
                                                <div class="simplebar-content" style="padding: 0px 24px;">
                                            <div id="demo"></div>
                                            <?php
                                            foreach($conversation as $conversationData)
                                            {
                                                if($conversationData->message_sent == 'client')
                                                {
                                                    
                                                
                                            ?>        
                                            <li class="clearfix">
                                                <div class="chat-avatar">
                                                    <img src="{{asset('public/admin_package/assets/images/users/avatar-5.jpg')}}" class="rounded" alt="Shreyu N">
                                                    <i>
                                                        <?php
                                                        
                                                        $dateString = $conversationData->created_at;

                                                        // Create a DateTime object
                                                        $dateTime = new DateTime($dateString);
                                                        
                                                        // Format and echo the time
                                                        $time = $dateTime->format('H:i');
                                                        echo $time;
                                                        ?>
                                                    </i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>{{$client->company_name ?? ''}}</i>
                                                        <p>
                                                            {{$conversationData->message}}
                                                        </p>
                                                    </div>
                                                </div>
                                               
                                            </li>
                                           
                                            <?php
                                                }
                                             if($conversationData->message_sent == 'Admin')
                                                {
                                                    
                                                
                                            ?> 
                                            <li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="{{asset('public/admin_package/assets/images/users/avatar-1.jpg')}}" class="rounded" alt="dominic">
                                                    <i>
                                                    <?php
                                                        
                                                        $dateString = $conversationData->created_at;

                                                        // Create a DateTime object
                                                        $dateTime = new DateTime($dateString);
                                                        
                                                        // Format and echo the time
                                                        $time = $dateTime->format('H:i');
                                                        echo $time;
                                                        ?>
                                                        </i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Me</i>
                                                        <p>
                                                           {{$conversationData->message}}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="conversation-actions dropdown">
                                                    <button class="btn btn-sm btn-link" data-bs-toggle="dropdown" aria-expanded="false"><i class="uil uil-ellipsis-v"></i></button>

                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#">Copy Message</a>
                                                        <a class="dropdown-item" href="#">Edit</a>
                                                        <a class="dropdown-item" href="#">Delete</a>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php
                                               
                                            
                                                }
                                            }
                                            ?>
                                           
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        <div class="simplebar-placeholder" style="width: auto; height: 872px;">
                                            
                                        </div>
                                        </div>
                                        <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                            <div class="simplebar-scrollbar" style="width: 0px; display: none;">
                                                
                                            </div>
                                            </div>
                                            <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
                                                <div class="simplebar-scrollbar" style="height: 331px; transform: translate3d(0px, 0px, 0px); display: block;">
                                                    
                                                </div>
                                                </div>
                                                </ul>

                                        <div class="row px-3 pb-3">
                                            <div class="col">
                                                <div class="mt-2 bg-light p-3 rounded">
                                                    <?php if(isset($ticket->status)){if($ticket->status != 'Resoloved'){?>
                                                    <form class="needs-validation" action="{{ URL::to('super_admin/conversation/submit',[$ticket->id]) }}" id="formId">
                                                       @csrf
                                                        <div class="row">
                                                            <div class="col mb-2 mb-sm-0">
                                                                <input type="text"   name="message_type" class="form-control border-0" placeholder="Enter your text">
                                                                <div class="invalid-feedback">
                                                                    Please enter your messsage
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-sm-auto">
                                                                <div class="btn-group">
                                                                    <a href="#" class="btn btn-light"><i class="uil uil-paperclip"></i></a>
                                                                    <a href="#" class="btn btn-light"> <i class="uil uil-smile"></i> </a>
                                                                    <div class="d-grid">
                                                                        <button type="button" id="OnSubmitForm" class="btn btn-success chat-send"><i class="uil uil-message"></i></button>
                                                                    </div>
                                                                </div>
                                                            </div> <!-- end col -->
                                                            
                                                        </div> <!-- end row-->
                                                    </form>
                                                    <?php
                                                            }
                                                     
                                                            }
                                                            ?>
                                                </div> 
                                            </div> <!-- end col-->
                                        </div>
                                        <!-- end row -->
                                    </div> <!-- end card-body -->
                                </div> <!-- end card -->
                            </div>
                            <!-- end chat area-->

                            <!-- start user detail -->
                            <div class="col-xxl-3 col-xl-6 order-xl-1 order-xxl-2">
                                <div class="card">
                                    <div class="card-body">
                                        
                                        <form action="{{URL::to('super_admin/updated_status_ticket',[$ticket->id])}}" method="post">
                                            @csrf
                                            <div class="row">
                                                <div class="col-md-10">
                                                <label for="emailaddress" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                    <option <?php if(isset($ticket->status)){if($ticket->status == 'Pending') {echo 'selected';}} ?> value="Pending">Pending</option>
                                                    <option <?php if(isset($ticket->status)){if($ticket->status == 'In-Process') {echo 'selected';}} ?> value="In-Process">In-Process</option>
                                                    <option <?php if(isset($ticket->status)){if($ticket->status == 'Resoloved') {echo 'selected';}} ?> value="Resoloved">Resoloved</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-2 mt-3">
                                                    <?php if(isset($ticket->status)){if($ticket->status != 'Resoloved'){?>
                                                     <button name="submit" class="btn btn-primary mt-1" type="submit">submit</button>
                                                     <?php
                                                     }
                                                     else
                                                     {
                                                     ?>
                                                     <button class="btn mt-1" style="background-color:#727cf559;" type="button">submit</button>
                                                     <?php
                                                     }
                                                     }
                                                     ?>
                                                </div>
                                            </div>
                                        </form>
                                        

                                        <div class="mt-3">
                                            

                                            <p class="mt-4 mb-1"><strong><i class="uil uil-at"></i> Email:</strong> {{$client->email ?? ''}}</p>
                                           

                                            <p class="mt-3 mb-1"><strong><i class="uil uil-phone"></i> Phone Number:</strong>{{$client->phone ?? ''}}</p>
                                            

                                            <!--<p class="mt-3 mb-1"><strong><i class="uil uil-location"></i> Location:</strong>{{$client->email ?? ''}}</p>-->
                                           

                                            
                                            

                                            
                                            
                                        </div>
                                    </div> <!-- end card-body -->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                            <!-- end user detail -->
                        </div>
    
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
 <script>
    
    
    function allConversationGet(){
      $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                                }
                            });
                            let text = "";
                            var ticket_id='<?php echo $result->ticket->id;  ?>';
                             var customer_name='<?php echo $result->ticket->company_name;  ?>';
                            $.ajax({
                                url: "{{ url('super_admin/view_all_conversation') }}",
                                method: 'get',
                                data: {
                                    "ticket_id": ticket_id,
                                    "customer_name": customer_name,
                                },
                                success: function(result){ 
                                     console.log(result);
                                     result.forEach(myConversation);
                                     document.getElementById("demo").innerHTML = text;
                                     function myConversation(item, index) {
                                    //   text += index + ": " + item.message + "<br>";
                                     
                                      if(item.message_sent == 'client'){
                                           var dateString = item.created_at;
                                                var dateTime = new Date(dateString);
                                                
                                                var hours = dateTime.getHours();
                                                var minutes = dateTime.getMinutes();
                                                var seconds = dateTime.getSeconds();
                                                var getTime=hours+ ':'+ minutes;
                                                console.log("Time: " + hours + ":" + minutes + ":" + seconds);
                                          
                                          
                                         text += `<li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="{{asset('public/admin_package/assets/images/users/avatar-1.jpg')}}" class="rounded" alt="dominic">
                                                    <i>
                                                    
                                                        ${getTime}
                                                        </i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Me</i>
                                                        <p>
                                                           ${item.message}
                                                        </p>
                                                    </div>
                                                </div>
                                               
                                            </li>`;
                                      }
                                      if(item.message_sent == 'Admin'){
                                           var dateString = item.created_at;
                                                var dateTime = new Date(dateString);
                                                
                                                var hours = dateTime.getHours();
                                                var minutes = dateTime.getMinutes();
                                                var seconds = dateTime.getSeconds();
                                                var getTime=hours+ ':' + minutes;
                                                console.log("Time: " + hours + ":" + minutes + ":" + seconds);
                                           text +=`<li class="clearfix">
                                                <div class="chat-avatar">
                                                    <img src="{{asset('public/admin_package/assets/images/users/avatar-5.jpg')}}" class="rounded" alt="Shreyu N">
                                                    <i>
                                                      ${getTime}  
                                                    </i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Synchtravel</i>
                                                        <p>
                                                           ${item.message}
                                                        </p>
                                                    </div>
                                                </div>
                                               
                                            </li>`;
                                      }
                                      
                                    }
                                },
                                error:function(error){
                                    console.log(error);
                                }
                            });  
    }
      $(document).ready(function () {

    allConversationGet();

});  
</script>
<script>
$(document).ready(function () {
$("#OnSubmitForm").click(function(ev) {

    GetDataFun();
});
});                
    function GetDataFun(){
        
               
                    var form    = $("#formId");
                    var url     = form.attr('action');
                    $.ajax({
                        type    : "post",
                        url     : url,
                        data    : form.serialize(),
                        success : function(data) {
                           console.log(data);  
              
                        },
                        error   : function(data) {
                            alert("some Error");
                        }
                    });   
    }
</script> 
@endsection