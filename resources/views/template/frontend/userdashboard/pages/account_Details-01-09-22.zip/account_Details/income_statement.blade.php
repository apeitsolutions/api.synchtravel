@extends('template/frontend/userdashboard/layout/default')
@section('content')

<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Tours</a></li>
                                <li class="breadcrumb-item active">Income Statement</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Income Statement</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="text-sm-end">
                                </div>
                            </div>
                            <div class="table-responsive">
                                <div class="row">
                                    <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                        <thead class="table-light">
                                            <tr role="row">
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Booking ID</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Total</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Recieved</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Outstandings</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Expense</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Profit</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($data as $value)
                                                <?php $markup_details = json_decode($value->markup_details); ?>
                                                @if(isset($markup_details))    
                                                    @foreach($markup_details as $value1)
                                                    <tr role="row" class="odd">
                                                        @if(isset($currency_SymbolU))
                                                            @foreach($currency_SymbolU as $currency_SymbolUU)    
                                                                <td>
                                                                    {{ $value->id }}
                                                                </td>
                                                                <td>
                                                                    {{ $value->generate_id }}
                                                                </td>
                                                                <td>
                                                                    {{ $value->title }}
                                                                </td>
                                                                <td>
                                                                    <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                    {{ $value->total_amount }}
                                                                </td>
                                                                <td>
                                                                    <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                    {{ $value->recieved_amount }}
                                                                </td>
                                                                <td>
                                                                    <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                    {{ $value->remaining_amount }}
                                                                </td>
                                                                <td>
                                                                    <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                    {{ $value->total_amount - $value1->markup_price  }}
                                                                </td>
                                                                <td>
                                                                    <?php echo $currency_SymbolUU->currency_symbol; ?>
                                                                    {{ $value1->markup_price }}
                                                                </td>
                                                                <td>
                                                                    <div class="dropdown card-widgets">
                                                                        <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                            <i class="dripicons-dots-3"></i>
                                                                        </a>
                                                                        <div class="dropdown-menu dropdown-menu-end" style="">
                                                                            <!-- item-->
                                                                            <a href="{{ URL::to('super_admin/view_income_Voucher')}}/{{$value->id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Voucher</a>
                                                                            <!-- item-->
                                                                            <a href="{{ URL::to('super_admin/view_income_Invoice')}}/{{$value->id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>Invoice</a>
                                                                            <!-- item-->
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            @endforeach
                                                        @endif
                                                    </tr>
                                                    @endforeach
                                                @endif
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>         
    </section>
</div>


<!--<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">-->
<!--      <div class="modal-dialog modal-dialog-centered" role="document">-->
<!--        <div class="modal-content">-->
<!--          <div class="modal-header" style="background-color: black;">-->
<!--            <h5 class="modal-title" id="exampleModalLongTitle"></h5>-->
<!--            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">-->
<!--              <span aria-hidden="true">&times;</span>-->
<!--            </button>-->
<!--          </div>-->
<!--            <div class="modal-body">-->
              <!-- SELECT2 EXAMPLE -->

<!--              <div class="col-sm-12">-->
<!--                <h4 class="text-center">Flight Details</h4>-->
<!--                <h6 class="text-left">Flight Return Type :One Way</h6>-->
<!--              </div>-->
<!--              <table class="js-table-sections table table-hover js-table-sections-enabled">-->
<!--                <thead>-->
<!--                  <tr>-->
<!--                    <th width="15%">Airline</th>-->
<!--                    <th width="25%">Departure</th>-->
<!--                    <th width="25%">Arrival</th>-->
<!--                  </tr>-->
<!--                </thead>-->
<!--                <tbody class="js-table-sections-header chintu-click">-->
<!--                  <tr>-->
<!--                    <td class="text-center" id="airline_name"></td>-->
<!--                    <td>-->
<!--                      <div class="booking-item-departure">-->
<!--                        <h5><i class="fa fa-plane" id="deprturetime"></i></h5>-->
<!--                        <p class="booking-item-date" id="deprturedate">2022-05-11</p>-->
<!--                        <p class="booking-item-destination" id="departure">JED </p>-->
<!--                      </div>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                      <div class="booking-item-departure">-->
<!--                        <h5><i class="fa fa-plane" id="ArrivalTime"></i></h5>-->
<!--                        <p class="booking-item-date" id="ArrivalDate"></p>-->
<!--                        <p class="booking-item-destination" id="arrival">JED </p>-->
<!--                      </div>-->
<!--                    </td>-->
<!--                  </tr>-->
<!--                  <tr>-->
<!--                    <td>Flight Type</td>-->
<!--                    <td></td>-->
<!--                    <td id="flighttype"><p><strong></strong></p></td>-->
<!--                  </tr>-->
<!--                  <tr>-->
<!--                    <td>Total Price</td>-->
<!--                    <td></td>-->
<!--                    <td id="flight_price"><p><strong></strong></p></td>-->
<!--                  </tr>-->
<!--                </tbody>-->
<!--              </table>-->
              
<!--              <div class="hotel-booking-top">-->
<!--                  <h3 class="text-center">Hotel Booking Details</h3>-->
<!--                <div class="hotel-list-wrap ">-->
<!--                  <div class="col-sm-12"><h4>Makkah Hotel</h4></div>-->
<!--                    <table class="js-table-sections table table-hover js-table-sections-enabled">-->
<!--                      <thead>-->
<!--                        <tr>-->
<!--                          <th width="15%">Date In</th>-->
<!--                          <th width="15%">Date Out</th>-->
<!--                          <th width="25%">Hotel Name</th>-->
<!--                          <th width="10%">No of Rooms</th>-->
<!--                          <th width="15%">Price Per Night</th>-->
<!--                          <th width="15%">Total</th>-->
<!--                        </tr>-->
<!--                      </thead>-->
<!--                          <tbody class="js-table-sections-header chintu-click">-->
<!--                        <tr>-->
<!--                          <td class="text-center" id="dateinmakkah"></td>-->
<!--                          <td class="font-w600" id="dateoutmakkah"></td>-->
<!--                          <td class="font-w600" id="hotel_name_makkah"></td>-->
<!--                          <td class="font-w600" id="no_of_rooms_makkah"></td>-->
<!--                          <td class="font-w600" id="Price_Per_Nights_Makkah"></td>-->
<!--                          <td class="font-w600" id="Makkah_total_price_cal"></td>-->
                        
<!--                        </tr>-->
<!--                      </tbody>   -->
<!--                    </table>                       -->
<!--                  </div>-->
                  <!-- end of hotel-list-wrap -->
<!--                  <div class="hotel-list-wrap ">-->
<!--                    <div class="col-sm-12">-->
<!--                       <h4>Madina Hotel</h4>-->
<!--                    </div>-->
                   
<!--                    <table class="js-table-sections table table-hover js-table-sections-enabled">-->
<!--                      <thead>-->
<!--                        <tr>-->
<!--                          <th width="15%">Date In</th>-->
<!--                          <th width="15%">Date Out</th>-->
<!--                          <th width="25%">Hotel Name</th>-->
<!--                          <th width="10%">No of Rooms</th>-->
<!--                          <th width="15%">Price Per Night</th>-->
<!--                          <th width="15%">Total</th>-->
<!--                        </tr>-->
<!--                      </thead>-->
<!--                      <tbody class="js-table-sections-header chintu-click">-->
<!--                        <tr>-->
<!--                          <td class="text-center" id="dateinmadinah"></td>-->
<!--                          <td class="font-w600" id="dateoutmadinah"></td>-->
<!--                          <td class="font-w600" id="hotel_name_madina"> </td>-->
<!--                          <td class="font-w600" id="no_of_rooms_madina"></td>-->
<!--                          <td class="font-w600" id="price_per_night_madinah"></td>-->
<!--                          <td class="font-w600" id="madinah_total_price_cal"></td>-->
                        
<!--                        </tr>-->
<!--                      </tbody>   -->
<!--                    </table>-->
<!--                  </div>-->
                  <!-- end of hotel-list-wrap -->
<!--                </div>-->
<!--              </div>-->

<!--              <div class="col-12">-->
<!--                <h3 class="text-center">Transfer Details</h3>-->
<!--              </div>-->
<!--              <table class="js-table-sections table table-hover js-table-sections-enabled">-->
<!--                <thead>-->
<!--                  <tr>-->
<!--                    <th width="15%">Vehcle</th>-->
<!--                    <th width="15%">Pessengers</th>-->
<!--                    <th width="15%">Pickup</th>-->
<!--                    <th width="15%">Dropoff </th>-->
<!--                    <th width="15%">Fare</th>-->
<!--                  </tr>-->
<!--                </thead>-->
<!--                <tbody class="js-table-sections-header chintu-click">-->
<!--                  <tr>-->
<!--                    <td id="transfer_vehicle"></td>-->
<!--                    <td id="passenger"></td>-->
<!--                    <td id="pickuplocat"></td>-->
<!--                    <td id="dropoflocat"></td>-->
<!--                    <td id="transf_price"></td>-->
<!--                  </tr>-->
<!--                </tbody>-->
<!--              </table>-->

<!--              <div class="col-12">-->
<!--                <h3 class="text-center">Visa Detail</h3>-->
<!--              </div>-->
<!--              <table class="js-table-sections table table-hover js-table-sections-enabled">-->
<!--                <thead>-->
<!--                  <tr>-->
<!--                    <th width="50%">Adult Visa Fee</th>-->
<!--                    <th width="50%">Child Visa Fee</th>-->
<!--                    <th width="50%">Total</th>-->
<!--                  </tr>-->
<!--                </thead>-->
<!--                <tbody class="js-table-sections-header chintu-click">-->
<!--                  <tr>-->
<!--                    <td id="visa_fees_adult"></td>-->
<!--                    <td id="visa_fees_child"></td>-->
<!--                    <td id="visa_fees_price"></td>-->
<!--                  </tr>-->
<!--                </tbody>-->
<!--              </table>-->

<!--              <div class="row">-->
<!--                <div class="offset-md-7 col-md-5">-->
<!--                  Flight Total:<h5 id="flight_price_total"></h5>-->
<!--                  Makkah Hotel Total:<h5 id="Makkah_total_price_cal"></h5>-->
<!--                  Madinah Hotel Totall:<h5 id="madinah_total_price_cal"></h5>-->
<!--                  Transfer Total:<h5 id="transfers_head_total"></h5>-->
<!--                  Visa Fee :<h5 id="visa_fees"></h5>-->
<!--                  <hr>-->
<!--                  Grand Total :<h4 id="grand_total_price"></h4>-->
<!--                </div>-->
<!--              </div>-->

<!--            <div class="modal-footer">-->
<!--              <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>-->
<!--            </div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->



  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
    
    $(document).ready(function () {
      
      //View Modal Single Quotation
    //   $('.detail-btn').click(function() {
    //     const id = $(this).attr('data-id');
    //     $.ajax({
    //       url: 'view_QuotationsID/'+id,
    //       type: 'GET',
    //       data: {
    //         "id": id
    //       },
    //       success:function(data) {
    //         var a                = data['a'];
    //         var roundTripDetails = a['roundTripDetails'];
    //         var oneWayDetails    = a['oneWayDetails'];

    //         console.log(a);

    //         //Flight Details
    //         $('#airline_name').html(oneWayDetails['airline_name']);
    //         $('#deprturetime').html(oneWayDetails['deprturetime']);
    //         $('#ArrivalTime').html(oneWayDetails['ArrivalTime']);
    //         $('#deprturedate').html(oneWayDetails['deprturedate']);
    //         $('#ArrivalDate').html(oneWayDetails['ArrivalDate']);
    //         $('#departure').html(oneWayDetails['departure']);
    //         $('#arrival').html(oneWayDetails['arrival']);

    //         $('#flighttype').html(a['flighttype']);
    //         $('#flight_price').html(a['flight_price']);

    //         //Hotel Booking Details Makkkah
    //         $('#dateinmakkah').html(a['dateinmakkah']);
    //         $('#dateoutmakkah').html(a['dateoutmakkah']);
    //         $('#hotel_name_makkah').html(a['hotel_name_makkah']);
    //         $('#no_of_rooms_makkah').html(a['no_of_rooms_makkah']);
    //         $('#Price_Per_Nights_Makkah').html(a['Price_Per_Nights_Makkah']);
    //         $('#Makkah_total_price_cal').html(a['Makkah_total_price_cal']);

    //         //Hotel Booking Details Madinah
    //         $('#dateinmadinah').html(a['dateinmadinah']);
    //         $('#dateoutmadinah').html(a['dateoutmadinah']);
    //         $('#hotel_name_madina').html(a['hotel_name_madina']);
    //         $('#no_of_rooms_madina').html(a['no_of_rooms_madina']);
    //         $('#price_per_night_madinah').html(a['price_per_night_madinah']);
    //         $('#madinah_total_price_cal').html(a['madinah_total_price_cal']);


    //         //Transfer Details
    //         $('#transfer_vehicle').html(a['transfer_vehicle']);
    //         $('#passenger').html(a['passenger']);
    //         $('#pickuplocat').html(a['pickuplocat']);
    //         $('#dropoflocat').html(a['dropoflocat']);
    //         $('#trans_date').html(a['trans_date']);
    //         $('#transf_price').html(a['transf_price']);

    //         //Visa Details
    //         $('#visa_fees_adult').html(a['visa_fees_adult']);
    //         $('#visa_fees_child').html(a['visa_fees_child']);
    //         $('#visa_fees_price').html(a['visa_fees_price']);

    //         //Totals
    //         $('#flight_price_total').html(a['flight_price']);
    //         $('#Makkah_total_price_cal').html(a['Makkah_total_price_cal']);
    //         $('#madinah_total_price_cal').html(a['madinah_total_price_cal']);
    //         $('#transfers_head_total').html(a['transfers_head_total']);
    //         $('#visa_fees').html(a['visa_fees_price']);
    //         $('#grand_total_price').html(a['grand_total_price']);
            
    //       }
    //     })
    //   });

      // // Confirm Quotation
      // $('#confirm_Quotation').click(function() {
      //     pagingType: 'full_numbers',
      // });

    });

  </script>

@endsection
