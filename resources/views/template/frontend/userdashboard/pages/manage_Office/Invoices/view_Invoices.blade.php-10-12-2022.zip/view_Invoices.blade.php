
<?php

//print_r($data);die();

?>

@extends('template/frontend/userdashboard/layout/default')
@section('content')

    <?php $currency=Session::get('currency_symbol'); //dd($all_countries); ?>
    
    <style>
        .nav-link{
          color: #575757;
          font-size: 18px;
        }
    </style>

    <div class="content-wrapper">
        
        <section class="content" style="padding: 10px 20px 0px 20px">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-primary" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <!-- <i class="mdi mdi-eye me-1"></i> -->
                    <span class="iconify" data-icon="uil:plane-departure" data-width="70"></span>
                  </div>
                  <div class="inner">
                    
                    <p>Total Flights</p>
    
                    <h3>150</h3>
    
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-home-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3>53<sup style="font-size: 15px">%</sup></h3>
    
                    <p>Total Hotels</p>
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-pricetag-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3>44</h3>
    
                    <p>Total Transfer</p>
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-dollar-sign-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3>65</h3>
    
                    <p>Commision</p>
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
            </div>
          </div>
        </section>
        
        <section class="content" style="padding: 30px 50px 0px 50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-12 col-6">
                <nav class="breadcrumb push">
                    <a class="breadcrumb-item" href="#">Dashboard</a> 
                    <span class="breadcrumb-item active">View Agent Invoices</span>
                </nav>
              </div>
            </div>
          </div>
        </section>
    
        <section class="content" style="padding: 30px 50px 0px 50px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-6">
                        <div class="panel-body padding-bottom-none">
                            <div class="block-content block-content-full">
                                <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table style="" class="table table-bordered table-striped table-vcenter dataTable no-footer" id="myTable" role="grid" aria-describedby="example_info">
                                                
                                                <thead>
                                                    <tr role="row">
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;text-align:center;">SR No.</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;text-align:center;">Invoice Id</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;text-align:center;">Invoice Agent</th>
                                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;text-align:center;">Lead Name</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;text-align:center;">Prepared By</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;text-align:center;">Total Payable</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;text-align:center;">Date</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Validity: activate to sort column ascending" style="width: 143.438px;text-align:center;">Outstandings</th>
                                                        <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Options: activate to sort column ascending" style="width: 175.642px;text-align:center;">Options</th>
                                                    </tr>
                                                </thead>
                                                
                                                <tbody style="text-align: center;">
                                                    <?php $i = 1; ?>
                                                    @foreach ($data as $value)
                                                        <?php
                                                            // dd($value->no_of_pax_days);
                                                            // dd($value->count_P_Input);
                                                            $date4days = date('Y-m-d',strtotime($value->created_at. ' + 5 days'));
                                                            $currdate = date('Y-m-d');
                                                        ?>
                                                        <tr role="row" class="odd">
                                                            <td class="sorting_1">{{ $i }} </td>
                                                            <td class="sorting_1">{{ $value->id }} </td>
                                                            <td class="sorting_1">{{ $value->agent_Name }} </td>
                                                            <td class="sorting_1">{{ $value->f_name }} {{ $value->middle_name }}</td>
                                                            <td>{{ $value->tour_author }}</td>
                                                            
                                                            <?php
                                                                $accomodation_detailsE          = $value->accomodation_details;
                                                                $accomodation_details_moreE     = $value->accomodation_details_more;
                                                                $no_of_pax_days                 = $value->no_of_pax_days;
                                                                $visa_Pax                       = $value->visa_Pax;
                                                                $acc_total_amount               = 0;
                                                                $markup_detailsE                = $value->markup_details;
                                                                $more_visa_detailsE             = $value->more_visa_details;
                                                                
                                                                if(isset($accomodation_detailsE) && $accomodation_detailsE != null && $accomodation_detailsE != ''){
                                                                    $accomodation_details = Json_decode($accomodation_detailsE);
                                                                    foreach($accomodation_details as $accomodation_details1){
                                                                        if(isset($accomodation_details1->hotel_invoice_markup) && $accomodation_details1->hotel_invoice_markup != null && $accomodation_details1->hotel_invoice_markup != ''){
                                                                            $hotel_invoice_markup = $accomodation_details1->hotel_invoice_markup;
                                                                        }else{
                                                                            $hotel_invoice_markup = 0;
                                                                        }
                                                                        if(isset($accomodation_details1->acc_qty) && $accomodation_details1->acc_qty != null && $accomodation_details1->acc_qty != ''){
                                                                            $acc_qty = $accomodation_details1->acc_qty;
                                                                        }else{
                                                                            $acc_qty = 0;
                                                                        }
                                                                        $acc_total_amount = $acc_total_amount + ($hotel_invoice_markup * $acc_qty);   
                                                                    }
                                                                    
                                                                    if(isset($accomodation_details_moreE) && $accomodation_details_moreE != null && $accomodation_details_moreE != ''){
                                                                        $accomodation_details_more  = Json_decode($accomodation_details_moreE);
                                                                        foreach($accomodation_details_more as $accomodation_details_more1){
                                                                            if(isset($accomodation_details_more1->more_hotel_invoice_markup) && $accomodation_details_more1->more_hotel_invoice_markup != null && $accomodation_details_more1->more_hotel_invoice_markup != ''){
                                                                                $more_hotel_invoice_markup = $accomodation_details_more1->more_hotel_invoice_markup;
                                                                            }else{
                                                                                $more_hotel_invoice_markup = 0;
                                                                            }
                                                                            if(isset($accomodation_details_more1->more_acc_qty) && $accomodation_details_more1->more_acc_qty != null && $accomodation_details_more1->more_acc_qty != ''){
                                                                                $more_acc_qty = $accomodation_details_more1->more_acc_qty;
                                                                            }else{
                                                                                $more_acc_qty = 0;
                                                                            }
                                                                            $acc_total_amount = $acc_total_amount + ($more_hotel_invoice_markup * $more_acc_qty);
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                if(isset($markup_detailsE) && $markup_detailsE != null & $markup_detailsE != ''){
                                                                    $markup_details1    = json_decode($value->markup_details);
                                                                    foreach($markup_details1 as $markup_details)
                                                                    {
                                                                        if($markup_details->markup_Type_Costing == 'flight_Type_Costing'){
                                                                            if($markup_details->markup_price != null && $markup_details->markup_price != ''){
                                                                                $flight_Type_Costing = $markup_details->markup_price * $no_of_pax_days;
                                                                            }else{
                                                                                $flight_Type_Costing = 0;
                                                                            }
                                                                        }
                                                                        if($markup_details->markup_Type_Costing == 'transportation_Type_Costing'){
                                                                            if($markup_details->markup_price != null && $markup_details->markup_price != ''){
                                                                                $transportation_Type_Costing = $markup_details->markup_price * $no_of_pax_days; 
                                                                            }else{
                                                                                $transportation_Type_Costing = 0;
                                                                            }
                                                                        }
                                                                        if($markup_details->markup_Type_Costing == 'visa_Type_Costing'){
                                                                            if($markup_details->markup_price != null && $markup_details->markup_price != ''){
                                                                                if(isset($visa_Pax) && $visa_Pax != null && $visa_Pax != ''){
                                                                                    $visa_Type_Costing = $markup_details->markup_price * $visa_Pax;
                                                                                }else{
                                                                                    $visa_Type_Costing = $markup_details->markup_price * $no_of_pax_days;
                                                                                }
                                                                            }else{
                                                                                $visa_Type_Costing = 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }else{
                                                                    $flight_Type_Costing            = 0;
                                                                    $transportation_Type_Costing    = 0;
                                                                    $visa_Type_Costing              = 0;   
                                                                }
                                                                
                                                                if(isset($more_visa_detailsE) && $more_visa_detailsE != null & $more_visa_detailsE != ''){
                                                                    $more_visa_Type_Costing = 0;
                                                                    $more_visa_details  = json_decode($more_visa_detailsE);
                                                                    // dd($more_visa_details);
                                                                    foreach($more_visa_details as $more_visa_details1){
                                                                        $more_visa_Pax                  = $more_visa_details1->more_visa_Pax;
                                                                        $more_total_visa_markup_value   = $more_visa_details1->more_total_visa_markup_value;
                                                                        $more_visa_Type_Costing = $more_visa_Type_Costing + ($more_visa_Pax * $more_total_visa_markup_value);
                                                                    }
                                                                }else{
                                                                    $more_visa_Type_Costing = 0;
                                                                }
                                                                
                                                                $total_Payable = $acc_total_amount + $transportation_Type_Costing + $flight_Type_Costing + $visa_Type_Costing + $more_visa_Type_Costing;
                                                            ?>
                                                            
                                                            <td><?php echo $currency ?>{{ $total_Payable }}</td>
                                                            <td>{{ Date('Y-m-d',strtotime($value->created_at)) }}</td>
                                                            <td>
                                                                <span style="font-size: 15px;" class="badge bg-info" id="view_outSid_{{ $value->id }}" data-id="{{ $value->id }}" onclick="view_outS({{ $value->id }})">
                                                                    View Outstanding
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <div class="dropdown card-widgets">
                                                                    <a href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                        <i class="dripicons-dots-3"></i>
                                                                    </a>
                                                                    <div class="dropdown-menu dropdown-menu-end" style="">
                                                                        <a href="{{ route('pay_invoice_Agent',$value->id) }}" class="dropdown-item">Pay Amount</a>
                                                                        <a href="{{ route('invoice_Agent',$value->id) }}" class="dropdown-item">View Invoice</a>
                                                                        @if($value->no_of_pax_days == $value->count_P_Input)
                                                                            <a class="dropdown-item" onclick="add_more_passenger({{$value->id}})" data-bs-toggle="modal" data-bs-target="#add-more-passenger-modal">View More Passengers details</a>
                                                                        @else
                                                                            <a class="dropdown-item" onclick="add_more_passenger({{$value->id}})" data-bs-toggle="modal" data-bs-target="#add-more-passenger-modal">Add More Passengers</a>
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        
                                                        <?php $i++ ?>
                                                    @endforeach  
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <div id="add-more-passenger-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" style="margin-right: 700px;">
                <div class="modal-content" style="width: 1100px;">
                    <div class="modal-header">
                        <h4 class="modal-title" id="standard-modalLabel">Add more Passenger</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                    </div>
                    <div class="modal-body">
                        <form action="{{URL::to('add_more_passenger_Invoice')}}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <h3>Lead Passenger Details</h3>
                                <div class="col-lg-12">
                                    <h5>Lead Passenger Name : <span id="lead_name_ID"></span></h5>
                                    <p>Maximum Pax :<span id="no_of_pax_days_ID"></span></p>
                                    <input type="hidden" value="Invoice" id="package_Type" name="package_Type">
                                    <input type="hidden" value="" id="no_of_pax_days_Input" name="no_of_pax_days_Input">
                                    <input type="hidden" value="" id="invoice_Id_Input" name="invoice_Id_Input">
                                    <input type="hidden" value="" id="count_P_Input" name="count_P_Input">
                                    <input type="hidden" value="" id="count_P_Input1">
                                    <input type="hidden" value="" id="more_Passenger_Data_Input" name="more_Passenger_Data_Input">
                                </div>
                                
                                <div id="more_P_D_div"></div>
                                
                                <div class="col-lg-12">
                                    <div class="mb-3 text-last" id="edit_M_P_Button">
                                        <button class="btn btn-primary" id="add_more_P" type="button">Add more Passenger</button>
                                    </div>
                                    
                                </div>
                                
                                <div id="add_more_P_div"></div>
                                
                                <div class="row" id="" style="float:right">
                                    <div class="col-lg-12 mb-3">
                                        <button class="btn btn-primary" id="button_P" type="submit" style="display: none;">Submit</button>
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
    <script>
    
        $(document).ready(function () {
          
            //DataTable
            $('#myTable').DataTable({
                pagingType: 'full_numbers',
            });
            
            //View Modal Single Quotation
            $('.detail-btn').click(function() {
                const id = $(this).attr('data-id');
                $.ajax({
                    url: 'view_QuotationsID/'+id,
                    type: 'GET',
                    data: {
                        "id": id
                    },
                    success:function(data) {
                        var a                = data['a'];
                        var roundTripDetails = a['roundTripDetails'];
                        var oneWayDetails    = a['oneWayDetails'];
                        
                        console.log(a);
            
                        //Flight Details
                        $('#airline_name').html(oneWayDetails['airline_name']);
                        $('#deprturetime').html(oneWayDetails['deprturetime']);
                        $('#ArrivalTime').html(oneWayDetails['ArrivalTime']);
                        $('#deprturedate').html(oneWayDetails['deprturedate']);
                        $('#ArrivalDate').html(oneWayDetails['ArrivalDate']);
                        $('#departure').html(oneWayDetails['departure']);
                        $('#arrival').html(oneWayDetails['arrival']);
                        
                        $('#flighttype').html(a['flighttype']);
                        $('#flight_price').html(a['flight_price']);
                        
                        //Hotel Booking Details Makkkah
                        $('#dateinmakkah').html(a['dateinmakkah']);
                        $('#dateoutmakkah').html(a['dateoutmakkah']);
                        $('#hotel_name_makkah').html(a['hotel_name_makkah']);
                        $('#no_of_rooms_makkah').html(a['no_of_rooms_makkah']);
                        $('#Price_Per_Nights_Makkah').html(a['Price_Per_Nights_Makkah']);
                        $('#Makkah_total_price_cal').html(a['Makkah_total_price_cal']);
                        
                        //Hotel Booking Details Madinah
                        $('#dateinmadinah').html(a['dateinmadinah']);
                        $('#dateoutmadinah').html(a['dateoutmadinah']);
                        $('#hotel_name_madina').html(a['hotel_name_madina']);
                        $('#no_of_rooms_madina').html(a['no_of_rooms_madina']);
                        $('#price_per_night_madinah').html(a['price_per_night_madinah']);
                        $('#madinah_total_price_cal').html(a['madinah_total_price_cal']);
                        
                        
                        //Transfer Details
                        $('#transfer_vehicle').html(a['transfer_vehicle']);
                        $('#passenger').html(a['passenger']);
                        $('#pickuplocat').html(a['pickuplocat']);
                        $('#dropoflocat').html(a['dropoflocat']);
                        $('#trans_date').html(a['trans_date']);
                        $('#transf_price').html(a['transf_price']);
                        
                        //Visa Details
                        $('#visa_fees_adult').html(a['visa_fees_adult']);
                        $('#visa_fees_child').html(a['visa_fees_child']);
                        $('#visa_fees_price').html(a['visa_fees_price']);
                        
                        //Totals
                        $('#flight_price_total').html(a['flight_price']);
                        $('#Makkah_total_price_cal').html(a['Makkah_total_price_cal']);
                        $('#madinah_total_price_cal').html(a['madinah_total_price_cal']);
                        $('#transfers_head_total').html(a['transfers_head_total']);
                        $('#visa_fees').html(a['visa_fees_price']);
                        $('#grand_total_price').html(a['grand_total_price']);
            
                    }
                })
            });
    
        });

    </script>
    
    <script>
        var all_countries = {!!json_encode($all_countries)!!};
        console.log(all_countries);
        
        function add_more_passenger(id){
            $('#edit_M_P_Button').css('display','')
            $('#add_more_P_div').empty();
            $('#invoice_Id_Input').val();
            $('#lead_name_ID').empty();
            $('#no_of_pax_days_ID').empty();
            $('#no_of_pax_days_Input').val();
            $('#add_more_P').css('display','');
            $('#more_P_D_div').empty();
            let I_id = id;
            $.ajax({
                url:"{{URL::to('get_single_Invoice')}}" + '/' + I_id,
                method: "GET",
                data: {
                	I_id:I_id
                },
                success:function(data){
                    var data1                   = data['data'];
                    var invoice_Id              = data1['id'];
                    var f_name                  = data1['f_name'];
                    var middle_name             = data1['middle_name'];
                    var no_of_pax_days          = data1['no_of_pax_days'];
                    $('#invoice_Id_Input').val(invoice_Id);         	  
                    $('#lead_name_ID').html(f_name+' '+middle_name);
                    $('#no_of_pax_days_ID').html(no_of_pax_days);
                    $('#no_of_pax_days_Input').val(no_of_pax_days);
                    
                    var count_P_Input = data1['count_P_Input'];
                    if(count_P_Input > 0 && count_P_Input != null && count_P_Input != ''){
                        $('#count_P_Input').val(count_P_Input);
                        $('#count_P_Input1').val(count_P_Input);
                    }else{
                        $('#count_P_Input').val(1);
                        $('#count_P_Input1').val(1);
                    }
                    
                    var more_Passenger_Data = data1['more_Passenger_Data'];
                    if(more_Passenger_Data != null && more_Passenger_Data != ''){
                        $('#more_Passenger_Data_Input').val(more_Passenger_Data);
                        var edit_M_P_Button = `<button class="btn btn-primary" id="edit_more_P" onclick="edit_more_P()" type="button">Edit more Passenger</button>`;
                        // $('#edit_M_P_Button').append(edit_M_P_Button);
                        
                        var more_Passenger_Data_decode = JSON.parse(data1['more_Passenger_Data']);
                        $.each(more_Passenger_Data_decode, function (key, value) {
                            var more_p_fname            = value.more_p_fname;
                            var more_p_lname            = value.more_p_lname;
                            var more_p_gender           = value.more_p_gender;
                            var more_p_dob              = value.more_p_dob;
                            var more_p_nationality      = value.more_p_nationality;
                            var more_p_passport_number  = value.more_p_passport_number;
                            var more_p_passport_expiry  = value.more_p_passport_expiry;
                            var more_p_passport         = value.more_p_passport;
                            var more_p_image            = value.more_p_image;
                            var url_IandP       = `https://alhijaztours.net/public/uploads/package_imgs/`;
                            
                            var data =  `<div class="row" id="main_div_P_${invoice_Id}">
                                            <div class="col-lg-12">
                                                <h5>More Passenger details</h5>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label for="label" class="form-label">First Name</label>
                                                <input class="form-control remove_readonly_prop" type="text" value="${more_p_fname}" name="" placeholder="" readonly>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label for="label" class="form-label">Last Name</label>
                                                <input class="form-control remove_readonly_prop" type="text" value="${more_p_lname}" name="" placeholder="" readonly>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <label for="label" class="form-label">Gender</label>
                                                <select class="form-control" name="" readonly>`;
                                                    if(more_p_gender == 'Male'){
                            data +=                     `<option value="Male" selected>Male</option>
                                                        <option value="Female">Female</option>`;
                                                    }
                                                    else if(more_p_gender == 'Female'){
                            data +=                     `<option value="Male">Male</option>
                                                        <option value="Female" selected>Female</option>`;
                                                    }
                                                    else{
                            data +=                     `<option value="">Choose...</option>
                                                        <option value="Male">Male</option>
                                                        <option value="Female">Female</option>`;
                                                    }
                            data +=             `</select>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Date of Birth</label>
                                                <input class="form-control" type="text" value="${more_p_dob}" name="more_p_dob[]" readonly>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Nationality</label>
                                                <input class="form-control" type="text" value="${more_p_nationality}" name="more_p_nationality[]" readonly>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Passport Number</label>
                                                <input class="form-control" type="text" value="${more_p_passport_number}" name="more_p_passport_number[]" readonly>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Passport Expire Date</label>
                                                <input class="form-control" type="text" value="${more_p_passport_expiry}" name="more_p_passport_expiry[]" readonly>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Passport</label>
                                                <input class="form-control" type="text" value="${more_p_passport}" name="" readonly>
                                                <input class="form-control" type="file" value="${more_p_passport}" name="" hidden>
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <label for="" class="form-label">Image</label>
                                                <img src="${url_IandP}${more_p_image}" style="height: 80px;width: 80px;">
                                                <input class="form-control" type="text" name="" readonly hidden>
                                                <input class="form-control" type="file" name="" readonly hidden>
                                            </div>
                                        </div>`;
                            
                            if(more_p_fname != null){
                                $('#more_P_D_div').append(data);
                            }
                        });
                    }
                    
                    // if(no_of_pax_days = count_P_Input){
                    //     $('#edit_M_P_Button').css('display','none')
                    // }
                }
            }); 
        }
        
        $('#add_more_P').click(function() {
            $('#button_P').css('display','');
            
            var count_P = $('#count_P_Input').val();
            count_P     = parseFloat(count_P) + 1;
            
            var no_of_pax_days_Input    = $('#no_of_pax_days_Input').val();
            var id_P                    = $('#invoice_Id_Input').val();
            var data =  `<div class="row" id="main_div_P_${id_P}${count_P}">
                            <div class="col-lg-12">
                                <h5>More Passenger # ${count_P}</h5>
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label for="label" class="form-label">First Name</label>
                                <input class="form-control" type="text" id="more_p_fname${id_P}_${count_P}" name="more_p_fname[]" placeholder="" required>
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label for="label" class="form-label">Last Name</label>
                                <input class="form-control" type="text" id="more_p_lname${id_P}_${count_P}" name="more_p_lname[]" placeholder="" required>
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label for="label" class="form-label">Gender</label>
                                <select class="form-control" id="more_p_gender${id_P}_${count_P}" name="more_p_gender[]" placeholder="Choose..." required>
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Date of Birth</label>
                                <input class="form-control" type="date" id="more_p_dob${id_P}_${count_P}" name="more_p_dob[]" placeholder="" required>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Nationality</label>
                                <select class="form-control" id="more_p_nationality${id_P}_${count_P}" name="more_p_nationality[]" required>`;
                                $.each(all_countries, function(key, value) {
                                        data += `<option value="${value.name}">${value.name}</option>`;
                                });     
                                data += `<select>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Passport Number</label>
                                <input class="form-control" type="text" id="more_p_passport_number${id_P}_${count_P}" name="more_p_passport_number[]" placeholder="" required>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Passport Expire Date</label>
                                <input class="form-control" type="date" id="more_p_passport_expiry${id_P}_${count_P}" name="more_p_passport_expiry[]" placeholder="" required>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Passport Picture</label>
                                <input class="form-control" type="file" id="more_p_passport${id_P}_${count_P}" name="more_p_passport[]" placeholder="">
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label for="image" class="form-label">Image</label>
                                <input class="form-control" type="file" id="more_p_image${id_P}_${count_P}" name="more_p_image[]" placeholder="">
                            </div>
                            <div class="mb-3">
                                <button class="btn btn-primary" id="remove_more_P" onclick="removeMorePassenger(${id_P}${count_P})" type="button">Remove</button>
                            </div>
                        </div>`;
                        
            if(count_P <= no_of_pax_days_Input){
                $('#add_more_P_div').append(data);
                $('#count_P_Input').val(count_P);
            }else{
                $('#add_more_P').css('display','none');
                count_P = count_P - 1;
                $('#count_P_Input').val(count_P);
            }
        });
        
        function removeMorePassenger(id){
            $('#main_div_P_'+id+'').remove();
            var no_of_pax_days_Input    = $('#no_of_pax_days_Input').val();
            var count_P                 = $('#count_P_Input').val();
            var count_P_Input1          = $('#count_P_Input1').val();
            count_P                     = count_P - 1;
            $('#count_P_Input').val(count_P);
            if(count_P <= no_of_pax_days_Input){
                $('#add_more_P').css('display','');
            }
            
            if(count_P_Input = count_P_Input1){
                $('#button_P').css('display','none');
            }
        }
        
    </script>
    
    <script>
        function view_outS(id){
            const I_id = $('#view_outSid_'+id+'').attr('data-id');
            $('#view_outS_'+id+'').empty();
            
            $.ajax({
                url:"{{URL::to('get_single_Invoice')}}" + '/' + I_id,
                type: 'GET',
                data: {
                    I_id: I_id
                },
                success:function(data) {
                    // console.log(data);
                    var total_Invoice_Agent         = data['total_Invoice_Agent'];
                    var outStanding_Invoice_Agent   = data['outStanding_Invoice_Agent'];
                    
                    if(outStanding_Invoice_Agent != null && outStanding_Invoice_Agent != ''){
                        var total_AmountF   = parseInt(total_Invoice_Agent['total_Amount']);
                        var out_S           = parseFloat(total_AmountF) - parseFloat(outStanding_Invoice_Agent);
                        if(out_S < 0){
                            $('#view_outSid_'+id+'').html('OVER PAID'+'('+out_S+')'+'');
                        }else{
                            $('#view_outSid_'+id+'').html(out_S);  
                        }   
                    }else{
                        $('#view_outSid_'+id+'').html('Nothing Paid Yet');
                    }
                },
            });
        }
    </script>

@endsection
