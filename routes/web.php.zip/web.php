<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CountryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get("removecache",function (){
\Illuminate\Support\Facades\Artisan::call('route:cache');
\Illuminate\Support\Facades\Artisan::call('route:clear');
\Illuminate\Support\Facades\Artisan::call('config:cache');
\Illuminate\Support\Facades\Artisan::call('config:clear');
\Illuminate\Support\Facades\Artisan::call('optimize');
});








Route::group(['middleware'=>'admin_middleware'],function(){
    
    Route::get('/','frontend\user_dashboard\UserController@index');
  
});  

Route::group(['prefix'=>'super_admin','middleware'=>'admin_middleware'],function(){

    Route::get('/','frontend\user_dashboard\UserController@index');
    Route::get('create_umrah_packages','frontend\admin_dashboard\UmrahPackageController@create');
    Route::post('submit_umrah_packages','frontend\admin_dashboard\UmrahPackageController@store');
    Route::get('view_umrah_packages','frontend\admin_dashboard\UmrahPackageController@view');

    Route::get('delete_umrah_packages/{id}','frontend\admin_dashboard\UmrahPackageController@delete_umrah_packages');
    Route::get('edit_umrah_packages/{id}','frontend\admin_dashboard\UmrahPackageController@edit_umrah_packages');
    Route::post('submit_edit_umrah_packages/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_umrah_packages');

    Route::get('enable_umrah_packages/{id}','frontend\admin_dashboard\UmrahPackageController@enable_umrah_packages');
    Route::get('disable_umrah_package/{id}','frontend\admin_dashboard\UmrahPackageController@disable_umrah_packages');






    Route::get('create_excursion','frontend\admin_dashboard\UmrahPackageController@create_excursion');
    Route::post('submit_tour','frontend\admin_dashboard\UmrahPackageController@submit_tour');
    Route::get('view_tour','frontend\admin_dashboard\UmrahPackageController@view_tour');
    Route::get('delete_tour/{id}','frontend\admin_dashboard\UmrahPackageController@delete_tour');
    Route::get('edit_tour/{id}','frontend\admin_dashboard\UmrahPackageController@edit_tour');
    Route::post('submit_edit_tour/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_tour');

    Route::get('enable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@enable_tour');
    Route::get('disable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@disable_tour');


    Route::get('add_categories','frontend\admin_dashboard\UmrahPackageController@add_categories');
    Route::post('submit_categories','frontend\admin_dashboard\UmrahPackageController@submit_categories');
    Route::get('view_categories','frontend\admin_dashboard\UmrahPackageController@view_categories');

    Route::get('delete_categories/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories');
    Route::get('edit_categories/{id}','frontend\admin_dashboard\UmrahPackageController@edit_categories');
    Route::post('submit_edit_categories/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_categories');





    Route::get('add_attributes','frontend\admin_dashboard\UmrahPackageController@add_attributes');
    Route::post('submit_attributes','frontend\admin_dashboard\UmrahPackageController@submit_attributes');
    Route::get('view_attributes','frontend\admin_dashboard\UmrahPackageController@view_attributes');

    Route::get('delete_attributes/{id}','frontend\admin_dashboard\UmrahPackageController@delete_attributes');
    Route::get('edit_attributes/{id}','frontend\admin_dashboard\UmrahPackageController@edit_attributes');
    Route::post('submit_edit_attributes/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_attributes');

 // Usama Routes
 Route::get('customer_subcription','frontend\admin_dashboard\CustomerSubscription@showSubscriptionForm');
 Route::post('submit_subcription','frontend\admin_dashboard\CustomerSubscription@create');







Route::get('ticket_view','frontend\user_dashboard\UserController@view_ticket');
Route::post('ticket_view/submit/{id}','frontend\user_dashboard\UserController@admin_ticket');

//employees routes
Route::get('/employees',[App\Http\Controllers\frontend\EmployeeController::class,'employees']);
Route::get('/employees/add',[App\Http\Controllers\frontend\EmployeeController::class,'create']);
Route::post('/employees/submit',[App\Http\Controllers\frontend\EmployeeController::class,'store']);
Route::get('/employees_edit/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'edit']);
Route::post('/employees_update/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'update']);
Route::get('/employees_delete/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'delete']);
Route::get('/view_location/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'view_location']);
Route::get('/view_task_location/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'view_task_location']);
Route::get('/employee_roles',[App\Http\Controllers\frontend\EmployeeController::class,'employee_roles']);
Route::post('/add_roles',[App\Http\Controllers\frontend\EmployeeController::class,'add_roles']);
Route::post('/edit_roles',[App\Http\Controllers\frontend\EmployeeController::class,'edit_roles']);
Route::get('/del_roles/{id}',[App\Http\Controllers\frontend\EmployeeController::class,'del_roles']);
//employees routes


//attendence routes
Route::get('/attendance',[App\Http\Controllers\frontend\AttendenceController::class,'attendence']);
Route::get('/attendance/add',[App\Http\Controllers\frontend\AttendenceController::class,'create']);
Route::post('/attendance/submit',[App\Http\Controllers\frontend\AttendenceController::class,'store']);
Route::get('/attendance_edit/{id}',[App\Http\Controllers\frontend\AttendenceController::class,'edit']);
Route::post('/attendance_update/{id}',[App\Http\Controllers\frontend\AttendenceController::class,'update']);
Route::get('/attendance_delete/{id}',[App\Http\Controllers\frontend\AttendenceController::class,'delete']);
Route::post('/appoint/{id}',[App\Http\Controllers\frontend\AttendenceController::class,'view_task'])->name('task.appoint');
Route::get('/assign_mandob/{id}',[App\Http\Controllers\frontend\AttendenceController::class,'assign_mandob']);

Route::get('employees_task',[App\Http\Controllers\frontend\AttendenceController::class,'employees_task']);
Route::post('submit_task',[App\Http\Controllers\frontend\AttendenceController::class,'submit_task']);
Route::get('employees_task_edit',[App\Http\Controllers\frontend\AttendenceController::class,'employees_task_edit']);





Route::get('/leave_employees',[App\Http\Controllers\LeaveController::class,'index']);
Route::get('/leave_status/{status}/{id}',[App\Http\Controllers\LeaveController::class,'status']);
Route::post('/leaves/submit',[App\Http\Controllers\LeaveController::class,'store']);



Route::get('/approve/{id}', [App\Http\Controllers\LeaveController::class,'approve'])->name('admin.approve');
Route::get('/decline/{id}', [App\Http\Controllers\LeaveController::class,'decline'])->name('admin.decline');

//settings route 
Route::get('/settings','frontend\user_dashboard\UserController@settings');
Route::post('change-password', 'frontend\LoginController@change_password');

Route::get('send_email_to_agents','frontend\user_dashboard\UserController@send_email_to_agents');
Route::post('/send_mail','frontend\user_dashboard\UserController@send_mail');


Route::get('/manage_user_roles','frontend\user_dashboard\UserController@manage_user_roles');
Route::post('/add_user_permission','frontend\user_dashboard\UserController@add_user_permission');
Route::post('/edit_user_permission','frontend\user_dashboard\UserController@edit_user_permission');
Route::get('mange_user_role_delete/{id}','frontend\user_dashboard\UserController@mange_user_role_delete');
Route::get('activate_user/{id}','frontend\user_dashboard\UserController@super_admin_activate_user');
Route::get('inactivate_user/{id}','frontend\user_dashboard\UserController@super_admin_inactivate_user');



Route::get('create_offers','frontend\user_dashboard\UserController@create_offers');
Route::post('submit_offers','frontend\user_dashboard\UserController@submit_offers');
Route::get('edit_offers/{id}','frontend\user_dashboard\UserController@edit_offers');
Route::post('submit_edit_offers/{id}','frontend\user_dashboard\UserController@submit_edit_offers');
Route::get('delete_offers/{id}','frontend\user_dashboard\UserController@delete_offers');
Route::get('view_offers','frontend\user_dashboard\UserController@view_offers');
});

Route::post('/country_cites', [CountryController::class,'countryCites']);

// user dashboard routes ends

//login  and register routes
Route::get('signup1', 'frontend\Register1Controller@signup');
Route::post('register1', 'frontend\Register1Controller@register1');
Route::get('login1', 'frontend\LoginController@login');
Route::post('signin', 'frontend\LoginController@signin');
Route::post('change-password', 'frontend\LoginController@change_password');
Route::get('logout', 'frontend\LoginController@logout');
Auth::routes();

 Route::get('/home', 'HomeController@index')->name('home');






