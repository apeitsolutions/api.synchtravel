<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\SupplierControllerApi;
use App\Http\Controllers\MutamerControllerApi;
use App\Http\Controllers\HotelMangers\HotelController;
use App\Http\Controllers\HotelMangers\HotelbookingController;
// Hotel & Rooms
use App\Http\Controllers\HotelMangersApi\HotelControllerApi;
use App\Http\Controllers\HotelMangersApi\RoomControllerApi;
use App\Models\city;
use App\Models\country;
// Manage Office
use App\Http\Controllers\frontend\admin_dashboard\ManageOfficeController;
use App\Http\Controllers\frontend\admin_dashboard\InvoiceRequestController;
// Quotationssubmit_tours_api
use App\Http\Controllers\frontend\admin_dashboard\ManageQuotationsController;
use App\Http\Controllers\frontend\admin_dashboard\ManageQuotationsControllerApi;
use App\Http\Controllers\frontend\admin_dashboard\UmrahPackageControllerApi;
// Account Details
use App\Http\Controllers\frontend\admin_dashboard\AccountDetailsApiController;
// Vehicle
use App\Http\Controllers\frontend\admin_dashboard\TransferVehiclesApiController;
// Transfer Booking
use App\Http\Controllers\frontend\admin_dashboard\TransferzController;

use App\Http\Controllers\Accounts\CashAccControllerApi;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/





/*
|--------------------------------------------------------------------------
| hotels route started by jamshaid cheena
|--------------------------------------------------------------------------
*/

Route::post('hotels_searching','frontend\admin_dashboard\HotelBookingController@hotels_search');

/*
|--------------------------------------------------------------------------
|hotels route end by jamshaid cheena
|--------------------------------------------------------------------------
*/

// Route::post('view_Quotations',[
//   'middleware' => 'token_CheckMiddleware:editor',
//   'uses'       => 'frontend\admin_dashboard\ManageQuotationsControllerApi@view_Quotations',
// ]);

// Route::post('view_Quotations',[ManageQuotationsControllerApi::class,'view_Quotations']);
Route::post('agents_financial_stats',[ManageOfficeController::class,'agents_financial_stats']);

Route::post('booking_financial_stats',[ManageOfficeController::class,'booking_financial_stats']);

Route::post('single_notification_detail/{id}',[ManageOfficeController::class,'single_notification_detail']);
Route::post('all_notification_detail',[ManageOfficeController::class,'all_notification_detail']);
Route::post('alhijaz_Notification_function','frontend\admin_dashboard\UmrahPackageController@alhijaz_Notification_function');
Route::post('financial_statement','frontend\admin_dashboard\bookingController@financial_statement');
Route::post('transfer_supplier_payments','frontend\admin_dashboard\TransferSupplierController@transfer_supplier_payments');

Route::post('hotel_arrival_list',[HotelControllerApi::class,'hotel_arrival_list']);
Route::post('hotel_departure_list',[HotelControllerApi::class,'hotel_departure_list']);

Route::post('search_api','frontend\admin_dashboard\HotelController@search_api');
//hotel supplier start//
Route::post('add_hotel_suppliers','frontend\admin_dashboard\HotelSupplierController@add_hotel_suppliers');
Route::post('submit_hotel_suppliers','frontend\admin_dashboard\HotelSupplierController@submit_hotel_suppliers');
Route::post('view_hotel_suppliers','frontend\admin_dashboard\HotelSupplierController@view_hotel_suppliers');
Route::post('hotel_supplier_stats','frontend\admin_dashboard\HotelSupplierController@hotel_supplier_stats');
Route::post('supplier_hotel_wallet_trans','frontend\admin_dashboard\HotelSupplierController@supplier_hotel_wallet_trans');
Route::post('hotel_supplier_payments','frontend\admin_dashboard\HotelSupplierController@hotel_supplier_payments');

Route::post('view_room_bookings','frontend\admin_dashboard\HotelSupplierController@view_room_bookings');
Route::post('edit_hotel_suppliers','frontend\admin_dashboard\HotelSupplierController@edit_hotel_suppliers');
Route::post('submit_edit_hotel_suppliers','frontend\admin_dashboard\HotelSupplierController@submit_edit_hotel_suppliers');
Route::post('delete_hotel_suppliers','frontend\uadmin_dashboard\HotelSupplierController@delete_hotel_suppliers');
//hotel supplier ended//


// add visa suplier
Route::post('submit_visa_suppliers','frontend\admin_dashboard\visaSupplierController@submit_visa_suppliers');
Route::post('get_visa_suppliers','frontend\admin_dashboard\visaSupplierController@get_visa_suppliers');
Route::post('get_visa_suppliers_for_edit','frontend\admin_dashboard\visaSupplierController@get_visa_suppliers_for_edit');
Route::post('submit_visa_suppliers_for_update','frontend\admin_dashboard\visaSupplierController@submit_visa_suppliers_for_update');
//
// submit_visa_type
Route::post('get_visa_type_for_sup','frontend\admin_dashboard\visaSupplierController@get_visa_type_for_sup');
Route::post('submit_visa_avalability_for_sup','frontend\admin_dashboard\visaSupplierController@submit_visa_avalability_for_sup');
//
Route::post('add_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@add_transfer_suppliers');
Route::post('submit_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@submit_transfer_suppliers');
Route::post('view_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@view_transfer_suppliers');
Route::post('transfer_supplier_stats','frontend\admin_dashboard\TransferSupplierController@transfer_supplier_stats');
Route::post('edit_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@edit_transfer_suppliers');
Route::post('submit_edit_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@submit_edit_transfer_suppliers');
Route::post('delete_transfer_suppliers','frontend\admin_dashboard\TransferSupplierController@delete_transfer_suppliers');


Route::post('add_transfer_company','frontend\admin_dashboard\TransferCompanyController@add_transfer_company');
Route::post('submit_transfer_company','frontend\admin_dashboard\TransferCompanyController@submit_transfer_company');
Route::post('view_transfer_company','frontend\admin_dashboard\TransferCompanyController@view_transfer_company');
Route::post('transfer_company_stats','frontend\admin_dashboard\TransferCompanyController@transfer_company_stats');
Route::post('edit_transfer_company','frontend\admin_dashboard\TransferCompanyController@edit_transfer_company');
Route::post('submit_edit_transfer_company','frontend\admin_dashboard\TransferCompanyController@submit_edit_transfer_company');
Route::post('delete_transfer_company','frontend\admin_dashboard\TransferCompanyController@delete_transfer_company');

//supplier start//
Route::post('fetchallhotels',[SupplierControllerApi::class,'fetchallhotels']);
Route::post('fetchhotelrecord',[SupplierControllerApi::class,'fetchhotelrecord']);
Route::post('view_seat_occupancy',[SupplierControllerApi::class,'view_seat_occupancy']);
Route::post('invoice_for_occupancy',[SupplierControllerApi::class,'invoice_for_occupancy']);
Route::post('fetchflightrate',[SupplierControllerApi::class,'fetchflightrate']);
Route::post('pax_details',[SupplierControllerApi::class,'pax_details']);

//mutamer
Route::post('getinvoice',[MutamerControllerApi::class,'getinvoice']);
Route::post('addlead',[MutamerControllerApi::class,'addlead']);
Route::post('leadpassengerin',[MutamerControllerApi::class,'leadpassengerin']);
Route::post('save_lead_location',[MutamerControllerApi::class,'save_lead_location']);
Route::post('get_lead_location',[MutamerControllerApi::class,'get_lead_location']);
Route::post('cron_update_lead_location',[MutamerControllerApi::class,'cron_update_lead_location']);
Route::post('lead_logout',[MutamerControllerApi::class,'lead_logout']);
Route::post('get_invoice_data',[MutamerControllerApi::class,'get_invoice_data']);

Route::post('createsupplier',[SupplierControllerApi::class,'createsupplier']);
Route::post('get_suppliers_flights_detail',[SupplierControllerApi::class,'get_suppliers_flights_detail']);
Route::post('get_suppliers_flights_rute',[SupplierControllerApi::class,'get_suppliers_flights_rute']);

Route::post('fetchsupplier',[SupplierControllerApi::class,'fetchsupplier']);
Route::post('supplier_wallet_trans',[SupplierControllerApi::class,'supplier_wallet_trans']);
Route::post('deletesupplier',[SupplierControllerApi::class,'deletesupplier']);
Route::post('editsupplier',[SupplierControllerApi::class,'editsupplier']);
Route::post('updatesupplier',[SupplierControllerApi::class,'updatesupplier']);
// fetch supllier name
Route::post('fetchsuppliername',[SupplierControllerApi::class,'fetchsuppliername']);

Route::post('fetchallsupplierforseats',[SupplierControllerApi::class,'fetchallsupplierforseats']);
Route::post('createseat',[SupplierControllerApi::class,'createseat']);
Route::post('fetchseat',[SupplierControllerApi::class,'fetchseat']);
Route::post('deleteseat',[SupplierControllerApi::class,'deleteseat']);
Route::post('editseat',[SupplierControllerApi::class,'editseat']);
Route::post('updateseat',[SupplierControllerApi::class,'updateseat']);

Route::post('fetchairline',[SupplierControllerApi::class,'fetchairline']);
Route::post('save_flight_payment_recieved_and_remaining',[SupplierControllerApi::class,'save_flight_payment_recieved_and_remaining']);
// chart
Route::post('supplierdetail',[SupplierControllerApi::class,'supplierdetail']);
// Route::post('getbookingofroom',[SupplierControllerApi::class,'getbookingofroom']);
Route::post('getbooking',[SupplierControllerApi::class,'getbooking']);
//supplier end//
// customer subcriptions authentication
Route::post('customer_subcriptions_authentication',[HotelbookingController::class,'customer_subcriptions_authentication']);
Route::post('view_track_id_booking_hotel',[UmrahPackageControllerApi::class,'view_track_id_booking_hotel']);
// Transfer Search
Route::post('transfer_serach','frontend\admin_dashboard\TransferzController@transfer_serach');
Route::post('SaveTransferBooking','frontend\admin_dashboard\TransferzController@SaveTransferBooking');
Route::post('add_lead_passengar_transfer','frontend\admin_dashboard\TransferzController@add_lead_passengar_transfer');
Route::post('add_other_passengar_transfer','frontend\admin_dashboard\TransferzController@add_other_passengar_transfer');
Route::post('confrimTransferbooking','frontend\admin_dashboard\TransferzController@confrimTransferbooking');
Route::post('transfer_voucher','frontend\admin_dashboard\TransferzController@transfer_voucher');
Route::post('transfer_cancellation','frontend\admin_dashboard\TransferzController@transfer_cancellation');
// Transfer Search

Route::post('payment_messages','frontend\admin_dashboard\UmrahPackageController@payment_messages');
Route::post('submit_payment_messages','frontend\admin_dashboard\UmrahPackageController@submit_payment_messages');
Route::post('edit_payment_messages','frontend\admin_dashboard\UmrahPackageController@edit_payment_messages');

Route::post('hotel_voucher/{id}/{slug}','frontend\admin_dashboard\UmrahPackageController@hotel_voucher');
Route::post('save_passenger_detail_hotel','frontend\admin_dashboard\HotelController@save_passenger_detail_hotel');
Route::post('add_lead_passengar','frontend\admin_dashboard\HotelController@add_lead_passengar');
Route::post('add_other_passengar','frontend\admin_dashboard\HotelController@add_other_passengar');
Route::post('add_child_passengar','frontend\admin_dashboard\HotelController@add_child_passengar');
Route::post('hotelbed_booking','frontend\admin_dashboard\HotelController@hotelbed_booking');
Route::post('hotel_bed_cancelliation','frontend\admin_dashboard\HotelController@hotel_bed_cancelliation');
Route::post('get_booking_checkout','frontend\admin_dashboard\HotelController@get_booking_checkout');
Route::post('hotel_cart','frontend\admin_dashboard\HotelController@hotel_cart');
Route::post('travellanda_cancel_policy_data','frontend\admin_dashboard\HotelController@travellanda_cancel_policy_data');
Route::post('get_travelanda_hotel_details','frontend\admin_dashboard\HotelController@get_travelanda_hotel_details');

Route::post('get_hotel_cities_code','frontend\admin_dashboard\HotelController@get_hotel_cities_code');
Route::post('get_hotel_details_by_hotelbeds','frontend\admin_dashboard\HotelController@get_hotel_details_by_hotelbeds');
Route::post('travellanda_get_hotel_details','frontend\admin_dashboard\HotelController@travellanda_get_hotel_details');

Route::post('tbo_get_hotel_code_list','frontend\admin_dashboard\HotelController@tbo_get_hotel_code_list');
Route::post('get_booking_with_token','frontend\admin_dashboard\HotelController@get_booking_with_token');

Route::post('get_booking_with_token_hotelbeds','frontend\admin_dashboard\HotelController@get_booking_with_token_hotelbeds');
Route::post('get_booking_with_token_tbo','frontend\admin_dashboard\HotelController@get_booking_with_token_tbo');
Route::post('get_booking_with_token_ratehawk','frontend\admin_dashboard\HotelController@get_booking_with_token_ratehawk');

Route::post('booking_now_admin','frontend\admin_dashboard\HotelController@booking_now_admin');
Route::post('get_payment_detact_by_admin','frontend\admin_dashboard\HotelController@get_payment_detact_by_admin');
Route::post('get_hotel_payment_details_by_id','frontend\admin_dashboard\HotelController@get_hotel_payment_details_by_id');


Route::post('get_country_hotel_beds','frontend\admin_dashboard\HotelController@get_country_hotel_beds');

    Route::post('submit_other_visa_type','frontend\admin_dashboard\UmrahPackageController@submit_other_visa_type');
    Route::post('get_other_visa_type','frontend\admin_dashboard\UmrahPackageController@get_other_visa_type');
         
    Route::post('submit_other_Hotel_Name','frontend\admin_dashboard\UmrahPackageController@submit_other_Hotel_Name');
    Route::post('get_other_Hotel_Name','frontend\admin_dashboard\UmrahPackageController@get_other_Hotel_Name');
    
    Route::post('submit_pickup_location','frontend\admin_dashboard\UmrahPackageController@submit_pickup_location');
    Route::post('get_pickup_dropof_location','frontend\admin_dashboard\UmrahPackageController@get_pickup_dropof_location');
    
    Route::post('submit_dropof_location','frontend\admin_dashboard\UmrahPackageController@submit_dropof_location');
    
    Route::post('submitForm_Airline_Name','frontend\admin_dashboard\UmrahPackageController@submitForm_Airline_Name');
    Route::post('get_other_Airline_Name','frontend\admin_dashboard\UmrahPackageController@get_other_Airline_Name');
    
    Route::post('submit_other_Hotel_Type','frontend\admin_dashboard\UmrahPackageController@submit_other_Hotel_Type');
    Route::post('get_other_Hotel_Type','frontend\admin_dashboard\UmrahPackageController@get_other_Hotel_Type');
    
    Route::post('save_activities','ActivityController@save_activities');
    Route::post('update_activities','ActivityController@update_activities');
    Route::post('index_activities','ActivityController@index_activities');
    
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

/*
|--------------------------------------------------------------------------
| api routes written by Usama Ali
|--------------------------------------------------------------------------
|
| 
|
*/

Route::get('get_hotelbeds_token','frontend\admin_dashboard\UmrahPackageControllerApi@get_hotelbeds_token');


/*
|--------------------------------------------------------------------------
| api routes written by Usama Ali 22-06-2022
|--------------------------------------------------------------------------
|
| 
|
*/

Route::post('get_flight_name',[ManageQuotationsControllerApi::class,'get_flight_name']);

// Activity Booking
Route::post('view_ternary_bookings_Activity','frontend\admin_dashboard\UmrahPackageControllerApi@view_ternary_bookings_Activity');
Route::post('view_confirmed_bookings_Activity','frontend\admin_dashboard\UmrahPackageControllerApi@view_confirmed_bookings_Activity');

Route::post('view_booking_payment_Activity/{id}/{tourId}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_payment_Activity');
Route::post('view_booking_detail_Activity/{id}/{tourId}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_detail_Activity');
Route::post('view_booking_customer_details_Activity/{id}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_customer_details_Activity');
Route::post('confirmed_tour_booking_Activity/{id}','frontend\admin_dashboard\UmrahPackageControllerApi@confirmed_tour_booking_Activity');

Route::post('view_booking_payment_recieve_Activity/{tourId}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_payment_recieve_Activity');
Route::post('view_ternary_bookings_tourId_Activity/{P_Id}','frontend\admin_dashboard\UmrahPackageControllerApi@view_ternary_bookings_tourId_Activity');
// END Activity Booking

// Tour Booking
Route::post('view_ternary_bookings','frontend\admin_dashboard\UmrahPackageControllerApi@view_ternary_bookings');
Route::post('view_confirmed_bookings','frontend\admin_dashboard\UmrahPackageControllerApi@view_confirmed_bookings');

Route::post('view_booking_payment/{id}/{tourId}/{cartD_ID}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_payment');
Route::post('view_booking_detail/{id}/{tourId}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_detail');
Route::post('view_booking_customer_details/{id}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_customer_details');
Route::post('confirmed_tour_booking/{id}','frontend\admin_dashboard\UmrahPackageControllerApi@confirmed_tour_booking');

Route::post('view_booking_payment_recieve/{tourId}','frontend\admin_dashboard\UmrahPackageControllerApi@view_booking_payment_recieve');
Route::post('view_ternary_bookings_tourId/{P_Id}','frontend\admin_dashboard\UmrahPackageControllerApi@view_ternary_bookings_tourId');

Route::post('occupancy_tour/{id}','frontend\admin_dashboard\UmrahPackageController@occupancy_tour');

Route::post('view_Tour_PopUp/{id}','frontend\admin_dashboard\UmrahPackageController@view_Tour_PopUp');

// View Tour More Details
Route::post('more_Tour_Details/{id}','frontend\admin_dashboard\UmrahPackageController@more_Tour_Details');
Route::post('get_tours_booking','frontend\admin_dashboard\UmrahPackageController@get_tours_booking');
Route::post('view_more_bookings/{id}','frontend\admin_dashboard\UmrahPackageController@view_more_bookings');

Route::post('super_admin_index','frontend\admin_dashboard\UmrahPackageController@super_admin_index');

//Quotations


/*
|--------------------------------------------------------------------------
| api routes written by Usama Ali 22-06-2022
|--------------------------------------------------------------------------
|
| 
|
*/

Route::post('cash_accounts_list',[CashAccControllerApi::class,'cash_accounts_list']);
Route::post('cash_accounts_ledger',[CashAccControllerApi::class,'cash_accounts_ledger']);
Route::post('cash_accounts_add',[CashAccControllerApi::class,'cash_accounts_add']);
Route::post('add_payment_recv',[CashAccControllerApi::class,'add_payment_recv']);
Route::post('payments_recv_submit',[CashAccControllerApi::class,'payments_recv_submit']);
Route::post('view_pay_recv',[CashAccControllerApi::class,'view_pay_recv']);


// Hotel Route
Route::post('get_hotel_booking',[HotelControllerApi::class,'get_hotel_booking']);
Route::post('hotel_manger/add_hotel',[HotelControllerApi::class,'showAddHotelFrom']);
Route::post('/hotel_manger/add_hotel_sub',[HotelControllerApi::class,'addHotel']);
Route::post('/hotel_manger/add_hotel_sub_ajax',[HotelControllerApi::class,'add_hotel_sub_ajax']);
Route::post('/hotel_manger/hotel_list',[HotelControllerApi::class,'index']);
Route::post('/country_cites', [CountryController::class,'countryCites']);
Route::post('/country_code', [CountryController::class,'country_code']);



Route::post('hotel_manger/edit_hotel',[HotelControllerApi::class,'showeditHotelFrom']);
Route::post('hotel_manger/edit_hotel/submit',[HotelControllerApi::class,'updateHotel']);


Route::post('/city', function () {
    $city = city::find(1);
    $country = $city->Country;
    dd($country);
    echo "This is Country ";
});

// Manage Office Routes
    
    // Agents
    Route::post('agent_ledeger',[ManageOfficeController::class,'agent_ledeger']);
    
        Route::post('create_customer',[ManageOfficeController::class,'create_customer']);
    Route::post('submit_customer',[ManageOfficeController::class,'submit_customer']);
    
    Route::post('customer_ledeger',[ManageOfficeController::class,'customer_ledeger']);
    Route::post('create_Agents',[ManageOfficeController::class,'create_Agents']);
    Route::post('add_Agents',[ManageOfficeController::class,'add_Agents']);
    Route::post('edit_Agents/{id}',[ManageOfficeController::class,'edit_Agents']);
    Route::post('update_Agents/{id}',[ManageOfficeController::class,'update_Agents']);
    Route::post('delete_Agents/{id}',[ManageOfficeController::class,'delete_Agents']);
    
    // Invoice
    Route::post('create_Invoices',[ManageOfficeController::class,'create_Invoices']);
    Route::post('view_Invoices',[ManageOfficeController::class,'view_Invoices']);
    Route::post('add_Invoices',[ManageOfficeController::class,'add_Invoices']);
    
    // Transfer Supplier Invoice
    Route::post('get_TranferSuppliers',[ManageOfficeController::class,'get_TranferSuppliers']);
    Route::post('add_Invoices_TranSupp',[ManageOfficeController::class,'add_Invoices_TranSupp']);
    Route::post('update_Invoices_TranSupp/{id}',[ManageOfficeController::class,'update_Invoices_TranSupp']);
    
    Route::post('edit_Invoices/{id}',[ManageOfficeController::class,'edit_Invoices']);
    Route::post('update_Invoices/{id}',[ManageOfficeController::class,'update_Invoices']);
    Route::post('confirm_invoice_Agent/{id}',[ManageOfficeController::class,'confirm_invoice_Agent']);
    Route::post('invoice_Agent/{id}',[ManageOfficeController::class,'invoice_Agent'])->name('invoice_Agent');
    Route::post('pay_invoice_Agent/{id}',[ManageOfficeController::class,'pay_invoice_Agent'])->name('pay_invoice_Agent');
    Route::post('recieve_invoice_Agent',[ManageOfficeController::class,'recieve_invoice_Agent'])->name('recieve_invoice_Agent');
    Route::post('payable_ledger',[ManageOfficeController::class,'payable_ledger'])->name('payable_ledger');
    Route::post('receivAble_ledger',[ManageOfficeController::class,'receivAble_ledger'])->name('receivAble_ledger');
    Route::post('cash_ledger',[ManageOfficeController::class,'cash_ledger'])->name('cash_ledger');
    
    Route::post('request_Invoices',[InvoiceRequestController::class,'request_Invoices']);
    Route::post('request_Invoices_submit',[InvoiceRequestController::class,'request_Invoices_submit']);
       Route::post('view_request_Invoices',[InvoiceRequestController::class,'view_request_Invoices']);
        Route::post('get_invoice_data',[InvoiceRequestController::class,'get_invoice_data']);
    Route::post('request_invoice_confirmed',[InvoiceRequestController::class,'request_invoice_confirmed']);
    
     Route::post('request_invoice_confirmed_submit',[InvoiceRequestController::class,'request_invoice_confirmed_submit']);
    
    Route::post('request_invoice_confirmed_view',[InvoiceRequestController::class,'request_invoice_confirmed_view']);
    Route::post('request_invoice_pay_amount',[InvoiceRequestController::class,'request_invoice_pay_amount']);
    Route::post('request_recieve_invoice',[InvoiceRequestController::class,'request_recieve_invoice']);
    
    Route::post('request_invoice_edit',[InvoiceRequestController::class,'request_invoice_edit']);
          Route::post('request_invoice_edit_submit',[InvoiceRequestController::class,'request_invoice_edit_submit']);
    
    
    
    
    Route::post('get_single_Invoice/{id}',[ManageOfficeController::class,'get_single_Invoice']);
    Route::post('add_more_passenger_Invoice',[ManageOfficeController::class,'add_more_passenger_Invoice']);
    // Ajax
    Route::post('get_rooms_list',[ManageOfficeController::class,'get_rooms_list']);
    Route::post('get_hotels_list',[ManageOfficeController::class,'get_hotels_list']);
    
    Route::post('submit_invoiceRoomSupplier',[ManageOfficeController::class,'submit_invoiceRoomSupplier']);
    Route::post('get_invoiceRoomSupplier_detail',[ManageOfficeController::class,'get_invoiceRoomSupplier_detail']);
 
// End Manage Office Routes

// Rooms Route
Route::post('/hotel_manger/add_room',[RoomControllerApi::class,'showAddRoomFrom']);
Route::post('/hotel_manger/fetch_room_types',[RoomControllerApi::class,'fetch_room_types']);
Route::post('/hotel_manger/add_room_type_sub',[RoomControllerApi::class,'add_room_type_sub']);
Route::post('/hotel_manger/add_room_sub',[RoomControllerApi::class,'addRoom']);
Route::post('/hotel_manger/rooms_list',[RoomControllerApi::class,'index']);
Route::post('/hotel_manger/view_room/{id}',[RoomControllerApi::class,'updateShowForm']);
Route::post('/hotel_manger/update_room/{id}',[RoomControllerApi::class,'update_room']);

// Hotel Room Ajax Route
Route::post('hotel_Room',[HotelControllerApi::class,'hotel_Room']);

//Quotations
Route::post('manage_Quotation',[ManageQuotationsControllerApi::class,'manage_Quotation']);
Route::post('add_Manage_Quotation',[ManageQuotationsControllerApi::class,'add_Manage_Quotation']);
Route::post('view_Quotations',[ManageQuotationsControllerApi::class,'view_Quotations']);
Route::post('view_QuotationsID/{id}',[ManageQuotationsControllerApi::class,'view_QuotationsID']);
Route::post('edit_Quotations/{id}',[ManageQuotationsControllerApi::class,'edit_Quotations']);
Route::post('update_Manage_Quotation/{id}',[ManageQuotationsControllerApi::class,'update_Manage_Quotation']);
Route::post('invoice_Quotations/{id}',[ManageQuotationsControllerApi::class,'invoice_Quotations'])->name('invoice_Quotations');
// Flights
Route::post('get_flight_name',[ManageQuotationsControllerApi::class,'get_flight_name']);
//Makkah
Route::post('hotel_Makkah_Room',[ManageQuotationsControllerApi::class,'hotel_Makkah_Room']);
Route::post('makkah_Room/{id}',[ManageQuotationsControllerApi::class,'makkah_Room']);
//Madinah
Route::post('hotel_Madinah_Room',[ManageQuotationsControllerApi::class,'hotel_Madinah_Room']);
Route::post('madinah_Room/{id}',[ManageQuotationsControllerApi::class,'madinah_Room']);

//Bookings
Route::post('view_Bookings',[ManageQuotationsControllerApi::class,'view_Bookings']);
Route::post('add_Bookings/{id}',[ManageQuotationsControllerApi::class,'add_Bookings']);

//Room Ajax Route
Route::get('roomID/{id}',[HotelController::class,'roomID']);

// Vehicles
Route::post('add_Vehicles',[TransferVehiclesApiController::class,'add_Vehicles']);
Route::post('search_Vehicles',[TransferVehiclesApiController::class,'search_Vehicles']);
Route::post('view_Vehicles',[TransferVehiclesApiController::class,'view_Vehicles']);
Route::post('view_Vehicles1',[TransferVehiclesApiController::class,'view_Vehicles1']);
Route::post('add_new_vehicle',[TransferVehiclesApiController::class,'add_new_vehicle']);
Route::post('edit_vehicle_details/{id}',[TransferVehiclesApiController::class,'edit_vehicle_details']);
Route::post('update_vehicle/{id}',[TransferVehiclesApiController::class,'update_vehicle']);

// Destination
Route::post('view_Destination',[TransferVehiclesApiController::class,'view_Destination']);
Route::post('add_new_destination',[TransferVehiclesApiController::class,'add_new_destination']);
Route::post('edit_destination_details/{id}',[TransferVehiclesApiController::class,'edit_destination_details']);
Route::post('update_destination/{id}',[TransferVehiclesApiController::class,'update_destination']);
Route::post('get_tbo_hotel_details',[TransferVehiclesApiController::class,'get_tbo_hotel_details']);

// Vehicle Category
Route::post('view_Vehicle_Category',[TransferVehiclesApiController::class,'view_Vehicle_Category'])->name('view_Vehicle_Category');
Route::post('add_new_vehicle_category',[TransferVehiclesApiController::class,'add_new_vehicle_category']);
Route::post('edit_vehicle_category/{id}',[TransferVehiclesApiController::class,'edit_vehicle_category']);
Route::post('update_vehicle_category/{id}',[TransferVehiclesApiController::class,'update_vehicle_category']);
Route::post('delete_vehicle_category/{id}',[TransferVehiclesApiController::class,'delete_vehicle_category']);
Route::post('add_new_vehicle_category_Ajax',[TransferVehiclesApiController::class,'add_new_vehicle_category_Ajax']);


/*
|--------------------------------------------------------------------------
| api routes written by jamshaid cheena
|--------------------------------------------------------------------------
|
| 
|
*/

Route::post('package_departure_list','frontend\admin_dashboard\UmrahPackageController@package_departure_list');
Route::post('package_return_list','frontend\admin_dashboard\UmrahPackageController@package_return_list');
Route::post('activities_departure_list','frontend\admin_dashboard\UmrahPackageController@activities_departure_list');
Route::post('activities_return_list','frontend\admin_dashboard\UmrahPackageController@activities_return_list');
Route::post('package_bookings','frontend\admin_dashboard\UmrahPackageController@package_bookings');
Route::post('activities_bookings','frontend\admin_dashboard\UmrahPackageController@activities_bookings');

Route::post('listing_umrah_packages','frontend\admin_dashboard\UmrahPackageController@listing_umrah_packages');

Route::post('countryCites_apis', [CountryController::class,'countryCites_api']);
Route::post('country_cites_laln/{id}', [CountryController::class,'country_cites_laln']);
Route::post('country_cites_ID/{id}', [CountryController::class,'country_cites_ID']);

Route::post('hotel_Room',[HotelController::class,'hotel_Room_api']);
Route::post('save_hotel_booking',[HotelbookingController::class,'SaveHotelBooking']);
Route::post('save_hotel_booking_details_tbo',[HotelbookingController::class,'save_hotel_booking_details_tbo']);

//Room Ajax Route
Route::post('super_admin/roomID/{id}',[HotelController::class,'roomID_api']);

Route::get('create_umrah_packages','frontend\admin_dashboard\UmrahPackageController@create');
Route::post('submit_umrah_packages_api','frontend\admin_dashboard\UmrahPackageController@submit_umrah_packages_api');
Route::post('view_umrah_packages_api','frontend\admin_dashboard\UmrahPackageController@view_umrah_packages_api');

Route::post('delete_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_umrah_packages_api');
Route::post('edit_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_umrah_packages_api');
Route::post('submit_edit_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_umrah_packages_api');

Route::post('enable_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@enable_umrah_packages_api');
Route::post('disable_umrah_package_api/{id}','frontend\admin_dashboard\UmrahPackageController@disable_umrah_package_api');

// tour route api started by jamshaid cheena

Route::post('account_details','frontend\admin_dashboard\CustomerSubscription@account_details');
Route::post('edit_account_details/{id}','frontend\admin_dashboard\CustomerSubscription@edit_account_details');
Route::post('contact_details','frontend\admin_dashboard\CustomerSubscription@contact_details');
Route::post('submit_contact_details','frontend\admin_dashboard\CustomerSubscription@submit_contact_details');
Route::post('payment_gateways_list','frontend\admin_dashboard\CustomerSubscription@payment_gateways_list');
Route::post('submit_payment_gateways','frontend\admin_dashboard\CustomerSubscription@submit_payment_gateways');
Route::post('edit_payment_gateways','frontend\admin_dashboard\CustomerSubscription@edit_payment_gateways');

 Route::post('save_meta_tags','frontend\admin_dashboard\CustomerSubscription@save_meta_tags');
 Route::post('get_meta_tags','frontend\admin_dashboard\CustomerSubscription@get_meta_tags');
 Route::post('save_pages_meta_info','frontend\admin_dashboard\CustomerSubscription@save_pages_meta_info');
 Route::post('update_pages_meta_info','frontend\admin_dashboard\CustomerSubscription@update_pages_meta_info');
 Route::post('get_all_pages_meta_info','frontend\admin_dashboard\CustomerSubscription@get_all_pages_meta_info');
 Route::post('get_single_page_data','frontend\admin_dashboard\CustomerSubscription@get_single_page_data');


Route::post('payment_mode_list','frontend\admin_dashboard\CustomerSubscription@payment_mode_list');
Route::post('submit_payment_mode','frontend\admin_dashboard\CustomerSubscription@submit_payment_mode');
Route::post('edit_payment_mode','frontend\admin_dashboard\CustomerSubscription@edit_payment_mode');
Route::post('3rd_party_commession','frontend\admin_dashboard\CustomerSubscription@third_party_commession');
Route::post('third_party_packages_selection','frontend\admin_dashboard\CustomerSubscription@third_party_packages_selection');
Route::post('third_party_packages_approve','frontend\admin_dashboard\CustomerSubscription@third_party_packages_approve');

Route::post('submit_other_provider','frontend\admin_dashboard\CustomerSubscription@submit_other_provider');
Route::post('submit_all_provider','frontend\admin_dashboard\CustomerSubscription@submit_all_provider');
Route::post('delete_provider/{id}','frontend\admin_dashboard\CustomerSubscription@delete_provider');
Route::post('edit_provider/{id}','frontend\admin_dashboard\CustomerSubscription@edit_provider');
Route::post('submit_edit_provider/{id}','frontend\admin_dashboard\CustomerSubscription@submit_edit_provider');


Route::post('submit_categories','frontend\admin_dashboard\UmrahPackageController@submit_categories_api');
Route::post('view_categories','frontend\admin_dashboard\UmrahPackageController@view_categories_api');
Route::post('delete_categories/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_api');
Route::post('edit_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_categories_api');
Route::post('submit_edit_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_categories_api_request');
Route::post('delete_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_api');

Route::post('submit_attributes','frontend\admin_dashboard\UmrahPackageController@submit_attributes_api');
Route::post('view_attributes','frontend\admin_dashboard\UmrahPackageController@view_attributes_api');
Route::post('delete_attributes_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_attributes_api');
Route::post('submit_edit_attributes/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_attributes_api');

Route::post('edit_attributes_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_attributes_api');
 
Route::post('get_tour_list','frontend\admin_dashboard\UmrahPackageControllerApi@get_tour_list_api');
Route::post('create_tour','frontend\admin_dashboard\UmrahPackageController@create_tour_api');
Route::post('add_tour','frontend\admin_dashboard\UmrahPackageController@add_tour_api');


Route::post('mange_currency','frontend\admin_dashboard\UmrahPackageController@mange_currency_api');
Route::post('mange_currency_submit','frontend\admin_dashboard\UmrahPackageController@mange_currency_submit_api');



Route::post('edit_tour_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_tours_api');
Route::post('submit_tours_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_tours_api');
Route::post('delete_tour/{id}/{generate_id}','frontend\admin_dashboard\UmrahPackageController@delete_tour_api');
Route::post('enable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@enable_tour_api');
Route::post('disable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@disable_tour_api');

Route::post('save_Package','frontend\admin_dashboard\UmrahPackageController@save_Package');
Route::post('save_Accomodation/{id}','frontend\admin_dashboard\UmrahPackageController@save_Accomodation');

Route::post('booking_allocations/{id}','frontend\admin_dashboard\UmrahPackageController@booking_allocations');

// Activities 
Route::post('submit_Activities_New','frontend\admin_dashboard\UmrahPackageController@submit_Activities_New');
Route::post('edit_activities/{id}','frontend\admin_dashboard\UmrahPackageController@edit_activities');
Route::post('submit_edit_activities/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_activities');

// activities route api started by jamshaid cheena
Route::post('submit_categories_activites','frontend\admin_dashboard\UmrahPackageController@submit_categories_activites_api');
Route::post('view_categories_activites','frontend\admin_dashboard\UmrahPackageController@view_categories_activites_api');

Route::post('delete_categories_activites/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_activites_api');
Route::post('edit_categories_activites_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_categories_activites_api');
Route::post('submit_edit_categories_activites_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_categories_activites_api_request');
Route::post('delete_categories_activites_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_activites_api');

// Hotel Names
Route::post('view_Hotel_Names','frontend\admin_dashboard\UmrahPackageController@view_Hotel_Names');
Route::post('edit_Hotel_Names/{id}','frontend\admin_dashboard\UmrahPackageController@edit_Hotel_Names');
Route::post('submit_edit_Hotel_Names/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_Hotel_Names');
Route::post('delete_Hotel_Names/{id}','frontend\admin_dashboard\UmrahPackageController@delete_Hotel_Names');
// End Hotel Names

// Accounts Route

// Booking Allocations
Route::post('booking_details_single/{id}',[AccountDetailsApiController::class,'booking_details_single']);
Route::post('hotel_Name_Details_Single',[AccountDetailsApiController::class,'hotel_Name_Details_Single']);
Route::post('reservation_no_add',[AccountDetailsApiController::class,'reservation_no_add']);
Route::post('reservation_no_update',[AccountDetailsApiController::class,'reservation_no_update']);
Route::post('reservation_Detail_Single',[AccountDetailsApiController::class,'reservation_Detail_Single']);
Route::post('add_more_passenger_package_booking',[AccountDetailsApiController::class,'add_more_passenger_package_booking']);
// End

Route::post('expenses_IncomeAll',[AccountDetailsApiController::class,'expenses_IncomeAll']);
Route::post('expenses_Income_client_wise_data/{id}',[AccountDetailsApiController::class,'expenses_Income_client_wise_data']);

Route::post('income_statement',[AccountDetailsApiController::class,'income_statement']);
Route::post('expenses_Income',[AccountDetailsApiController::class,'expenses_Income']);
Route::post('out_Standings',[AccountDetailsApiController::class,'out_Standings']);
Route::post('recieved_Payments',[AccountDetailsApiController::class,'recieved_Payments']);
Route::post('recieved_Payments_approve',[AccountDetailsApiController::class,'recieved_Payments_approve']);
Route::post('update_customer_payment',[AccountDetailsApiController::class,'update_customer_payment']);


Route::post('stats_Tours',[AccountDetailsApiController::class,'stats_Tours']);
Route::post('more_Tour_Details1/{id}',[AccountDetailsApiController::class,'more_Tour_Details1']);

Route::post('cancelled_Tours',[AccountDetailsApiController::class,'cancelled_Tours']);

Route::post('view_total_Amount/{id}',[AccountDetailsApiController::class,'view_total_Amount']);
Route::post('view_recieve_Amount/{id}',[AccountDetailsApiController::class,'view_recieve_Amount']);
Route::post('view_Outstandings/{id}',[AccountDetailsApiController::class,'view_Outstandings']);
Route::post('view_Details_Accomodation/{id}',[AccountDetailsApiController::class,'view_Details_Accomodation']);

Route::post('hotel_detail_ID/{id}',[AccountDetailsApiController::class,'hotel_detail_ID']);
Route::post('flight_detail_ID/{id}',[AccountDetailsApiController::class,'flight_detail_ID']);
Route::post('transportation_detail_ID/{id}',[AccountDetailsApiController::class,'transportation_detail_ID']);
Route::post('visa_detail_ID/{id}',[AccountDetailsApiController::class,'visa_detail_ID']);

// Visa
Route::post('visa_Pay/{id}','frontend\admin_dashboard\AccountDetailsApiController@visa_Pay');
Route::post('sumbit_Visa_Pay','frontend\admin_dashboard\AccountDetailsApiController@sumbit_Visa_Pay');
Route::post('view_visa_total_Amount/{id}',[AccountDetailsApiController::class,'view_visa_total_Amount']);

// Transportation
Route::post('transportation_Pay/{id}','frontend\admin_dashboard\AccountDetailsApiController@transportation_Pay');
Route::post('sumbit_Transportation_Pay','frontend\admin_dashboard\AccountDetailsApiController@sumbit_Transportation_Pay');
Route::post('view_transportation_total_Amount/{id}',[AccountDetailsApiController::class,'view_transportation_total_Amount']);

// Flight
Route::post('sumbit_Flight_Pay','frontend\admin_dashboard\AccountDetailsApiController@sumbit_Flight_Pay');

// Accomodation
Route::post('acc_Pay/{selected_city}/{t_Id}','frontend\admin_dashboard\AccountDetailsApiController@acc_Pay');
Route::post('sumbit_Accomodation_Pay','frontend\admin_dashboard\AccountDetailsApiController@sumbit_Accomodation_Pay');


// End Accounts Route

// Locations
    // Pickup Locations
        Route::post('view_pickup_locations','frontend\admin_dashboard\UmrahPackageController@view_pickup_locations');
        Route::post('edit_pickup_locations/{id}','frontend\admin_dashboard\UmrahPackageController@edit_pickup_locations');
        Route::post('submit_edit_pickup_locations/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_pickup_locations');
        Route::post('delete_pickup_locations/{id}','frontend\admin_dashboard\UmrahPackageController@delete_pickup_locations');
    // Dropof Locations
        Route::post('view_dropof_locations','frontend\admin_dashboard\UmrahPackageController@view_dropof_locations');
        Route::post('edit_dropof_locations/{id}','frontend\admin_dashboard\UmrahPackageController@edit_dropof_locations');
        Route::post('submit_edit_dropof_locations/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_dropof_locations');
        Route::post('delete_dropof_locations/{id}','frontend\admin_dashboard\UmrahPackageController@delete_dropof_locations');
// End Locations

Route::post('submit_attributes_activites','frontend\admin_dashboard\UmrahPackageController@submit_attributes_activities_api');
Route::post('view_attributes_activites','frontend\admin_dashboard\UmrahPackageController@view_attributes_activites_api');
Route::post('delete_attributes_activites_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_attributes_activites_api');
Route::post('submit_edit_attributes_activites/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_attributes_activites_api');

Route::post('edit_attributes_activites_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_attributes_activites_api');
 
Route::post('get_activites_list','frontend\admin_dashboard\UmrahPackageController@get_activities_list_api');
Route::post('get_activites_lists','ActivityController@get_activities_list');
Route::post('submit_activity_cities','ActivityController@submit_activity_cities');

Route::post('get_activites_lists_wi_limit','ActivityController@get_activities_list_wi_limit');
Route::post('get_activites_lists_wi_cities','ActivityController@get_activites_lists_wi_cities');

Route::post('create_activites','frontend\admin_dashboard\UmrahPackageController@create_activities_api');
Route::post('add_activities','frontend\admin_dashboard\UmrahPackageController@add_activities_api');
Route::post('edit_activities_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_activities_api');
Route::post('submit_activities_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_activities_api');
Route::post('delete_activities/{id}','frontend\admin_dashboard\UmrahPackageController@delete_activities_api');
Route::post('enable_activities/{id}','frontend\admin_dashboard\UmrahPackageController@enable_activities_api');
Route::post('disable_activities/{id}','frontend\admin_dashboard\UmrahPackageController@disable_activities_api');

// activities route api ended by jamshaid cheena


Route::post('super_admin','frontend\admin_dashboard\CustomerSubscription@access_url');
Route::post('super_admin/login','frontend\admin_dashboard\CustomerSubscription@login');

Route::get('super_admin/userData','frontend\admin_dashboard\CustomerSubscription@index');



// 15/06/2022

Route::post('ticket_view','frontend\user_dashboard\UserController_Api@view_ticket');
Route::post('ticket_view/submit/{id}','frontend\user_dashboard\UserController_Api@admin_ticket');

//employees routes
Route::post('/employees',[App\Http\Controllers\frontend\EmployeeController_Api::class,'employees']);
Route::post('/employees/add',[App\Http\Controllers\frontend\EmployeeController_Api::class,'create']);
Route::post('/employees/submit',[App\Http\Controllers\frontend\EmployeeController_Api::class,'store']);
Route::post('/employees_edit/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'edit']);
Route::post('/employees_update/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'update']);
Route::post('/employees_delete/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'delete']);
Route::get('/view_location/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'view_location']);
Route::get('/view_task_location/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'view_task_location']);
Route::post('/employee_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'employee_roles']);
Route::post('/add_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'add_roles']);
Route::post('/edit_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'edit_roles']);
Route::post('/del_roles/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'del_roles']);
//employees routes


//attendence routes
Route::post('/attendance',[App\Http\Controllers\frontend\AttendenceController_Api::class,'attendence']);
Route::post('/attendance/add',[App\Http\Controllers\frontend\AttendenceController_Api::class,'create']);
Route::post('/attendance/submit',[App\Http\Controllers\frontend\AttendenceController_Api::class,'store']);
Route::post('/attendance_edit/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'edit']);
Route::post('/attendance_update/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'update']);
Route::post('/attendance_delete/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'delete']);
Route::post('/appoint/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'view_task'])->name('task.appoint1');
Route::post('/assign_mandob/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'assign_mandob']);

Route::post('employees_task',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task']);
Route::post('submit_task',[App\Http\Controllers\frontend\AttendenceController_Api::class,'submit_task']);
Route::post('employees_task_edit/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task_edit']);
Route::post('submit_edit_task/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'submit_edit_task']);
Route::post('employees_task_delete/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task_delete']);





Route::post('/leave_employees',[App\Http\Controllers\LeaveController_Api::class,'index']);
Route::post('/leave_status/{status}/{id}',[App\Http\Controllers\LeaveController_Api::class,'status']);
Route::post('/leaves/submit',[App\Http\Controllers\LeaveController_Api::class,'store']);



Route::post('/approve/{id}', [App\Http\Controllers\LeaveController_Api::class,'approve'])->name('admin.approve1');
Route::post('/decline/{id}', [App\Http\Controllers\LeaveController_Api::class,'decline'])->name('admin.decline1');

//settings route 
Route::post('/settings','frontend\user_dashboard\UserController_Api@settings');
Route::post('change-password', 'frontend\LoginController_Api@change_password');

Route::post('send_email_to_agents','frontend\user_dashboard\UserController_Api@send_email_to_agents');
Route::post('/send_mail','frontend\user_dashboard\UserController_Api@send_mail');


Route::post('/manage_user_roles','frontend\user_dashboard\UserController_Api@manage_user_roles');
Route::post('/add_user_permission','frontend\user_dashboard\UserController_Api@add_user_permission');
Route::post('/edit_user_permission','frontend\user_dashboard\UserController_Api@edit_user_permission');
Route::post('mange_user_role_delete/{id}','frontend\user_dashboard\UserController_Api@mange_user_role_delete');
Route::post('activate_user/{id}','frontend\user_dashboard\UserController_Api@super_admin_activate_user');
Route::post('inactivate_user/{id}','frontend\user_dashboard\UserController_Api@super_admin_inactivate_user');



Route::post('create_offers','frontend\user_dashboard\UserController_Api@create_offers');
Route::post('submit_offers','frontend\user_dashboard\UserController_Api@submit_offers');
Route::post('edit_offers/{id}','frontend\user_dashboard\UserController_Api@edit_offers');
Route::post('submit_edit_offers/{id}','frontend\user_dashboard\UserController_Api@submit_edit_offers');
Route::post('delete_offers/{id}','frontend\user_dashboard\UserController_Api@delete_offers');
Route::post('view_offers','frontend\user_dashboard\UserController_Api@view_offers');

// 15/06/2022


/*
|--------------------------------------------------------------------------
|api routes written by jamshaid cheena
|--------------------------------------------------------------------------
|
| 
|
*/

/*
|--------------------------------------------------------------------------
|api routes written by usama asghar
|--------------------------------------------------------------------------
|
| 
|
*/






Route::post('super_admin/update_web_content','frontend\admin_dashboard\CustomerSubscription@update_web_content');
Route::post('super_admin/view_web_content','frontend\admin_dashboard\CustomerSubscription@view_web_content');
Route::post('super_admin/url_meta_tag_info','frontend\admin_dashboard\CustomerSubscription@get_url_meta_tag_info');
Route::post('super_admin/update_web_cont','frontend\admin_dashboard\CustomerSubscription@update_web_cont');
Route::post('super_admin/slider_Images','frontend\admin_dashboard\CustomerSubscription@slider_Images');
Route::post('super_admin/fetch_top_categories','frontend\admin_dashboard\CustomerSubscription@fetch_top_categories');
Route::post('super_admin/fetch_all_categories','frontend\admin_dashboard\CustomerSubscription@fetch_all_categories');
Route::post('super_admin/fetch_all_attributes','frontend\admin_dashboard\CustomerSubscription@fetch_all_attributes');
Route::post('super_admin/filter_tour','frontend\admin_dashboard\CustomerSubscription@filter_tour');
Route::post('super_admin/filter_activities','frontend\admin_dashboard\CustomerSubscription@filter_activities');
Route::post('cleint_users_save','frontend\admin_dashboard\CustomerSubscription@cleint_users_save');
Route::post('customer_login_sub','frontend\admin_dashboard\CustomerSubscription@customer_login_sub');
Route::post('save_contact_us','frontend\admin_dashboard\CustomerSubscription@insert_contact_us');


Route::post('super_admin/fetch_category_tour_wi_limit','frontend\admin_dashboard\CustomerSubscription@fetch_category_tour_wi_limit');



Route::post('super_admin/update_slider_content','frontend\admin_dashboard\CustomerSubscription@slider_Images_update');



    Route::post('get_all_tores_wi_token','frontend\admin_dashboard\UmrahPackageController@get_all_tour_list_api_with_token');
    Route::post('get_category_wi_id','frontend\admin_dashboard\UmrahPackageController@get_category_wi_id');
    Route::post('get_facilities_names','frontend\admin_dashboard\UmrahPackageController@get_facilities_names');

    Route::post('get_tour_itenery','frontend\admin_dashboard\bookingController@get_tour_iternery'); 
    Route::post('add_special_discount','frontend\admin_dashboard\bookingController@add_special_discount'); 
    
    Route::post('get_tour_iteneryI','frontend\admin_dashboard\bookingController@get_tour_iteneryI');
    Route::post('get_tour_iteneryQ','frontend\admin_dashboard\bookingController@get_tour_iteneryQ');
    Route::post('delete_booking','frontend\admin_dashboard\bookingController@delete_booking');
    
    Route::post('get_tour_wi_token','frontend\admin_dashboard\UmrahPackageController@get_tour_list_api_with_token');
    Route::post('get_tour_for_carsole','frontend\admin_dashboard\UmrahPackageController@get_tour_for_carsole');
    Route::post('get_activity_for_carsole','frontend\admin_dashboard\UmrahPackageController@get_activity_for_carsole');
    Route::post('get_tour_details','frontend\admin_dashboard\UmrahPackageController@get_tour_details');
    Route::post('fetch_payment_data1','frontend\admin_dashboard\UmrahPackageController@fetch_payment_data1');
    Route::post('get_visa_type','frontend\admin_dashboard\BookingPackageController@get_visa_type');
    Route::post('save_booking','frontend\admin_dashboard\bookingController@save_booking');
    Route::post('update_booking','frontend\admin_dashboard\bookingController@update_booking');
    Route::post('save_booking_combine','frontend\admin_dashboard\bookingController@save_booking_combine');
    Route::post('save_booking1','frontend\admin_dashboard\bookingController@save_booking1');
    Route::post('agents_stats','frontend\admin_dashboard\bookingController@agents_stats');
    Route::post('agents_stats_details','frontend\admin_dashboard\bookingController@agents_stats_details');
    Route::post('supplier_stats_details','frontend\admin_dashboard\bookingController@supplier_stats_details');
    
    
    
    Route::post('save_booking_payment','frontend\admin_dashboard\bookingController@save_booking_payment');
    Route::post('view_customer_booking','frontend\admin_dashboard\CustomerSubscription@view_customer_booking');
    Route::post('view_customer_booking_combine','frontend\admin_dashboard\CustomerSubscription@view_customer_booking_combine');
    
  // Usama 6-15-2022
    Route::post('get_tour_for_cart','frontend\admin_dashboard\UmrahPackageController@get_tour_for_cart');
    Route::post('get_tour_payment_mode','frontend\admin_dashboard\UmrahPackageController@get_tour_payment_mode');
    Route::post('get_customer_booking','frontend\admin_dashboard\UmrahPackageController@view_booking_with_token');
    Route::post('get_agent_upaid_all_inv','frontend\admin_dashboard\bookingController@get_agent_upaid_all_inv');
    Route::post('adjust_over_pay','frontend\admin_dashboard\bookingController@adjust_over_pay');
    Route::post('manage_wallent_balance','frontend\admin_dashboard\bookingController@manage_wallent_balance');
    
    Route::post('invoice_data','frontend\admin_dashboard\bookingController@invoice_data');
    Route::post('invoice_dataI','frontend\admin_dashboard\bookingController@invoice_dataI');
    Route::post('invoice_dataQ','frontend\admin_dashboard\bookingController@invoice_dataQ');
    Route::post('tour_revenue','frontend\admin_dashboard\bookingController@tour_revenue');
    Route::post('invoice_combine','frontend\admin_dashboard\bookingController@invoice_combine');
    Route::post('invoice_package_data','frontend\admin_dashboard\bookingController@invoice_package_data');
    Route::post('get_tour_iternery_invoice_package_data','frontend\admin_dashboard\bookingController@get_tour_iternery_invoice_package_data');
    
    Route::post('/countries', [CountryController::class,'allCountries']);
    

    
// Route::post('/search_pakages','frontend\admin_dashboard\UmrahPackageController@search_pakages'); 
// Route::post('/map_data','frontend\admin_dashboard\UmrahPackageController@map_data'); 
// Route::post('/search_activities','frontend\admin_dashboard\UmrahPackageController@search_activities'); 
// Route::post('/country_activities','frontend\admin_dashboard\UmrahPackageController@get_country_activities'); 
// Route::post('/all_activities','frontend\admin_dashboard\UmrahPackageController@get_all_activities'); 

Route::post('/search_pakages','frontend\admin_dashboard\UmrahPackageController@search_pakages'); 
Route::post('/map_data','frontend\admin_dashboard\UmrahPackageController@map_data'); 
Route::post('/search_activities','frontend\admin_dashboard\UmrahPackageController@search_activities'); 
Route::post('/activitySearchajax','frontend\admin_dashboard\AjaxActivityController@activitySearchajax');
Route::post('/get_activity_detail','frontend\admin_dashboard\AjaxActivityController@get_activity_detail');
Route::post('/country_activities','frontend\admin_dashboard\UmrahPackageController@get_country_activities'); 
Route::post('/all_activities','frontend\admin_dashboard\UmrahPackageController@get_all_activities'); 

Route::post('/cites_suggestions','frontend\admin_dashboard\UmrahPackageController@cites_suggestions'); 
    
    
Route::post('book_package','frontend\admin_dashboard\BookingPackageController_Api@book_package');
Route::post('get_booking_package/{id}','frontend\admin_dashboard\BookingPackageController_Api@get_booking_package');
Route::post('get_booking_package_tour/{title}','frontend\admin_dashboard\BookingPackageController_Api@get_booking_package_tour');
Route::post('submit_book_package','frontend\admin_dashboard\BookingPackageController_Api@submit_book_package');
Route::post('get_cites_book/{country_id}', 'frontend\admin_dashboard\BookingPackageController_Api@get_cites_book');
/*
|--------------------------------------------------------------------------
|api routes written by usama asghar
|--------------------------------------------------------------------------
|
| 
|
*/
