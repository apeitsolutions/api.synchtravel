<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\HotelMangers\HotelController;
use App\Models\city;
use App\Models\country;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});



/*
|--------------------------------------------------------------------------
| api routes written by jamshaid cheena
|--------------------------------------------------------------------------
|
| 
|
*/
Route::post('client_middleware',[App\Http\Controllers\ClientController::class,'__construct']);



Route::post('countryCites_apis', [CountryController::class,'countryCites_api']);
   Route::post('hotel_Room',[HotelController::class,'hotel_Room_api']);
 //Room Ajax Route
    Route::post('super_admin/roomID/{id}',[HotelController::class,'roomID_api']);


Route::get('create_umrah_packages','frontend\admin_dashboard\UmrahPackageController@create');
Route::post('submit_umrah_packages_api','frontend\admin_dashboard\UmrahPackageController@submit_umrah_packages_api');
Route::post('view_umrah_packages_api','frontend\admin_dashboard\UmrahPackageController@view_umrah_packages_api');

Route::post('delete_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_umrah_packages_api');
Route::post('edit_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_umrah_packages_api');
Route::post('submit_edit_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_umrah_packages_api');

Route::post('enable_umrah_packages_api/{id}','frontend\admin_dashboard\UmrahPackageController@enable_umrah_packages_api');
Route::post('disable_umrah_package_api/{id}','frontend\admin_dashboard\UmrahPackageController@disable_umrah_package_api');








    Route::post('submit_categories','frontend\admin_dashboard\UmrahPackageController@submit_categories_api');
    Route::post('view_categories','frontend\admin_dashboard\UmrahPackageController@view_categories_api');
    Route::post('delete_categories/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_api');
    Route::post('edit_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_categories_api');
    Route::post('submit_edit_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_categories_api_request');
    Route::post('delete_categories_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_categories_api');



    Route::post('submit_attributes','frontend\admin_dashboard\UmrahPackageController@submit_attributes_api');
    Route::post('view_attributes','frontend\admin_dashboard\UmrahPackageController@view_attributes_api');
    Route::post('delete_attributes_api/{id}','frontend\admin_dashboard\UmrahPackageController@delete_attributes_api');
    Route::post('submit_edit_attributes/{id}','frontend\admin_dashboard\UmrahPackageController@submit_edit_attributes_api');

    Route::post('edit_attributes_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_attributes_api');
    




Route::post('get_tour_list','frontend\admin_dashboard\UmrahPackageController@get_tour_list_api');
Route::post('create_tour','frontend\admin_dashboard\UmrahPackageController@create_tour_api');
Route::post('add_tour','frontend\admin_dashboard\UmrahPackageController@add_tour_api');
Route::post('edit_tour_api/{id}','frontend\admin_dashboard\UmrahPackageController@edit_tours_api');
Route::post('submit_tours_api/{id}','frontend\admin_dashboard\UmrahPackageController@submit_tours_api');
Route::post('delete_tour/{id}','frontend\admin_dashboard\UmrahPackageController@delete_tour_api');
Route::post('enable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@enable_tour_api');
Route::post('disable_tour/{id}','frontend\admin_dashboard\UmrahPackageController@disable_tour_api');

Route::post('super_admin','frontend\admin_dashboard\CustomerSubscription@access_url');
Route::post('super_admin/login','frontend\admin_dashboard\CustomerSubscription@login');

Route::get('super_admin/userData','frontend\admin_dashboard\CustomerSubscription@index');



// 15/06/2022

Route::post('ticket_view','frontend\user_dashboard\UserController_Api@view_ticket');
Route::post('ticket_view/submit/{id}','frontend\user_dashboard\UserController_Api@admin_ticket');

//employees routes
Route::post('/employees',[App\Http\Controllers\frontend\EmployeeController_Api::class,'employees']);
Route::post('/employees/add',[App\Http\Controllers\frontend\EmployeeController_Api::class,'create']);
Route::post('/employees/submit',[App\Http\Controllers\frontend\EmployeeController_Api::class,'store']);
Route::post('/employees_edit/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'edit']);
Route::post('/employees_update/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'update']);
Route::post('/employees_delete/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'delete']);
Route::get('/view_location/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'view_location']);
Route::get('/view_task_location/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'view_task_location']);
Route::post('/employee_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'employee_roles']);
Route::post('/add_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'add_roles']);
Route::post('/edit_roles',[App\Http\Controllers\frontend\EmployeeController_Api::class,'edit_roles']);
Route::post('/del_roles/{id}',[App\Http\Controllers\frontend\EmployeeController_Api::class,'del_roles']);
//employees routes


//attendence routes
Route::post('/attendance',[App\Http\Controllers\frontend\AttendenceController_Api::class,'attendence']);
Route::post('/attendance/add',[App\Http\Controllers\frontend\AttendenceController_Api::class,'create']);
Route::post('/attendance/submit',[App\Http\Controllers\frontend\AttendenceController_Api::class,'store']);
Route::post('/attendance_edit/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'edit']);
Route::post('/attendance_update/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'update']);
Route::post('/attendance_delete/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'delete']);
Route::post('/appoint/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'view_task'])->name('task.appoint1');
Route::post('/assign_mandob/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'assign_mandob']);

Route::post('employees_task',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task']);
Route::post('submit_task',[App\Http\Controllers\frontend\AttendenceController_Api::class,'submit_task']);
Route::post('employees_task_edit/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task_edit']);
Route::post('submit_edit_task/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'submit_edit_task']);
Route::post('employees_task_delete/{id}',[App\Http\Controllers\frontend\AttendenceController_Api::class,'employees_task_delete']);





Route::post('/leave_employees',[App\Http\Controllers\LeaveController_Api::class,'index']);
Route::post('/leave_status/{status}/{id}',[App\Http\Controllers\LeaveController_Api::class,'status']);
Route::post('/leaves/submit',[App\Http\Controllers\LeaveController_Api::class,'store']);



Route::post('/approve/{id}', [App\Http\Controllers\LeaveController_Api::class,'approve'])->name('admin.approve1');
Route::post('/decline/{id}', [App\Http\Controllers\LeaveController_Api::class,'decline'])->name('admin.decline1');

//settings route 
Route::post('/settings','frontend\user_dashboard\UserController_Api@settings');
Route::post('change-password', 'frontend\LoginController_Api@change_password');

Route::post('send_email_to_agents','frontend\user_dashboard\UserController_Api@send_email_to_agents');
Route::post('/send_mail','frontend\user_dashboard\UserController_Api@send_mail');


Route::post('/manage_user_roles','frontend\user_dashboard\UserController_Api@manage_user_roles');
Route::post('/add_user_permission','frontend\user_dashboard\UserController_Api@add_user_permission');
Route::post('/edit_user_permission','frontend\user_dashboard\UserController_Api@edit_user_permission');
Route::post('mange_user_role_delete/{id}','frontend\user_dashboard\UserController_Api@mange_user_role_delete');
Route::post('activate_user/{id}','frontend\user_dashboard\UserController_Api@super_admin_activate_user');
Route::post('inactivate_user/{id}','frontend\user_dashboard\UserController_Api@super_admin_inactivate_user');



Route::post('create_offers','frontend\user_dashboard\UserController_Api@create_offers');
Route::post('submit_offers','frontend\user_dashboard\UserController_Api@submit_offers');
Route::post('edit_offers/{id}','frontend\user_dashboard\UserController_Api@edit_offers');
Route::post('submit_edit_offers/{id}','frontend\user_dashboard\UserController_Api@submit_edit_offers');
Route::post('delete_offers/{id}','frontend\user_dashboard\UserController_Api@delete_offers');
Route::post('view_offers','frontend\user_dashboard\UserController_Api@view_offers');

// 15/06/2022


/*
|--------------------------------------------------------------------------
|api routes written by jamshaid cheena
|--------------------------------------------------------------------------
|
| 
|
*/

/*
|--------------------------------------------------------------------------
|api routes written by usama
|--------------------------------------------------------------------------
|
| 
|
*/


Route::post('super_admin/update_web_content','frontend\admin_dashboard\CustomerSubscription@update_web_content');
Route::post('super_admin/view_web_content','frontend\admin_dashboard\CustomerSubscription@view_web_content');
Route::post('super_admin/update_web_cont','frontend\admin_dashboard\CustomerSubscription@update_web_cont');
Route::post('super_admin/slider_Images','frontend\admin_dashboard\CustomerSubscription@slider_Images');



Route::post('super_admin/update_slider_content','frontend\admin_dashboard\CustomerSubscription@slider_Images_update');



    
    Route::post('get_tour_wi_token','frontend\admin_dashboard\UmrahPackageController@get_tour_list_api_with_token');
    Route::post('get_tour_details','frontend\admin_dashboard\UmrahPackageController@get_tour_details');
    Route::post('save_booking','frontend\admin_dashboard\bookingController@save_booking');
  // USama 6-15-2022
    Route::post('get_tour_for_cart','frontend\admin_dashboard\UmrahPackageController@get_tour_for_cart');
    Route::post('invoice_data','frontend\admin_dashboard\bookingController@invoice_data');

